const fs = require('fs');
const path = require('path');

// Read the original HTML file
const originalHtmlPath = path.resolve(__dirname, '../public/assets/aistudio/deepseek_html_20261019_574f13_af3cbc3b.html');
const originalHtml = fs.readFileSync(originalHtmlPath, 'utf8');

console.log('Original HTML size:', originalHtml.length);
