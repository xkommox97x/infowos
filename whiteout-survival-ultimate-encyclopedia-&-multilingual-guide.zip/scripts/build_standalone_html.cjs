const fs = require('fs');
const path = require('path');

// Read the original file
const htmlPath = path.resolve(__dirname, '../public/assets/aistudio/deepseek_html_20261019_574f13_af3cbc3b.html');
let content = fs.readFileSync(htmlPath, 'utf8');

// We will construct the enhanced HTML with:
// 1. Google Translate API integration
// 2. High-speed client-side dictionary for all 12 languages
// 3. Translation indicator pill & Export HTML button
// 4. Full RTL support for Arabic
// 5. Reactive DOM translator that switches texts smoothly

// Find where <script> starts
const scriptStartTag = '<script>';
const scriptEndTag = '</script>';

const scriptIndex = content.lastIndexOf(scriptStartTag);
if (scriptIndex === -1) {
  console.error('Could not find script tag');
  process.exit(1);
}

const beforeScript = content.substring(0, scriptIndex);

// Add download button & status indicator to header-controls if not present
let modifiedHtml = beforeScript;

// Enhance header controls with download button and translation badge
const oldHeaderControls = '<div class="header-controls">';
const newHeaderControls = `<div class="header-controls">
<span id="transStatus" style="font-size:0.75rem;padding:4px 10px;border-radius:12px;background:rgba(84,192,239,0.15);border:1px solid var(--ice);color:var(--frost);display:flex;align-items:center;gap:6px;">
  <span style="display:inline-block;width:8px;height:8px;border-radius:50%;background:#4ade80;"></span>
  <span id="transStatusText">🇹🇷 Türkçe (Orijinal)</span>
</span>
<button id="downloadHtmlBtn" style="padding:6px 12px;font-size:0.75rem;background:var(--bg-card);border:1px solid var(--border);border-radius:var(--radius);color:var(--ice);font-weight:600;display:flex;align-items:center;gap:6px;" title="Bu sayfayı HTML dosyası olarak indir">
  📥 İndir (.html)
</button>`;

if (modifiedHtml.includes(oldHeaderControls)) {
  modifiedHtml = modifiedHtml.replace(oldHeaderControls, newHeaderControls);
}

// Add Google Translate element right before main
const googleTranslateDiv = `
<div id="google_translate_element" style="display:none;"></div>
`;

if (modifiedHtml.includes('<main class="container">')) {
  modifiedHtml = modifiedHtml.replace('<main class="container">', googleTranslateDiv + '<main class="container">');
}

// Now write the new script that includes the complete 12-language translation engine
const newScript = `<script type="text/javascript">
function googleTranslateElementInit() {
  new google.translate.TranslateElement({
    pageLanguage: 'tr',
    includedLanguages: 'tr,en,de,fr,es,pt,ru,ar,ja,zh-CN,it,pl',
    autoDisplay: false
  }, 'google_translate_element');
}
</script>
<script type="text/javascript" src="//translate.google.com/translate_a/element.js?cb=googleTranslateElementInit"></script>

<script>
// ============================================================
// WHITEOUT SURVIVAL ENCYCLOPEDIA — 12-LANGUAGE CLIENT TRANSLATOR
// ============================================================

const LANG_CONFIG = {
  tr: { name: "Türkçe", flag: "🇹🇷", dir: "ltr", searchPlaceholder: "Ansiklopedide ara...", status: "Türkçe (Orijinal)" },
  en: { name: "English", flag: "🇬🇧", dir: "ltr", searchPlaceholder: "Search encyclopedia (Helios, Gear, Bear Trap)...", status: "English (Translated)" },
  de: { name: "Deutsch", flag: "🇩🇪", dir: "ltr", searchPlaceholder: "Enzyklopädie durchsuchen...", status: "Deutsch (Übersetzt)" },
  fr: { name: "Français", flag: "🇫🇷", dir: "ltr", searchPlaceholder: "Rechercher dans l'encyclopédie...", status: "Français (Traduit)" },
  es: { name: "Español", flag: "🇪🇸", dir: "ltr", searchPlaceholder: "Buscar en la enciclopedia...", status: "Español (Traducido)" },
  pt: { name: "Português", flag: "🇵🇹", dir: "ltr", searchPlaceholder: "Pesquisar na enciclopédia...", status: "Português (Traduzido)" },
  ru: { name: "Русский", flag: "🇷🇺", dir: "ltr", searchPlaceholder: "Поиск по энциклопедии...", status: "Русский (Переведено)" },
  ar: { name: "العربية", flag: "🇸🇦", dir: "rtl", searchPlaceholder: "ابحث في الموسوعة...", status: "العربية (مترجم)" },
  ja: { name: "日本語", flag: "🇯🇵", dir: "ltr", searchPlaceholder: "百科事典を検索...", status: "日本語 (翻訳済)" },
  zh: { name: "简体中文", flag: "🇨🇳", dir: "ltr", searchPlaceholder: "搜索百科全书...", status: "简体中文 (已翻译)" },
  it: { name: "Italiano", flag: "🇮🇹", dir: "ltr", searchPlaceholder: "Cerca nell'enciclopedia...", status: "Italiano (Tradotto)" },
  pl: { name: "Polski", flag: "🇵🇱", dir: "ltr", searchPlaceholder: "Szukaj w encyklopedii...", status: "Polski (Przetłumaczono)" }
};

// Curated high-accuracy game translations for TOC links
const TOC_TRANSLATIONS = {
  tr: ["Başlangıç", "Fırın", "Araştırma", "Kahramanlar", "Hero Gear", "Chief Gear", "Chief Charms", "Helios T11", "Helios 1. Ordu", "Genel Ordu", "Savaş", "Kale Savaşı", "Ayı Tuzağı", "Uzmanlar", "Evcil Hayvanlar", "Etkinlikler", "F2P vs P2W", "Tuzaklar", "Kaynaklar"],
  en: ["Getting Started", "Furnace", "Research", "Heroes", "Hero Gear", "Chief Gear", "Chief Charms", "Helios T11", "Helios 1st Army", "Troop Ratios", "Battle", "Sunfire Castle", "Bear Trap", "Experts", "Pets", "Events", "F2P vs P2W", "Traps", "Sources"],
  de: ["Einstieg", "Ofen", "Forschung", "Helden", "Helden-Gear", "Anführer-Gear", "Talismane", "Helios T11", "Helios 1. Armee", "Truppenquoten", "Kampf", "Sonnfeuer", "Bärenfalle", "Experten", "Haustiere", "Events", "F2P vs P2W", "Fallen", "Quellen"],
  fr: ["Débuter", "Fournaise", "Recherche", "Héros", "Équip. Héros", "Équip. Chef", "Charmes Chef", "Hélios T11", "Hélios 1ère Armée", "Ratios Troupes", "Combat", "Château Sunfire", "Piège à Ours", "Experts", "Familiers", "Événements", "F2P vs P2W", "Pièges", "Sources"],
  es: ["Inicio", "Horno", "Investigación", "Héroes", "Equipo Héroe", "Equipo Jefe", "Talismanes", "Helios T11", "Helios 1er Ejército", "Ratios Tropas", "Batalla", "Castillo Sunfire", "Trampa Oso", "Expertos", "Mascotas", "Eventos", "F2P vs P2W", "Trampas", "Fuentes"],
  pt: ["Início", "Fornalha", "Pesquisa", "Heróis", "Equip. Herói", "Equip. Chefe", "Amuletos", "Helios T11", "Helios 1º Exército", "Proporções", "Batalha", "Castelo Sunfire", "Armadilha Urso", "Especialistas", "Mascotes", "Eventos", "F2P vs P2W", "Armadilhas", "Fontes"],
  ru: ["Старт", "Печь", "Исследования", "Герои", "Снаряжение героев", "Снаряжение вождя", "Чармы", "Гелиос T11", "Гелиос 1-я армия", "Составы войск", "Бой", "Замок Санфайр", "Медвежья ловушка", "Эксперты", "Питомцы", "События", "F2P vs P2W", "Ошибки", "Источники"],
  ar: ["البداية", "الفرن", "الأبحاث", "الأبطال", "عتاد الأبطال", "عتاد القائد", "التمائم", "هيليوس T11", "جيش هيليوس 1", "نسب القوات", "المعارك", "قلعة سان فاير", "مصيدة الدب", "الخبراء", "الحيوانات", "الفعاليات", "F2P مقابل P2W", "الأخطاء", "المصادر"],
  ja: ["序盤攻略", "溶鉱炉", "研究", "英雄", "英雄装備", "総督装備", "護符", "ヘリオスT11", "ヘリオス第1部隊", "全般兵種比率", "戦闘システム", "太陽城争奪", "ベアトラップ", "専門家", "巨獣ペット", "イベント日程", "無課金vs課金", "落とし穴", "情報源"],
  zh: ["新手起步", "大熔炉", "科学研究", "英雄百科", "装备赋能", "领主装备", "领主护符", "太阳神T11", "太阳神配比", "通用配比", "战斗机制", "太阳城王战", "猎熊全解", "学院专家", "宠物巨兽", "活动日程", "平民vs氪金", "避坑指南", "参考资料"],
  it: ["Inizio", "Fornace", "Ricerca", "Eroi", "Equip. Eroi", "Equip. Capo", "Amuleti", "Helios T11", "Helios 1° Esercito", "Ripartizione", "Battaglia", "Castello Sunfire", "Trappola Orso", "Esperti", "Animali", "Eventi", "F2P vs P2W", "Trappole", "Fonti"],
  pl: ["Start", "Piec", "Badania", "Bohaterowie", "Ekwip. Bohaterów", "Ekwip. Wodza", "Talizmany", "Helios T11", "Helios 1. Armia", "Proporcje", "Walka", "Zamek Sunfire", "Pułapka Niedźwiedź", "Eksperci", "Zwierzaki", "Wydarzenia", "F2P vs P2W", "Pułapki", "Źródła"]
};

// Section H2 Titles mapping for instant direct translation
const SECTION_TITLES = {
  baslangic: {
    tr: "🚀 1. Sıfırdan Başlangıç — İlk 30 Gün ve F2P Yol Haritası",
    en: "🚀 1. Getting Started — First 30 Days & F2P Roadmap",
    de: "🚀 1. Der Einstieg — Erste 30 Tage & F2P-Fahrplan",
    fr: "🚀 1. Bien Débuter — Les 30 Premiers Jours & Feuille de Route F2P",
    es: "🚀 1. Empezando de Cero — Primeros 30 Días y Hoja de Ruta F2P",
    pt: "🚀 1. Começando do Zero — Primeiros 30 Dias e Roteiro F2P",
    ru: "🚀 1. Старт с нуля — Первые 30 дней и дорожная карта F2P",
    ar: "🚀 1. البداية من الصفر — أول 30 يوماً وخارطة طريق F2P",
    ja: "🚀 1. ゼロからのスタート — 最初の30日間と無課金(F2P)ロードマップ",
    zh: "🚀 1. 从零起步 — 首月30天与零氪(F2P)发展路线图",
    it: "🚀 1. Iniziare da Zero — Primi 30 Giorni e Tabella di Marcia F2P",
    pl: "🚀 1. Start od Zera — Pierwsze 30 Dni i Plan F2P"
  },
  firin: {
    tr: "🏰 2. Fırın ve Şehir Gelişimi",
    en: "🏰 2. Furnace & City Development",
    de: "🏰 2. Ofen & Stadtentwicklung",
    fr: "🏰 2. Fournaise & Développement Urbain",
    es: "🏰 2. Horno y Desarrollo de la Ciudad",
    pt: "🏰 2. Fornalha e Desenvolvimento da Cidade",
    ru: "🏰 2. Печь и развитие города",
    ar: "🏰 2. الفرن وتطوير المدينة",
    ja: "🏰 2. 大溶鉱炉と都市開発",
    zh: "🏰 2. 大熔炉与城市建筑发展",
    it: "🏰 2. Fornace e Sviluppo Urbano",
    pl: "🏰 2. Piec i Rozwój Miasta"
  },
  arastirma: {
    tr: "🔬 3. Araştırma Merkezi",
    en: "🔬 3. Research Center Prioritization",
    de: "🔬 3. Forschungszentrum-Prioritäten",
    fr: "🔬 3. Centre de Recherche",
    es: "🔬 3. Centro de Investigación",
    pt: "🔬 3. Centro de Pesquisa",
    ru: "🔬 3. Центр исследований",
    ar: "🔬 3. مركز الأبحاث",
    ja: "🔬 3. 研究所の優先度",
    zh: "🔬 3. 科学研究所优先升级指南",
    it: "🔬 3. Centro di Ricerca",
    pl: "🔬 3. Centrum Badań"
  },
  kahramanlar: {
    tr: "🦸 4. Kahraman Ansiklopedisi ve Nesil Tuzağı",
    en: "🦸 4. Hero Encyclopedia & Generation Trap",
    de: "🦸 4. Helden-Enzyklopädie & Generationsfalle",
    fr: "🦸 4. Encyclopédie des Héros & Piège des Générations",
    es: "🦸 4. Enciclopedia de Héroes y la Trampa de Generaciones",
    pt: "🦸 4. Enciclopédia de Heróis e a Armadilha das Gerações",
    ru: "🦸 4. Энциклопедия героев и ловушка поколений",
    ar: "🦸 4. موسوعة الأبطال وفخ الأجيال",
    ja: "🦸 4. 英雄図鑑と「世代の罠」",
    zh: "🦸 4. 英雄图鉴全解与代际陷阱",
    it: "🦸 4. Enciclopedia Eroi e la Trappola delle Generazioni",
    pl: "🦸 4. Encyklopedia Bohaterów i Pułapka Generacji"
  },
  "hero-gear": {
    tr: "⚔️ 5. Hero Gear — Empowerment (+20 → +60 → +100)",
    en: "⚔️ 5. Hero Gear — Empowerment (+20 → +60 → +100)",
    de: "⚔️ 5. Heldenausrüstung — Ermächtigung (+20 → +60 → +100)",
    fr: "⚔️ 5. Équipement de Héros — Renforcement (+20 → +60 → +100)",
    es: "⚔️ 5. Equipo de Héroe — Potenciación (+20 → +60 → +100)",
    pt: "⚔️ 5. Equipamento de Herói — Potenciação (+20 → +60 → +100)",
    ru: "⚔️ 5. Снаряжение героев — Усиление (+20 → +60 → +100)",
    ar: "⚔️ 5. عتاد الأبطال — التمكين (+20 → +60 → +100)",
    ja: "⚔️ 5. 英雄装備 — エンパワー (+20 → +60 → +100)",
    zh: "⚔️ 5. 英雄装备 — 赋能精炼 (+20 → +60 → +100)",
    it: "⚔️ 5. Equipaggiamento Eroi — Potenziamento (+20 → +60 → +100)",
    pl: "⚔️ 5. Ekwipunek Bohaterów — Wzmocnienie (+20 → +60 → +100)"
  },
  "chief-gear": {
    tr: "🛡️ 6. Chief Gear — Set Bonusu Kuralı",
    en: "🛡️ 6. Chief Gear — Set Bonus Rules",
    de: "🛡️ 6. Anführer-Ausrüstung — Set-Bonus-Regel",
    fr: "🛡️ 6. Équipement du Chef — Règle du Bonus de Set",
    es: "🛡️ 6. Equipo del Jefe — Regla del Bonus de Conjunto",
    pt: "🛡️ 6. Equipamento do Chefe — Regra do Bônus de Conjunto",
    ru: "🛡️ 6. Снаряжение вождя — Правило бонуса сета",
    ar: "🛡️ 6. عتاد القائد — قاعدة مكافأة المجموعة",
    ja: "🛡️ 6. 総督装備 — セット効果の絶対法則",
    zh: "🛡️ 6. 领主装备 — 套装效果木桶理论",
    it: "🛡️ 6. Equipaggiamento del Capo — Regola del Bonus Set",
    pl: "🛡️ 6. Ekwipunek Wodza — Zasada Bonusu Zestawu"
  },
  "chief-charms": {
    tr: "💎 7. Chief Charms — Lv.11 Eşiği ve 40:1 Takas",
    en: "💎 7. Chief Charms — Lv.11 Threshold & 40:1 Exchange",
    de: "💎 7. Anführer-Talismane — Lv.11 Schwelle & 40:1 Tausch",
    fr: "💎 7. Charmes du Chef — Seuil Niv.11 & Échange 40:1",
    es: "💎 7. Talismanes del Jefe — Umbral Nv.11 y Canje 40:1",
    pt: "💎 7. Amuletos do Chefe — Limite Nív.11 e Troca 40:1",
    ru: "💎 7. Чармы вождя — Порог 11 ур. и обмен 40:1",
    ar: "💎 7. تمائم القائد — عتبة المستوى 11 ومبادلة 40:1",
    ja: "💎 7. 護符(チャーム) — Lv.11の壁と40:1交換レート",
    zh: "💎 7. 领主护符 — 11级门槛与40:1兑换机制",
    it: "💎 7. Amuleti del Capo — Soglia Liv.11 e Scambio 40:1",
    pl: "💎 7. Talizmany Wodza — Próg Poz. 11 i Wymiana 40:1"
  },
  helios: {
    tr: "🌟 8. Helios T11 — Geç Oyunun Kapısı",
    en: "🌟 8. Helios T11 — The Late-Game Gate",
    de: "🌟 8. Helios T11 — Das Tor zum Late-Game",
    fr: "🌟 8. Hélios T11 — La Porte du Late-Game",
    es: "🌟 8. Helios T11 — La Puerta al Late-Game",
    pt: "🌟 8. Helios T11 — A Porta para o Fim de Jogo",
    ru: "🌟 8. Гелиос T11 — Врата в позднюю игру",
    ar: "🌟 8. قوات هيليوس T11 — بوابة المراحل المتقدمة",
    ja: "🌟 8. ヘリオスT11兵 — 終盤戦の絶対関門",
    zh: "🌟 8. 太阳神 T11 兵种 — 后期战争分水岭",
    it: "🌟 8. Helios T11 — La Porta del Late-Game",
    pl: "🌟 8. Helios T11 — Brama do Późnej Gry"
  },
  "helios-oranlar": {
    tr: "🎯 9. Helios T11 — 1. Ordu ve Alternatifleri",
    en: "🎯 9. Helios T11 — 1st Army Compositions",
    de: "🎯 9. Helios T11 — 1. Armee & Alternativen",
    fr: "🎯 9. Hélios T11 — 1ère Armée et Alternatives",
    es: "🎯 9. Helios T11 — 1er Ejército y Alternativas",
    pt: "🎯 9. Helios T11 — 1º Exército e Alternativas",
    ru: "🎯 9. Гелиос T11 — Составы 1-й армии",
    ar: "🎯 9. هيليوس T11 — تشكيلات الجيش الأول والبدائل",
    ja: "🎯 9. ヘリオスT11 — 第1軍団編成と代替案",
    zh: "🎯 9. 太阳神 T11 — 第一主力出征配比及变体",
    it: "🎯 9. Helios T11 — 1° Esercito e Alternative",
    pl: "🎯 9. Helios T11 — Skład 1. Armii i Alternatywy"
  },
  "ordu-oranlari": {
    tr: "🎯 10. Genel Ordu Oranları — Mod Bazlı",
    en: "🎯 10. General Troop Ratios — Mode Specific",
    de: "🎯 10. Allgemeine Truppenverhältnisse — Modus-spezifisch",
    fr: "🎯 10. Ratios Généraux de Troupes — Par Mode",
    es: "🎯 10. Ratios Generales de Tropas — Por Modo de Juego",
    pt: "🎯 10. Proporções Gerais de Tropas — Por Modo",
    ru: "🎯 10. Общие соотношения войск по режимам игры",
    ar: "🎯 10. نسب القوات العامة — بحسب نمط اللعب",
    ja: "🎯 10. 各種コンテンツ別・部隊編成比率",
    zh: "🎯 10. 全玩法部队兵种出征配比大全",
    it: "🎯 10. Ripartizione Generale Truppe — Per Modalità",
    pl: "🎯 10. Ogólne Proporcje Wojsk — Według Trybów"
  },
  savas: {
    tr: "⚔️ 11. Savaş Mekanikleri — Sayaç Üçgeni, Ralli ve Garnizon",
    en: "⚔️ 11. Battle Mechanics — Counter Triangle, Rallies & Garrisons",
    de: "⚔️ 11. Kampfmechanik — Konter-Dreieck & Rallies",
    fr: "⚔️ 11. Mécaniques de Combat — Triangle de Contre & Rallies",
    es: "⚔️ 11. Mecánicas de Batalla — Triángulo de Contras y Rallies",
    pt: "⚔️ 11. Mecânicas de Batalha — Triângulo de Vantagens e Ralis",
    ru: "⚔️ 11. Боевая механика — Треугольник преимуществ и сборы",
    ar: "⚔️ 11. آليات المعركة — مثلث التفوق والحشود",
    ja: "⚔️ 11. 戦闘メカニクス — 三すくみ相性と集結・駐屯の鉄則",
    zh: "⚔️ 11. 战斗底层机制 — 克制三角、集结与驻防",
    it: "⚔️ 11. Meccaniche di Battaglia — Triangolo di Contrasto e Raduni",
    pl: "⚔️ 11. Mechanika Walki — Trójkąt Kontr, Rajdy i Garnizony"
  },
  kale: {
    tr: "🏰 12. Kale Savaşı (Sunfire Castle)",
    en: "🏰 12. Sunfire Castle Battle Rules",
    de: "🏰 12. Sonnfeuer-Schlosschlacht",
    fr: "🏰 12. Bataille du Château Sunfire",
    es: "🏰 12. Batalla del Castillo Sunfire",
    pt: "🏰 12. Batalha do Castelo Sunfire",
    ru: "🏰 12. Битва за замок Санфайр (Sunfire Castle)",
    ar: "🏰 12. معركة قلعة سان فاير (Sunfire Castle)",
    ja: "🏰 12. サンファイア城塞決戦 (Sunfire Castle)",
    zh: "🏰 12. 太阳城王城争夺战 (Sunfire Castle)",
    it: "🏰 12. Battaglia del Castello Sunfire",
    pl: "🏰 12. Bitwa o Zamek Sunfire"
  },
  "bear-trap": {
    tr: "🐻 13. Ayı Tuzağı (Bear Trap / Bear Hunt) — Eksiksiz Rehber",
    en: "🐻 13. Bear Trap / Bear Hunt — Master Guide",
    de: "🐻 13. Bärenfalle (Bear Hunt) — Meister-Leitfaden",
    fr: "🐻 13. Piège à Ours (Bear Hunt) — Guide Ultime",
    es: "🐻 13. Trampa de Oso (Bear Hunt) — Guía Maestra",
    pt: "🐻 13. Armadilha de Urso (Bear Hunt) — Guia Definitivo",
    ru: "🐻 13. Медвежья ловушка (Bear Trap) — Полное руководство",
    ar: "🐻 13. مصيدة الدب (Bear Trap) — الدليل الشامل",
    ja: "🐻 13. ベアトラップ（熊狩り）— 完全攻略極意",
    zh: "🐻 13. 猎熊陷阱 (Bear Trap) — 极限打桩终极全解",
    it: "🐻 13. Trappola dell'Orso — Guida Suprema",
    pl: "🐻 13. Pułapka na Niedźwiedzia — Kompletny Przewodnik"
  },
  uzmanlar: {
    tr: "🧑‍🔬 14. Uzmanlar (Experts) — F2P Öncelik Sırası",
    en: "🧑‍🔬 14. Dawn Academy Experts — F2P Priority Order",
    de: "🧑‍🔬 14. Experten der Dämmerungsakademie",
    fr: "🧑‍🔬 14. Experts de l'Académie de l'Aube",
    es: "🧑‍🔬 14. Expertos de la Academia del Alba",
    pt: "🧑‍🔬 14. Especialistas da Academia da Alvorada",
    ru: "🧑‍🔬 14. Эксперты Академии Рассвета — Порядок прокачки F2P",
    ar: "🧑‍🔬 14. خبراء أكاديمية الفجر — أولويات لاعبي F2P",
    ja: "🧑‍🔬 14. 暁のアカデミー・専門家育成優先度",
    zh: "🧑‍🔬 14. 黎明学院专家 — 平民F2P养成优先级",
    it: "🧑‍🔬 14. Esperti dell'Accademia dell'Alba",
    pl: "🧑‍🔬 14. Eksperci Akademii Świtu — Kolejność F2P"
  },
  evcil: {
    tr: "🐾 15. Evcil Hayvanlar (Pets) — Tier Listesi ve Öncelik",
    en: "🐾 15. Pets Tier List & Evolution Order",
    de: "🐾 15. Haustiere (Pets) — Rangliste & Prioritäten",
    fr: "🐾 15. Familiers — Tier List & Ordre d'Évolution",
    es: "🐾 15. Mascotas — Lista de Niveles y Prioridades",
    pt: "🐾 15. Mascotes — Tier List e Ordem de Evolução",
    ru: "🐾 15. Питомцы — Тир-лист и очередность развития",
    ar: "🐾 15. الحيوانات الأليفة — قائمة المستويات والأولويات",
    ja: "🐾 15. 巨獣(ペット) — ティア表と育成優先順位",
    zh: "🐾 15. 巨兽宠物系统 — 梯队排行与升级优先级",
    it: "🐾 15. Animali da Compagnia — Tier List e Priorità",
    pl: "🐾 15. Zwierzaki — Lista Poziomów i Priorytety"
  },
  etkinlikler: {
    tr: "📅 16. Etkinlik Takvimi",
    en: "📅 16. Event Calendar & Meta Strategies",
    de: "📅 16. Event-Kalender & Strategien",
    fr: "📅 16. Calendrier des Événements",
    es: "📅 16. Calendario de Eventos",
    pt: "📅 16. Calendário de Eventos",
    ru: "📅 16. Календарь событий и циклы активностей",
    ar: "📅 16. تقويم الفعاليات والأحداث",
    ja: "📅 16. 定期イベントカレンダーと攻略周期",
    zh: "📅 16. 循环活动日程表与备战节点",
    it: "📅 16. Calendario Eventi",
    pl: "📅 16. Kalendarz Wydarzeń i Strategie"
  },
  f2p: {
    tr: "💰 17. F2P vs P2W — Gerçek Zaman Çizelgesi",
    en: "💰 17. F2P vs P2W — Realistic Progression Timelines",
    de: "💰 17. F2P vs P2W — Realistische Zeitachsen",
    fr: "💰 17. F2P vs P2W — Délais de Progression Réalistes",
    es: "💰 17. F2P vs P2W — Líneas de Tiempo Reales",
    pt: "💰 17. F2P vs P2W — Linhas do Tempo Reais",
    ru: "💰 17. F2P против P2W — Реалистичные таймлайны",
    ar: "💰 17. مقارنة F2P ضد P2W — الجداول الزمنية الواقعية",
    ja: "💰 17. 無課金(F2P) vs 課金(P2W) — 到達時期の現実",
    zh: "💰 17. 零氪(F2P) 与 氪金(P2W) 真实发展时间线",
    it: "💰 17. F2P vs P2W — Tempistiche Realistiche",
    pl: "💰 17. F2P vs P2W — Realne Ramy Czasowe"
  },
  tuzaklar: {
    tr: "⚠️ 18. En Pahalı Tuzaklar",
    en: "⚠️ 18. The 10 Most Expensive Traps",
    de: "⚠️ 18. Die 10 Teuersten Fallen",
    fr: "⚠️ 18. Les 10 Pièges les Plus Coûteux",
    es: "⚠️ 18. Las 10 Trampas Más Caras",
    pt: "⚠️ 18. As 10 Armadilhas Mais Caras",
    ru: "⚠️ 18. Топ-10 самых дорогих ошибок",
    ar: "⚠️ 18. أغلى 10 أخطاء فادحة",
    ja: "⚠️ 18. 絶対に避けるべき「最大の罠」ワースト10",
    zh: "⚠️ 18. 代价惨重的 10 大避坑指南",
    it: "⚠️ 18. Le 10 Trappole Più Costose",
    pl: "⚠️ 18. 10 Najbardziej Kosztownych Pułapek"
  },
  kaynaklar: {
    tr: "📚 19. Kaynaklar",
    en: "📚 19. Community & Official References",
    de: "📚 19. Quellen & Verifizierung",
    fr: "📚 19. Sources et Vérification",
    es: "📚 19. Fuentes y Verificación",
    pt: "📚 19. Fontes e Verificação",
    ru: "📚 19. Источники и ссылки",
    ar: "📚 19. المصادر والمراجع المعتمدة",
    ja: "📚 19. 参考文献と検証情報元",
    zh: "📚 19. 资料来源与官方验证出处",
    it: "📚 19. Fonti e Riferimenti",
    pl: "📚 19. Źródła i Weryfikacja"
  }
};

let CURRENT_LANG = "tr";

// Function to trigger Google Translate when available
function triggerGoogleTranslate(targetLang) {
  let gLang = targetLang;
  if (targetLang === "zh") gLang = "zh-CN";

  // Set Google Translate cookie
  document.cookie = "googtrans=/tr/" + gLang + "; path=/";
  document.cookie = "googtrans=/tr/" + gLang + "; domain=" + window.location.hostname + "; path=/";

  const combo = document.querySelector(".goog-te-combo");
  if (combo) {
    combo.value = gLang;
    combo.dispatchEvent(new Event("change"));
  }
}

// Function to translate local DOM elements directly
function applyLocalTranslations(lang) {
  const conf = LANG_CONFIG[lang] || LANG_CONFIG.tr;

  // 1. Update HTML language and text direction
  document.getElementById("htmlRoot").lang = lang;
  if (conf.dir === "rtl") {
    document.body.setAttribute("dir", "rtl");
  } else {
    document.body.removeAttribute("dir");
  }

  // 2. Update search placeholder
  const searchInput = document.getElementById("globalSearch");
  if (searchInput) searchInput.placeholder = conf.searchPlaceholder;

  // 3. Update status badge
  const statusText = document.getElementById("transStatusText");
  if (statusText) statusText.textContent = conf.flag + " " + conf.status;

  // 4. Update TOC navigation links
  const tocLinks = document.querySelectorAll("#tocNav a");
  const navLabels = TOC_TRANSLATIONS[lang] || TOC_TRANSLATIONS.tr;
  tocLinks.forEach((link, idx) => {
    if (navLabels[idx]) {
      link.textContent = navLabels[idx];
    }
  });

  // 5. Update Section Titles
  Object.keys(SECTION_TITLES).forEach((secId) => {
    const sec = document.getElementById(secId);
    if (sec) {
      const h2 = sec.querySelector("h2");
      if (h2) {
        const titleData = SECTION_TITLES[secId];
        const newTitle = titleData[lang] || titleData.tr;
        h2.textContent = newTitle;
      }
    }
  });

  // 6. Trigger Google Translate for deep paragraphs, tables, and notices
  triggerGoogleTranslate(lang);
}

// Event listener for language select change
document.getElementById("langSelect").addEventListener("change", function () {
  CURRENT_LANG = this.value;
  applyLocalTranslations(CURRENT_LANG);
});

// Search input handler
document.getElementById("globalSearch").addEventListener("input", function () {
  const q = this.value.toLowerCase().trim();
  document.querySelectorAll("section").forEach((s) => {
    if (!q) {
      s.classList.remove("hidden");
      return;
    }
    s.classList.toggle("hidden", !s.textContent.toLowerCase().includes(q));
  });
});

// Table of Contents scrollspy
const secs = document.querySelectorAll("section[id]"), links = document.querySelectorAll("#tocNav a");
window.addEventListener("scroll", () => {
  let cur = "";
  secs.forEach((s) => {
    if (window.scrollY >= s.offsetTop - 150) cur = s.id;
  });
  links.forEach((l) => l.classList.toggle("active", l.getAttribute("href") === "#" + cur));
});

// Download button logic: creates a standalone HTML download of current page
const downloadBtn = document.getElementById("downloadHtmlBtn");
if (downloadBtn) {
  downloadBtn.addEventListener("click", () => {
    const blob = new Blob([document.documentElement.outerHTML], { type: "text/html;charset=utf-8" });
    const a = document.createElement("a");
    a.href = URL.createObjectURL(blob);
    a.download = "whiteout_survival_encyclopedia_" + CURRENT_LANG + ".html";
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
  });
}

// Auto-detect browser language if not Turkish
window.addEventListener("DOMContentLoaded", () => {
  const bl = (navigator.language || "tr").split("-")[0];
  const sup = Object.keys(LANG_CONFIG);
  if (sup.includes(bl) && bl !== "tr") {
    document.getElementById("langSelect").value = bl;
    applyLocalTranslations(bl);
  }
});
</script>
</body>
</html>`;

const finalHtml = modifiedHtml + newScript;

// Write back to the target file
fs.writeFileSync(htmlPath, finalHtml, 'utf8');
console.log('Successfully wrote updated HTML file. New size:', finalHtml.length);
