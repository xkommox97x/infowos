import React, { useState, useRef, useEffect } from 'react';
import {
  Download,
  ExternalLink,
  Languages,
  Swords,
  Sparkles,
  Flame,
  CheckCircle2,
  Maximize2
} from 'lucide-react';
import { SupportedLanguage } from './types';
import { TroopCalculatorModal } from './components/TroopCalculatorModal';
import { GearPlannerModal } from './components/GearPlannerModal';
import { BearTrapAssistantModal } from './components/BearTrapAssistantModal';

export default function App() {
  const [currentLang, setCurrentLang] = useState<SupportedLanguage>('tr');
  const [activeModal, setActiveModal] = useState<'troop' | 'gear' | 'bear' | null>(null);
  const iframeRef = useRef<HTMLIFrameElement>(null);

  const htmlUrl = '/assets/aistudio/deepseek_html_20261019_574f13_af3cbc3b.html';

  const languages: { code: SupportedLanguage; label: string; flag: string }[] = [
    { code: 'tr', label: 'Türkçe', flag: '🇹🇷' },
    { code: 'en', label: 'English', flag: '🇬🇧' },
    { code: 'de', label: 'Deutsch', flag: '🇩🇪' },
    { code: 'fr', label: 'Français', flag: '🇫🇷' },
    { code: 'es', label: 'Español', flag: '🇪🇸' },
    { code: 'pt', label: 'Português', flag: '🇵🇹' },
    { code: 'ru', label: 'Русский', flag: '🇷🇺' },
    { code: 'ar', label: 'العربية', flag: '🇸🇦' },
    { code: 'ja', label: '日本語', flag: '🇯🇵' },
    { code: 'zh', label: '简体中文', flag: '🇨🇳' },
    { code: 'it', label: 'Italiano', flag: '🇮🇹' },
    { code: 'pl', label: 'Polski', flag: '🇵🇱' },
  ];

  // Sync language selection into the embedded iframe
  const handleLanguageChange = (newLang: SupportedLanguage) => {
    setCurrentLang(newLang);
    try {
      const iframe = iframeRef.current;
      if (iframe && iframe.contentDocument) {
        const select = iframe.contentDocument.getElementById('langSelect') as HTMLSelectElement | null;
        if (select) {
          select.value = newLang;
          select.dispatchEvent(new Event('change'));
        }
      }
    } catch (e) {
      console.warn('Iframe sync notice:', e);
    }
  };

  // Listen to iframe language changes if user changes it inside the HTML directly
  useEffect(() => {
    const handleIframeLoad = () => {
      try {
        const iframe = iframeRef.current;
        if (iframe && iframe.contentDocument) {
          const select = iframe.contentDocument.getElementById('langSelect') as HTMLSelectElement | null;
          if (select) {
            select.addEventListener('change', () => {
              setCurrentLang(select.value as SupportedLanguage);
            });
          }
        }
      } catch (e) {
        // cross-origin catch
      }
    };

    const iframe = iframeRef.current;
    if (iframe) {
      iframe.addEventListener('load', handleIframeLoad);
    }
    return () => {
      if (iframe) {
        iframe.removeEventListener('load', handleIframeLoad);
      }
    };
  }, []);

  return (
    <div className="flex flex-col h-screen w-full bg-[#060d17] text-[#eaf1fa] overflow-hidden">
      {/* Top Utility Bar */}
      <header className="flex-shrink-0 bg-[#0d1727]/95 border-b border-[#1e3352] px-3 py-2 flex flex-wrap items-center justify-between gap-2 z-20 backdrop-blur-md">
        <div className="flex items-center gap-2.5">
          <div className="w-8 h-8 rounded-full bg-gradient-to-tr from-cyan-500 to-sky-300 flex items-center justify-center font-black text-black text-sm">
            ❄
          </div>
          <div>
            <h1 className="text-xs sm:text-sm font-bold text-[#b3e0f3] leading-tight flex items-center gap-2">
              <span>Whiteout Survival Ansiklopedisi</span>
              <span className="text-[10px] px-2 py-0.5 rounded-full bg-cyan-950 text-cyan-300 border border-cyan-800">
                12 Dil Destekli HTML
              </span>
            </h1>
            <p className="text-[10px] text-[#86a3c6] hidden sm:block">
              {currentLang === 'tr'
                ? 'Çeviriler doğrudan HTML dosyası içinde çalışacak şekilde yapılandırıldı'
                : 'Translations are executed directly inside the HTML file'}
            </p>
          </div>
        </div>

        {/* Controls */}
        <div className="flex items-center flex-wrap gap-2">
          {/* Language Selector */}
          <div className="flex items-center gap-1.5 bg-[#142136] px-2.5 py-1 rounded-xl border border-[#1e3352]">
            <Languages className="w-3.5 h-3.5 text-cyan-400" />
            <select
              value={currentLang}
              onChange={(e) => handleLanguageChange(e.target.value as SupportedLanguage)}
              aria-label="Dil Seçimi"
              className="bg-transparent text-xs text-[#eaf1fa] font-medium focus:outline-none cursor-pointer"
            >
              {languages.map((l) => (
                <option key={l.code} value={l.code} className="bg-[#0d1727] text-white">
                  {l.flag} {l.label}
                </option>
              ))}
            </select>
          </div>

          {/* Quick Calculators */}
          <button
            type="button"
            onClick={() => setActiveModal('troop')}
            className="px-2.5 py-1 rounded-xl bg-[#142136] hover:bg-[#1e3352] border border-[#1e3352] text-xs font-semibold text-cyan-300 flex items-center gap-1.5 transition-colors"
            title="Ordu Oran Hesaplayıcı"
          >
            <Swords className="w-3.5 h-3.5 text-cyan-400" />
            <span className="hidden md:inline">Ordu Hesaplayıcı</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveModal('gear')}
            className="px-2.5 py-1 rounded-xl bg-[#142136] hover:bg-[#1e3352] border border-[#1e3352] text-xs font-semibold text-amber-300 flex items-center gap-1.5 transition-colors"
            title="Hero Gear Planlayıcı"
          >
            <Sparkles className="w-3.5 h-3.5 text-amber-400" />
            <span className="hidden md:inline">Hero Gear</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveModal('bear')}
            className="px-2.5 py-1 rounded-xl bg-[#142136] hover:bg-[#1e3352] border border-[#1e3352] text-xs font-semibold text-red-300 flex items-center gap-1.5 transition-colors"
            title="Ayı Tuzağı Rehberi"
          >
            <Flame className="w-3.5 h-3.5 text-red-400" />
            <span className="hidden md:inline">Ayı Tuzağı</span>
          </button>

          {/* Direct HTML Download */}
          <a
            href={htmlUrl}
            download={`whiteout_survival_encyclopedia_${currentLang}.html`}
            className="px-3 py-1 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-black text-xs font-bold flex items-center gap-1.5 transition-colors shadow-sm"
            title="Düzeltilmiş HTML Dosyasını İndir"
          >
            <Download className="w-3.5 h-3.5" />
            <span>HTML İndir</span>
          </a>

          {/* Open in New Tab */}
          <a
            href={htmlUrl}
            target="_blank"
            rel="noopener noreferrer"
            className="p-1.5 rounded-xl bg-[#142136] hover:bg-[#1e3352] border border-[#1e3352] text-gray-300 hover:text-white transition-colors"
            title="Bağımsız HTML Dosyasını Yeni Sekmede Aç"
          >
            <ExternalLink className="w-3.5 h-3.5" />
          </a>
        </div>
      </header>

      {/* Main Full-Height HTML Document Viewport */}
      <main className="flex-1 w-full h-full relative overflow-hidden bg-[#060d17]">
        <iframe
          ref={iframeRef}
          src={htmlUrl}
          className="w-full h-full border-none"
          title="Whiteout Survival Ultimate Encyclopedia"
        />
      </main>

      {/* Interactive Modals */}
      <TroopCalculatorModal
        isOpen={activeModal === 'troop'}
        onClose={() => setActiveModal(null)}
        lang={currentLang}
      />

      <GearPlannerModal
        isOpen={activeModal === 'gear'}
        onClose={() => setActiveModal(null)}
        lang={currentLang}
      />

      <BearTrapAssistantModal
        isOpen={activeModal === 'bear'}
        onClose={() => setActiveModal(null)}
        lang={currentLang}
      />
    </div>
  );
}
