export type SupportedLanguage =
  | 'tr'
  | 'en'
  | 'de'
  | 'fr'
  | 'es'
  | 'pt'
  | 'ru'
  | 'ar'
  | 'ja'
  | 'zh'
  | 'it'
  | 'pl';

export interface LanguageInfo {
  code: SupportedLanguage;
  name: string;
  nativeName: string;
  flag: string;
  dir: 'ltr' | 'rtl';
}

export interface SummaryCard {
  title: string;
  desc: string;
  tag?: string;
  tagType?: 'inf' | 'lan' | 'mar' | 'warn' | 'ok' | 'bad';
}

export interface NoticeBox {
  type: 'info' | 'warn' | 'danger' | 'ok';
  title?: string;
  content: string;
  bullets?: string[];
}

export interface TableData {
  title?: string;
  headers: string[];
  rows: (string | number)[][];
  note?: string;
}

export interface PriorityList {
  title: string;
  items: string[];
  note?: string;
}

export interface SectionContent {
  id: string;
  number: number;
  navLabel: string;
  title: string;
  subtitle: string;
  badge?: {
    text: string;
    type: 'ok' | 'warn' | 'bad';
  };
  cards?: SummaryCard[];
  notices?: NoticeBox[];
  tables?: TableData[];
  priorityBox?: PriorityList;
  svgType?: 'empowerment' | 'helios-chain' | 'counter-triangle' | 'sunfire-timeline' | 'bear-trap-keys';
  subsections?: {
    title: string;
    content?: string;
    notices?: NoticeBox[];
    tables?: TableData[];
    priorityBox?: PriorityList;
    cards?: SummaryCard[];
  }[];
}

export interface TranslationDictionary {
  appName: string;
  tagline: string;
  searchPlaceholder: string;
  languageSelectLabel: string;
  quickTools: string;
  troopCalc: string;
  gearCalc: string;
  bearTrapAssistant: string;
  aiAdvisor: string;
  viewMode: string;
  normalView: string;
  dualView: string;
  standaloneHtml: string;
  downloadHtml: string;
  copyLink: string;
  copied: string;
  sectionsCount: string;
  searchNoResults: string;
  clearSearch: string;
  sections: Record<string, SectionContent>;
  calcTitles: {
    troopCalcTitle: string;
    gearCalcTitle: string;
    bearAssistantTitle: string;
    aiStrategistTitle: string;
  };
}
