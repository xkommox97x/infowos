import { SectionContent } from '../types';

export const SECTIONS_EN: Record<string, SectionContent> = {
  baslangic: {
    id: 'baslangic',
    number: 1,
    navLabel: 'Getting Started',
    title: '🚀 1. Getting Started — First 30 Days & F2P Roadmap',
    subtitle: 'The first month of the game defines the trajectory of your account.',
    badge: { text: '✅ Verified', type: 'ok' },
    cards: [
      {
        title: '🏁 Server Selection',
        desc: 'Old servers are dominated by established alliances. Join a brand-new server. Missing new server launch events cannot be compensated.',
      },
      {
        title: '🤝 Join an Alliance Immediately',
        desc: 'Join an active alliance on Day 1. Alliance help, rallies, and resource chests scale exponentially in the early game.',
      },
      {
        title: '🎯 First 30 Days Goal',
        desc: 'Furnace 18 + VIP 6. For F2P players, Infantry Health research must prioritize over all other combat stats in the early game.',
      },
    ],
    notices: [
      {
        type: 'info',
        title: 'F2P Roadmap (WSCO Data):',
        content: '',
        bullets: [
          'Days 0–14: Furnace 19–22; join one of top 3 alliances. Gen 1 heroes, Arena, Tundra unlock.',
          'Days 25–54: Furnace 25–27; Labyrinth, Daybreak Island, Sunfire, Pets Gen 1 unlock. First pet: Arctic Wolf.',
          'Days 60–120: FC1–FC2; Fire Crystal era begins, SvS/KoI, Gen 3 heroes. Bank resources for first SvS prep phase.',
          'Furnace 30: F2P ~Day 55–65; €10/mo ~Day 50; €50/mo ~Day 40–45; Whale ~Day 35.',
        ],
      },
      {
        type: 'warn',
        title: 'Top 3 Early Game Mistakes:',
        content: '',
        bullets: [
          'Upgrading every building equally. You will hit a severe wall between Furnace 20–25.',
          'Wasting speedups randomly. Save them strictly for events or critical gate bottlenecks.',
          'Joining an alliance late. Alliance helps and gifts provide the majority of early acceleration.',
        ],
      },
    ],
  },

  firin: {
    id: 'firin',
    number: 2,
    navLabel: 'Furnace',
    title: '🏰 2. Furnace & City Development',
    subtitle: 'The Furnace is the beating heart of your settlement.',
    badge: { text: '✅ Verified', type: 'ok' },
    tables: [
      {
        title: 'Building Upgrade Priority',
        headers: ['Order', 'Building', 'Why?'],
        rows: [
          ['1', 'Furnace', 'Gates virtually every system; if it pauses, account progression halts.'],
          ['2', 'Embassy', 'Reinforcement and rally slots; accelerates alliance help capacity.'],
          ['3', 'Research Center', 'Permanent long-term multipliers; should not lag >3 levels behind Furnace.'],
          ['4', 'Troop Camps', 'Military backbone; keep close to Furnace level to unlock troop tiers.'],
          ['5', 'Infirmary', 'Hospital capacity; prevents permanent troop loss in defensive warfare.'],
          ['6', 'Resource Nodes', 'Keep at minimal requirements; prioritize Furnace and military first.'],
        ],
      },
      {
        title: 'Key Milestones Unlocked by Furnace Level',
        headers: ['Furnace Level', 'Unlocked System / Feature'],
        rows: [
          ['Lv.9', 'Research Center unlocks.'],
          ['Lv.15', 'Hero Gear unlocks.'],
          ['Lv.18', 'Pets unlock (Beast Cage; ~Day 55–60).'],
          ['Lv.19', 'Labyrinth unlocks.'],
          ['Lv.20', 'Mastery Forging unlocks.'],
          ['Lv.22', 'Chief Gear unlocks.'],
          ['Lv.25', 'Chief Charms unlock.'],
          ['Lv.30', 'Classic cap; Fire Crystal (FC) Era (~Day 60) begins.'],
        ],
      },
    ],
  },

  arastirma: {
    id: 'arastirma',
    number: 3,
    navLabel: 'Research',
    title: '🔬 3. Research Center Prioritization',
    subtitle: 'Single-queued; keep it running 24/7 without idle gaps.',
    tables: [
      {
        headers: ['Phase', 'Furnace', 'Distribution', 'Priority Nodes'],
        rows: [
          ['1. Foundation', '9–15', '60% Eco / 30% Growth / 10% Battle', 'Tool Enhancement (research speed) → Tooling Up (construction speed) → Command Tactics (march queue).'],
          ['2. Acceleration', '15–26', '40% Growth / 35% Eco / 25% Battle', 'Gathering Speed, March Queue, Regimental Expansion.'],
          ['3. Specialization', '26+', '45% Battle / 30% Growth / 25% Eco', 'Percentage-based battle stats; align with highest troop tier.'],
        ],
      },
    ],
    notices: [
      {
        type: 'danger',
        title: 'Furnace Gatekeeper Rule:',
        content: 'If the upcoming Furnace level demands a specific research node, that node is Priority 1. Letting Research lag 3+ levels behind Furnace completely blocks your progression.',
      },
    ],
  },

  kahramanlar: {
    id: 'kahramanlar',
    number: 4,
    navLabel: 'Heroes',
    title: '🦸 4. Hero Encyclopedia & Generation Trap',
    subtitle: 'Newest generation is not automatically superior. 5-star older gen > 1-star newer gen.',
    badge: { text: '⚠️ Skill values may vary', type: 'warn' },
    tables: [
      {
        headers: ['Generation', 'Priority Hero(es)', 'Strategic Role'],
        rows: [
          ['Gen 1', 'Molly, Jeronimo', 'Molly: AoE burst + freeze control. Jeronimo: premier Bear Trap rally leader.'],
          ['Gen 2', 'Flint, Alonso', 'Flint: F2P friendly tank (Lucky Wheel); front row till Gen 5. Alonso: sniper burst.'],
          ['Gen 3', 'Mia', 'Indispensable Bear Trap specialist; exclusive weapon boosts rally damage.'],
          ['Gen 5', 'Hector', 'Infantry tank; direct F2P successor to Flint.'],
          ['Gen 8', 'Gatot', 'Premier late-game frontline infantry tank.'],
          ['Gen 10+', 'Blanche, Rufus, Karol', 'Top tier damage dealers matching exclusive gear priorities.'],
        ],
      },
    ],
    cards: [
      { title: 'Level & EXP', desc: 'Increases core stats. R/SR heroes are transitional; save books for SSR.' },
      { title: 'Stars & Shards', desc: 'General mythic shards are scarce; conserve in Gen 1-4, invest heavily from Gen 5 onward.' },
      { title: 'Skill Upgrades', desc: 'Expedition and Exploration skill sets govern distinct battle arenas.' },
      { title: 'Exclusive Gear', desc: 'Reserve exclusive gear widgets strictly for evergreen staples like Jeronimo and Mia.' },
    ],
    notices: [
      {
        type: 'warn',
        title: 'Conserve Shards Rule:',
        content: 'Spend generic orange shards sparingly during the first 4 generations. Bank the majority for Gen 5+. Invest in evergreen heroes: Molly, Flint, Mia, Hector, Jeronimo.',
      },
    ],
  },

  'hero-gear': {
    id: 'hero-gear',
    number: 5,
    navLabel: 'Hero Gear',
    title: '⚔️ 5. Hero Gear — Empowerment (+20 → +60 → +100)',
    subtitle: 'Unlocks at Furnace 15. 3 troop types × 4 slots = 12 pieces. Each slot follows a unique empowerment growth curve.',
    badge: { text: '✅ Verified Curve', type: 'ok' },
    svgType: 'empowerment',
    subsections: [
      {
        title: '5.1 True Empowerment Bonus Matrix',
        notices: [
          {
            type: 'warn',
            title: 'Critical Correction:',
            content: 'The old assumption that "Belt & Gloves = Health, Goggles & Boots = Lethality" is incomplete. Empowerment bonuses follow slot-specific growth paths.',
          },
        ],
        tables: [
          {
            headers: ['Gear Group', '+20', '+40', '+60', '+80', '+100'],
            rows: [
              ['Gloves & Boots (Defensive Line)', 'Defense +20%', 'Health +7.5%', 'Attack +30%', 'Hero Attack +15%', 'Defense +50%'],
              ['Goggles & Belt (Offensive Line)', 'Attack +20%', 'Health +7.5%', 'Defense +30%', 'Hero Attack +15%', 'Attack +50%'],
            ],
            note: 'Verified from 9game.cn Infantry handbook: Gloves & Boots award +50% Troop Defense at Level 100.',
          },
        ],
      },
      {
        title: '5.2 What is +19?',
        notices: [
          {
            type: 'info',
            title: 'The +19 Ceiling',
            content: 'Level 19 is the final non-empowered stage of legendary gear. No Mithril is consumed up to +19. The jump from +19 to +20 is the first true Empowerment threshold requiring Mithril.',
          },
        ],
      },
      {
        title: '5.3 Cumulative Upgrade Costs',
        tables: [
          {
            headers: ['Threshold', 'Step Mithril', 'Step Mythic', 'Total Mithril', 'Total Mythic', 'Stat Benefit'],
            rows: [
              ['+19', '0', '0', '0', '0', 'Final non-empowered level.'],
              ['+20', '10', '3', '10', '3', 'First Empowerment: +20% Defense or Attack depending on piece.'],
              ['+40', '20', '5', '30', '8', 'Health +7.5% across both groups.'],
              ['+60', '30', '5', '60', '13', 'Gloves/Boots: Attack +30%; Goggles/Belt: Defense +30%.'],
              ['+80', '40', '10', '100', '23', 'Hero Attack +15%.'],
              ['+100', '50', '10', '150', '33', 'Gloves/Boots: Defense +50%; Goggles/Belt: Attack +50%.'],
            ],
            note: 'Taking 1 piece from +19 to +100 requires 150 Mithril + 33 Mythic gear pieces. A full 6-piece loadout ≈ 900 Mithril.',
          },
        ],
      },
      {
        title: '5.4 True Priority Order: +20 → +60 → +100',
        notices: [
          {
            type: 'danger',
            title: 'Why Skip +40 and +80?',
            content: 'Mithril is the bottleneck resource for F2P players. +40 only gives +7.5% Health and +80 gives +15% Hero Attack. Stopping at these intermediary checkpoints delays massive troop multipliers (+20, +60, +100). Reach +20 first, push directly to +60, then rush +100.',
          },
        ],
        priorityBox: {
          title: '🛡️ Infantry Priority — Defense First',
          items: [
            '1. Gloves +20 → Defense +20%. Spend your first 10 Mithril here.',
            '2. Belt +60 → Defense +30%. Belt provides Defense at +60. Level Belt to +60 before pushing Gloves to +60.',
            '3. Gloves +100 → Defense +50%. The single largest defense milestone in the game.',
          ],
          note: 'Consciously bypass Belt +20 (Attack) and Belt +100 (Attack) on Infantry to avoid wasting precious Mithril.',
        },
      },
    ],
  },

  'chief-gear': {
    id: 'chief-gear',
    number: 6,
    navLabel: 'Chief Gear',
    title: '🛡️ 6. Chief Gear — Set Bonus Rules',
    subtitle: 'Unlocks at Furnace 22. 6 pieces applying stat buffs across all marches.',
    badge: { text: '✅ Verified', type: 'ok' },
    tables: [
      {
        headers: ['Piece Category', 'Equipment Pieces', 'Buffed Troop Type', 'Priority'],
        rows: [
          ['Torso', 'Coat, Pants', 'Infantry', '1 (Highest)'],
          ['Hand', 'Belt, Weapon', 'Marksman', '2 (Secondary)'],
          ['Head & Wrist', 'Cap, Watch', 'Lancer', '3 (Tertiary)'],
        ],
      },
    ],
    notices: [
      {
        type: 'danger',
        title: 'Set bonus defaults to your lowest quality item!',
        content: 'Equipping 5 Gold items and 1 Purple item will downgrade your set bonus to Purple T1 across all 6 pieces! Never hyper-focus on a single item; upgrade all 6 pieces evenly.',
      },
      {
        type: 'info',
        title: '3-Piece & 6-Piece Thresholds:',
        content: '3 items of identical grade grant an army-wide Defense bonus; 6 items unlock an army-wide Attack bonus that stacks with the 3-piece bonus.',
      },
    ],
  },

  'chief-charms': {
    id: 'chief-charms',
    number: 7,
    navLabel: 'Chief Charms',
    title: '💎 7. Chief Charms — Lv.11 Threshold & 40:1 Exchange',
    subtitle: 'Unlocks at Furnace 25. 6 gear slots × 3 slots = 18 charms total.',
    badge: { text: '✅ Verified', type: 'ok' },
    priorityBox: {
      title: 'Two-Stage Progression Path',
      items: [
        '1. Raise all 18 charms to Lv.11 first. This unlocks Charm Materials Exchange and consumes zero Jewel Secrets.',
        '2. Only then push primary troop charms to Lv.12+. Jewel Secrets are exclusively required from this point onward.',
      ],
      note: 'Always prioritize Gear before Charms; Charm multiplier stats compound upon base gear numbers.',
    },
    notices: [
      {
        type: 'warn',
        title: '40:1 Conversion Ratio:',
        content: 'After Lv.11, 40 Charm Guides or 40 Charm Designs convert to 1 Jewel Secret. Upgrading a charm strictly via conversion to Lv.16 costs ≈ 10,400 guides/designs.',
      },
      {
        type: 'info',
        title: 'SvS Scoring Window:',
        content: 'Charm upgrades grant massive points during SvS Prep and King of Icefield. Hoard your upgrade materials strictly for these events.',
      },
    ],
  },

  helios: {
    id: 'helios',
    number: 8,
    navLabel: 'Helios T11',
    title: '🌟 8. Helios T11 — The Late-Game Gate',
    subtitle: 'Researched via War Academy and mandatory prerequisite for T12 Exalted troops.',
    badge: { text: '✅ Verified', type: 'ok' },
    svgType: 'helios-chain',
    tables: [
      {
        headers: ['Troop Type', 'Battlefield Role', 'Prime Use-Case', 'Unlock Priority'],
        rows: [
          ['Helios Infantry', 'Frontline meatshield, garrison defender', 'Damage sponge in SvS rallies and Sunfire defense', '1 (F2P Top Pick)'],
          ['Helios Marksman', 'Backline damage dealer, rally cannon', 'Bear Hunt burst and high-score PvE events', '2'],
          ['Helios Lancer', 'Marksman flanker, situational counter', 'Targeted counter-rallies against marksman heavy lines', '3'],
        ],
      },
      {
        title: 'Total Costs for One Full Helios Branch',
        headers: ['Resource Requirement', 'Amount'],
        rows: [
          ['Fire Crystal Shards', '~13,400 Shards'],
          ['Meat / Wood', '246,180,000 / 246,180,000'],
          ['Coal / Iron / Steel', '49,116,000 / 12,196,000 / 3,974,000'],
          ['Base Research Duration', '~271 days (~159 days with ~70% speed buff)'],
        ],
      },
    ],
    notices: [
      {
        type: 'warn',
        title: 'FC vs Shard Distinction:',
        content: 'Buildings consume Fire Crystals (FC); research branches consume Fire Crystal Shards. Do not prematurely convert FCs to Shards because the War Academy building itself requires FC5. Conversion rate: 10 FC → 13 Shards (daily cap of 2,600 Shards).',
      },
    ],
  },

  'helios-oranlar': {
    id: 'helios-oranlar',
    number: 9,
    navLabel: 'Helios 1st Army',
    title: '🎯 9. Helios T11 — 1st Army Compositions',
    subtitle: 'Optimized troop ratios based on your unlocked Helios types and tactical role.',
    badge: { text: '✅ Tested Ratios', type: 'ok' },
    notices: [
      {
        type: 'warn',
        title: 'Mixed Tier Rule:',
        content: 'These ratios account for a mix of Helios T11 and standard T10 units. If your 1st march is 100% Helios, switch to aggressive attack spreads such as 40/20/40. In defense, always keep the frontline beefy.',
      },
    ],
    tables: [
      {
        headers: ['Your Helios Setup', 'Tactical Role', '1st Army (Standard)', '1st Army (Alternative)', 'Rationale'],
        rows: [
          ['Helios Infantry Only', 'Attack', '50 / 25 / 25', '55 / 20 / 25', 'Anchors the front row with Helios Infantry while T10 DPS units deal uninterrupted damage.'],
          ['Helios Infantry Only', 'Defense', '70 / 15 / 15', '75 / 10 / 15', 'Survivability is paramount in defense. Helios Infantry + T10 backline outlasts pure T10 by several rounds.'],
          ['Helios Lancer Only', 'Attack', '40 / 35 / 25', '35 / 40 / 25', 'Helios Lancers shred marksman squads. Boost Lancer to 40% if enemy stacks archers.'],
          ['Helios Lancer Only', 'Defense', '55 / 30 / 15', '50 / 35 / 15', 'Lancers serve as a mid-row buffer while T10 infantry holds the line.'],
          ['Helios Marksman Only', 'Attack', '35 / 15 / 50', '30 / 15 / 55', 'Maximum DPS ceiling. If noticeably stronger than opponent, push Marksman to 55%.'],
          ['Helios Marksman Only', 'Defense', '55 / 15 / 30', '60 / 15 / 25', 'Marksmen are glass cannons; reduce archers on defense in favor of infantry.'],
          ['Helios Infantry + Marksman', 'Attack', '45 / 15 / 40', '40 / 15 / 45', 'The gold standard offensive duo. Minimizes fragile lancers.'],
          ['Helios Infantry + Marksman', 'Defense', '65 / 15 / 20', '70 / 15 / 15', 'Frontline saturation allows backline marksmen to fire safely.'],
          ['Helios Infantry + Lancer', 'Attack', '50 / 30 / 20', '45 / 35 / 20', 'Extremely resilient offensive march.'],
          ['Helios Infantry + Lancer', 'Defense', '65 / 25 / 10', '70 / 25 / 5', 'Unbreakable defensive bunker for Sunfire Castle or fortress holds.'],
          ['All 3 Helios Unlocked', 'Attack', '45 / 20 / 35', '40 / 20 / 40', 'Balanced and devastating full-Helios strike force.'],
          ['All 3 Helios Unlocked', 'Defense', '60 / 25 / 15', '65 / 20 / 15', 'Yields the longest possible defensive hold duration.'],
        ],
      },
    ],
  },

  'ordu-oranlari': {
    id: 'ordu-oranlari',
    number: 10,
    navLabel: 'General Troop Ratios',
    title: '🎯 10. General Troop Ratios — Mode Specific',
    subtitle: 'Standard troop compositions independent of Helios unlocks.',
    badge: { text: '✅ Meta Standards', type: 'ok' },
    tables: [
      {
        headers: ['Mode / Scenario', '1st Army', '2nd Army', '3rd Army', 'Reasoning'],
        rows: [
          ['Balanced / Open Field', '50/20/30', '60/20/20', '40/20/40', 'Army 1 handles skirmishes; Army 2 soaks damage; Army 3 delivers heavy punishment.'],
          ['Garrison / Defense', '60/20/20', '60/30/10', '50/20/30', 'High infantry ratio buffers incoming rally damage.'],
          ['Bear Trap (Bear Hunt)', '10/10/80', '10/10/80', '10/10/80', 'Pure marksman stacking. Always maintain a minimum of 5,000 infantry!'],
          ['Crazy Joe', '90/10/0', '90/10/0', '90/10/0', 'Near-pure frontline to safeguard barricades and avoid backline breaches.'],
          ['Labyrinth — Single March', '55/17/28 or 45/20/35', '—', '—', 'Tune ±5% depending on daily dungeon buff zones.'],
          ['Labyrinth — 3 Marches', '60/40/0', '54/3/43', '50/20/30', 'Tiered F2P progression splits.'],
        ],
      },
    ],
  },

  savas: {
    id: 'savas',
    number: 11,
    navLabel: 'Battle Mechanics',
    title: '⚔️ 11. Battle Mechanics — Counter Triangle, Rallies & Garrisons',
    subtitle: 'Rock-paper-scissors: Infantry > Lancer > Marksman > Infantry. Massive stat superiority can overwhelm the triangle.',
    badge: { text: '✅ Verified', type: 'ok' },
    svgType: 'counter-triangle',
    cards: [
      {
        title: '🎯 Rally Leader (Captain)',
        desc: 'All 9 Expedition skills (3 heroes × 3 skills) enter combat. Demands high overall stats, maximum rally capacity, and awakened heroes. Staples: Jeronimo, Mia.',
      },
      {
        title: '👥 Rally Joiner',
        desc: 'Only the 1st Expedition skill of the leftmost hero takes effect in combat. A maximum of 4 joiner skills activate per rally. Use Jessie, Jasser, or Seo-yoon in Slot 1.',
      },
    ],
    notices: [
      {
        type: 'danger',
        title: 'Costliest Mistake:',
        content: 'Placing defensive heroes (Patrick, Sergey) in Slot 1 of an offensive rally, or bringing non-combat heroes (Gina) to Bear Trap. This steals a slot from another player and cripples damage output.',
      },
    ],
  },

  kale: {
    id: 'kale',
    number: 12,
    navLabel: 'Sunfire Castle',
    title: '🏰 12. Sunfire Castle Battle Rules',
    subtitle: 'Held consecutively for 2.5 hours in a 5-hour window grants instant victory; otherwise the longest cumulative holding time wins.',
    badge: { text: '✅ Official Rule', type: 'ok' },
    svgType: 'sunfire-timeline',
    cards: [
      {
        title: '🛡️ Defensive Protocol',
        desc: 'Ratio: 60% Infantry / 20% Lancer / 20% Marksman. Slot 1: Patrick, Sergey. Alliance members must maintain constant reinforcement trickles. Control turrets.',
      },
      {
        title: '⚔️ Offensive Protocol',
        desc: 'Double rallies break entrenched garrisons. Slot 1: Jessie or Jasser. Recapturing before 14:30 UTC resets the enemy consecutive countdown timer.',
      },
    ],
  },

  'bear-trap': {
    id: 'bear-trap',
    number: 13,
    navLabel: 'Bear Trap',
    title: '🐻 13. Bear Trap / Bear Hunt — Master Guide',
    subtitle: 'Opens every ~48 hours; lasts 30 minutes. Troops do not die; objective is maximum total score.',
    badge: { text: '✅ Verified', type: 'ok' },
    svgType: 'bear-trap-keys',
    subsections: [
      {
        title: '13.1 Core Mechanic: Why Only Slot 1 Matters',
        notices: [
          {
            type: 'info',
            title: 'Joiner Mechanic',
            content: 'As a joiner, only the top-right Expedition skill of your leftmost hero contributes to the rally. The other 2 heroes contribute purely troop capacity. Exactly 4 joiner skills can be active in a single rally.',
          },
        ],
      },
      {
        title: '13.2 Ideal Rally Joiner Heroes',
        tables: [
          {
            headers: ['Hero', 'Gen', '1st Expedition Skill', 'Combat Impact'],
            rows: [
              ['Jessie', 'Gen 1', 'Stand of Arms', 'Boosts all damage dealt by all troops +5% → +25% (Lv.5).'],
              ['Jasser', 'Gen 1', 'Technical Genius', 'Boosts damage dealt by all troops up to +25%.'],
              ['Seo-yoon', 'Gen 1', 'Conquest Drum', 'Flat attack buff for all deployed units.'],
              ['Jeronimo', 'Gen 1', 'Rallying Cry', 'All troop damage +25% (Paywalled staple).'],
              ['Gwen', 'Gen 5', 'Eagle Vision', 'Controversial: "Damage Taken" debuff theoretically helps but tested non-functional by many top alliances.'],
              ['Reina', 'Gen 4', '—', '+25% attack/damage buff.'],
            ],
          },
        ],
      },
      {
        title: '13.3 The Great Gwen Debate',
        cards: [
          {
            title: '✅ Pro-Gwen Arguments',
            desc: 'Eagle Vision inflicts a 25% Damage Taken debuff. Gwen is the highest DPS marksman of Gen 5 and exceptional as a rally leader.',
            tag: 'Proponent',
            tagType: 'ok',
          },
          {
            title: '❌ Anti-Gwen Arguments',
            desc: 'The Bear does not take real damage; score is purely recorded accumulated damage. Debuffs on the target fail to trigger properly compared to raw army Attack buffs like Jessie/Jasser.',
            tag: 'Opponent',
            tagType: 'bad',
          },
        ],
        notices: [
          {
            type: 'danger',
            title: 'Balanced Verdict:',
            content: 'As a joiner, do NOT send Gwen in Slot 1! Stick to Jessie, Jasser, or Seo-yoon. As a rally captain/leader, Gwen is outstanding and fully recommended.',
          },
        ],
      },
    ],
  },

  uzmanlar: {
    id: 'uzmanlar',
    number: 14,
    navLabel: 'Experts',
    title: '🧑‍🔬 14. Dawn Academy Experts — F2P Priority Order',
    subtitle: 'Unlocked via Dawn Academy. F2P players should prioritize economic output and daily task gains.',
    badge: { text: '✅ Verified', type: 'ok' },
    tables: [
      {
        headers: ['Priority', 'Expert', 'Strategic Value', 'Target Stopping Point'],
        rows: [
          ['1', 'Agnes', 'F2P workhorse: extra Intel quests (+8/day), Mystery Badges (+120/day), stamina & build discounts.', 'Affinity 70 (early 30→60→100).'],
          ['2', 'Cyrille', 'Bear Trap specialist; expands rally capacity and multiplies hunt rewards.', 'Affinity 60.'],
          ['3', 'Baldur', 'Boosts recurring alliance event payouts.', 'Situational.'],
          ['4', 'Romulus', 'Military advisor providing raw combat stat bumps.', 'Situational.'],
          ['5', 'Holger', 'Specialized progression advisor tailored for Arena dominance.', 'If climbing Arena ranks.'],
        ],
      },
    ],
  },

  evcil: {
    id: 'evcil',
    number: 15,
    navLabel: 'Pets',
    title: '🐾 15. Pets Tier List & Evolution Order',
    subtitle: 'Unlocked at Furnace 18 via the Beast Cage (~Days 55–60).',
    badge: { text: '✅ Verified', type: 'ok' },
    tables: [
      {
        headers: ['Tier', 'Pets', 'Battlefield Utility & Value'],
        rows: [
          ['S', 'Iron Rhino, Saber-tooth Tiger, Cave Lion, Snow Ape, Frost Gorilla', 'Iron Rhino expands rally capacity by +60k to 150k. Essential for rally captains.'],
          ['A', 'Mammoth, Snow Leopard, Titan Roc', 'Tactical combat support in specialized engagements.'],
          ['B', 'Cave Hyena, Musk Ox, Arctic Wolf, Giant Tapir, Giant Elk', 'Development & farming: Cave Hyena cuts build timers; Arctic Wolf restores stamina; Musk Ox instant gathers.'],
        ],
      },
    ],
    notices: [
      {
        type: 'info',
        title: 'Early Game Evolution Order:',
        content: 'Cave Hyena (construction speed) → Arctic Wolf (stamina regen) → Musk Ox (instant gathering). In the late game, shift focus to Iron Rhino and Cave Lion.',
      },
    ],
  },

  etkinlikler: {
    id: 'etkinlikler',
    number: 16,
    navLabel: 'Events',
    title: '📅 16. Event Calendar & Meta Strategies',
    subtitle: 'Event recurrence frequency and optimal preparation methods.',
    badge: { text: '✅ Verified', type: 'ok' },
    tables: [
      {
        headers: ['Event', 'Frequency', 'Key Operational Rule'],
        rows: [
          ['Bear Trap (Bear Hunt)', '~Every 48 Hours', 'PvE; zero troop losses. Arrowhead trap buffs must be recharged before every hunt.'],
          ['Alliance Championship', 'Weekly', 'Never use the default 33/33/33 split; maintain at least 50% Infantry.'],
          ['Fortress Battles', 'Every Friday', 'Alliance territorial PvP; 2-hour window, 30-min continuous control needed.'],
          ['Frostfire Mine', 'Bi-Weekly', 'Solo PvP; 30 minutes; collect Orichalcum nodes.'],
          ['Foundry Battle', 'Bi-Weekly', 'Alliance battlefield; pre-assign roles for buildings and teleports.'],
          ['SvS / King of Icefield', 'Monthly', '5-day prep phase + battle day. Castle unlocks at Hour 2 of battle phase.'],
          ['Crazy Joe', 'Monthly', '21 waves; be online for waves 7, 14, 17. Run 90% Infantry.'],
          ['Alliance Mobilization', 'Monthly', 'R4/R5 leadership must refresh completed quests every 30 minutes.'],
        ],
      },
    ],
  },

  f2p: {
    id: 'f2p',
    number: 17,
    navLabel: 'F2P vs P2W',
    title: '💰 17. F2P vs P2W — Realistic Progression Timelines',
    subtitle: 'The only true difference is velocity. Spending buys time, not exclusive content.',
    badge: { text: '✅ WSCO Benchmark', type: 'ok' },
    tables: [
      {
        headers: ['Milestone', '€0 (F2P)', '~€10/mo', '~€50/mo', 'Whale'],
        rows: [
          ['Furnace 30', '~Day 55–65', '~Day 50', '~Day 40–45', '~Day 35'],
          ['FC5', '~Day 200–240', '~Day 180', '~Day 150', '~Day 110'],
          ['T11 Troops', '~Day 240–280', '~Day 210', '~Day 170', '~Day 120'],
          ['Legendary Chief Gear', '~Day 220–260', '~Day 190', '~Day 150', '~Day 100'],
          ['FC10 / Full Path', '~Day 550–650', '~Day 450', '~Day 340', '~Day 220'],
        ],
      },
    ],
    notices: [
      {
        type: 'info',
        title: 'The €10/Month Sweet Spot:',
        content: 'Growth Fund + Monthly Card acquires permanent account infrastructure. Beyond that, packs purchase speed. A disciplined F2P player can catch sporadic spenders within 12 months.',
      },
    ],
  },

  tuzaklar: {
    id: 'tuzaklar',
    number: 18,
    navLabel: 'Costly Traps',
    title: '⚠️ 18. The 10 Most Expensive Traps',
    subtitle: 'These common blunders cost players months of wasted progress.',
    badge: { text: 'Critical Warnings', type: 'bad' },
    cards: [
      { title: '1. Breaking Set Bonuses', desc: 'Over-leveling 1 piece of Chief Gear. The set bonus is dictated strictly by your lowest grade item.' },
      { title: '2. Skipping Weekly Mithril', desc: 'Missing the 1 weekly Mithril from Labyrinth Shop. Leveling +19 to +100 takes 150 Mithril.' },
      { title: '3. Spending Mithril on Joiners', desc: 'Upgrading Jessie or Jasser gear with Mithril is a catastrophic waste. Save it for your 1st march.' },
      { title: '4. Wrong Slot 1 Hero', desc: 'Putting non-damage heroes (Gina, Molly, Natalia, Bahiti) in Bear Trap Slot 1 blocks ally slots.' },
      { title: '5. Rushing Charms Pre-Lv.11', desc: 'Delays the 40:1 Materials Exchange and squanders rare Jewel Secrets prematurely.' },
      { title: '6. Chasing Every New Hero Gen', desc: 'A 5-star older hero heavily outperforms an underdeveloped 1-star newer hero.' },
      { title: '7. Skipping Helios T11', desc: 'Completely halts future progression into T12 Exalted ranks.' },
      { title: '8. Converting FC into Shards Early', desc: 'The War Academy structure requires FC5 itself before Helios research can finish.' },
      { title: '9. Wrong Empowerment Slot', desc: 'Pick Gloves +20 (Defense) over Belt (Attack) on Infantry. Empowerment is permanent and non-refundable!' },
      { title: '10. Getting Stuck at +40 / +80', desc: 'These provide minimal returns. Rush the +20 → +60 → +100 thresholds instead.' },
    ],
  },

  kaynaklar: {
    id: 'kaynaklar',
    number: 19,
    navLabel: 'Sources',
    title: '📚 19. Community & Official References',
    subtitle: 'All in-game trademarks belong to their respective copyright holders. This document is an independent verified strategy reference.',
    tables: [
      {
        headers: ['Reference', 'Primary Coverage', 'Reliability'],
        rows: [
          ['whiteoutsurvivalhandbook.com', 'Helios T11, Chief Gear, Charms, Gwen analysis', 'High'],
          ['WSCO (Whiteout Survival Community)', 'F2P Roadmap, F2P vs P2W, Expert tiering', 'High'],
          ['wos.h5joy-games.com', 'Iron Rhino, Helios costs, Bear damage formulas', 'Medium-High'],
          ['centurygames.helpshift.com', 'Official Sunfire Castle & Hero Gear Empowerment rules', 'Official'],
          ['heaven-guardian.com', 'Charm Secrets, VIP milestones, Rally breakdown', 'High'],
          ['altema.jp/whiteoutsurvival', 'Gen-by-gen hero mechanics & meta setups', 'High'],
        ],
      },
    ],
  },
};
