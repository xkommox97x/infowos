import { SectionContent, SupportedLanguage } from '../types';
import { SECTIONS_TR } from './sections_tr';
import { SECTIONS_EN } from './sections_en';

// Localized Section Titles and Nav Labels for all 12 languages
export const SECTION_METADATA: Record<
  string,
  Record<SupportedLanguage, { title: string; nav: string; subtitle: string }>
> = {
  baslangic: {
    tr: { title: '🚀 1. Sıfırdan Başlangıç — İlk 30 Gün ve F2P Yol Haritası', nav: 'Başlangıç', subtitle: 'Oyunun ilk ayı hesabınızın geleceğini belirler.' },
    en: { title: '🚀 1. Getting Started — First 30 Days & F2P Roadmap', nav: 'Getting Started', subtitle: 'The first month defines the trajectory of your account.' },
    de: { title: '🚀 1. Der Einstieg — Erste 30 Tage & F2P-Fahrplan', nav: 'Einstieg', subtitle: 'Der erste Monat entscheidet über die Zukunft deines Kontos.' },
    fr: { title: '🚀 1. Bien Débuter — Les 30 Premiers Jours & Feuille de Route F2P', nav: 'Débuter', subtitle: 'Le premier mois détermine l\'avenir de votre compte.' },
    es: { title: '🚀 1. Empezando de Cero — Primeros 30 Días y Hoja de Ruta F2P', nav: 'Inicio', subtitle: 'El primer mes define el futuro de tu cuenta.' },
    pt: { title: '🚀 1. Começando do Zero — Primeiros 30 Dias e Roteiro F2P', nav: 'Início', subtitle: 'O primeiro mês determina a trajetória da sua conta.' },
    ru: { title: '🚀 1. Старт с нуля — Первые 30 дней и дорожная карта F2P', nav: 'Старт', subtitle: 'Первый месяц определяет будущее вашего аккаунта.' },
    ar: { title: '🚀 1. البداية من الصفر — أول 30 يوماً وخارطة طريق F2P', nav: 'البداية', subtitle: 'الشهر الأول يحدد مسار حسابك ومستقبله.' },
    ja: { title: '🚀 1. ゼロからのスタート — 最初の30日間と無課金(F2P)ロードマップ', nav: '序盤攻略', subtitle: '最初の1ヶ月がアカウントの将来を決定づけます。' },
    zh: { title: '🚀 1. 从零起步 — 首月30天与零氪(F2P)发展路线图', nav: '新手起步', subtitle: '开局第一个月将彻底决定你账号的发展高度。' },
    it: { title: '🚀 1. Iniziare da Zero — Primi 30 Giorni e Tabella di Marcia F2P', nav: 'Inizio', subtitle: 'Il primo mese determina il destino del tuo account.' },
    pl: { title: '🚀 1. Start od Zera — Pierwsze 30 Dni i Plan F2P', nav: 'Start', subtitle: 'Pierwszy miesiąc decyduje o przyszłości Twojego konta.' },
  },

  firin: {
    tr: { title: '🏰 2. Fırın ve Şehir Gelişimi', nav: 'Fırın', subtitle: 'Fırın, şehrin kalbidir.' },
    en: { title: '🏰 2. Furnace & City Development', nav: 'Furnace', subtitle: 'The Furnace is the beating heart of your settlement.' },
    de: { title: '🏰 2. Ofen & Stadtentwicklung', nav: 'Ofen', subtitle: 'Der Schmelzofen ist das pulsierende Herz deiner Stadt.' },
    fr: { title: '🏰 2. Fournaise & Développement Urbain', nav: 'Fournaise', subtitle: 'La fournaise est le cœur battant de votre cité.' },
    es: { title: '🏰 2. Horno y Desarrollo de la Ciudad', nav: 'Horno', subtitle: 'El Horno es el corazón palpitante de tu ciudad.' },
    pt: { title: '🏰 2. Fornalha e Desenvolvimento da Cidade', nav: 'Fornalha', subtitle: 'A Fornalha é o coração pulsante do seu assentamento.' },
    ru: { title: '🏰 2. Печь и развитие города', nav: 'Печь', subtitle: 'Печь — это бьющееся сердце вашего поселения.' },
    ar: { title: '🏰 2. الفرن وتطوير المدينة', nav: 'الفرن', subtitle: 'الفرن هو القلب النابض لمدينتك ومستوطنتك.' },
    ja: { title: '🏰 2. 大溶鉱炉と都市開発', nav: '溶鉱炉', subtitle: '大溶鉱炉は都市の生命線であり、すべての発展の核です。' },
    zh: { title: '🏰 2. 大熔炉与城市建筑发展', nav: '大熔炉', subtitle: '大熔炉是整个庇护所的心脏，决定所有系统上限。' },
    it: { title: '🏰 2. Fornace e Sviluppo Urbano', nav: 'Fornace', subtitle: 'La Fornace è il cuore pulsante del tuo insediamento.' },
    pl: { title: '🏰 2. Piec i Rozwój Miasta', nav: 'Piec', subtitle: 'Piec jest bijącym sercem Twojej osady.' },
  },

  arastirma: {
    tr: { title: '🔬 3. Araştırma Merkezi', nav: 'Araştırma', subtitle: 'Tek kuyrukludur; asla boş bırakmayın.' },
    en: { title: '🔬 3. Research Center Prioritization', nav: 'Research', subtitle: 'Single-queued; keep it running 24/7 without idle gaps.' },
    de: { title: '🔬 3. Forschungszentrum-Prioritäten', nav: 'Forschung', subtitle: 'Nur eine Bauschleife; niemals leerlaufen lassen.' },
    fr: { title: '🔬 3. Centre de Recherche', nav: 'Recherche', subtitle: 'Une seule file d\'attente ; ne le laissez jamais inactif.' },
    es: { title: '🔬 3. Centro de Investigación', nav: 'Investigación', subtitle: 'Cola única; nunca lo dejes inactivo.' },
    pt: { title: '🔬 3. Centro de Pesquisa', nav: 'Pesquisa', subtitle: 'Fila única; nunca o deixe ocioso.' },
    ru: { title: '🔬 3. Центр исследований', nav: 'Исследования', subtitle: 'Очередь одна; лаборатория никогда не должна простаивать.' },
    ar: { title: '🔬 3. مركز الأبحاث', nav: 'الأبحاث', subtitle: 'قائمة انتظار واحدة؛ لا تتركه خاملاً أبداً.' },
    ja: { title: '🔬 3. 研究所の優先度', nav: '研究', subtitle: '研究キューは1つのみ。24時間稼働を維持しましょう。' },
    zh: { title: '🔬 3. 科学研究所优先升级指南', nav: '科学研究', subtitle: '单研究队列，绝对不能让科研有哪怕一秒钟闲置。' },
    it: { title: '🔬 3. Centro di Ricerca', nav: 'Ricerca', subtitle: 'Coda singola; mantienilo sempre attivo.' },
    pl: { title: '🔬 3. Centrum Badań', nav: 'Badania', subtitle: 'Jedna kolejka; nie pozwól jej stać bezczynnie.' },
  },

  kahramanlar: {
    tr: { title: '🦸 4. Kahraman Ansiklopedisi ve Nesil Tuzağı', nav: 'Kahramanlar', subtitle: '5 yıldızlı eski nesil > 1 yıldızlı yeni nesil.' },
    en: { title: '🦸 4. Hero Encyclopedia & Generation Trap', nav: 'Heroes', subtitle: '5-star older generation > 1-star newer generation.' },
    de: { title: '🦸 4. Helden-Enzyklopädie & Generationsfalle', nav: 'Helden', subtitle: '5-Sterne ältere Generation > 1-Stern neue Generation.' },
    fr: { title: '🦸 4. Encyclopédie des Héros & Piège des Générations', nav: 'Héros', subtitle: 'Ancienne génération 5 étoiles > nouvelle génération 1 étoile.' },
    es: { title: '🦸 4. Enciclopedia de Héroes y la Trampa de Generaciones', nav: 'Héroes', subtitle: 'Generación antigua 5 estrellas > nueva generación 1 estrella.' },
    pt: { title: '🦸 4. Enciclopédia de Heróis e a Armadilha das Gerações', nav: 'Heróis', subtitle: 'Geração antiga 5 estrelas > nova geração 1 estrela.' },
    ru: { title: '🦸 4. Энциклопедия героев и ловушка поколений', nav: 'Герои', subtitle: '5-звездочный герой старого поколения > 1-звездочный нового.' },
    ar: { title: '🦸 4. موسوعة الأبطال وفخ الأجيال', nav: 'الأبطال', subtitle: 'بطل 5 نجوم من جيل أقدم أفضل بكثير من بطل نجمة واحدة جديد.' },
    ja: { title: '🦸 4. 英雄図鑑と「世代の罠」', nav: '英雄', subtitle: '星5の旧世代英雄 ＞ 星1の新世代英雄。焦りは禁物です。' },
    zh: { title: '🦸 4. 英雄图鉴全解与代际陷阱', nav: '英雄百科', subtitle: '5星老世代主力 > 1星新世代花瓶。切忌盲目换代。' },
    it: { title: '🦸 4. Enciclopedia Eroi e la Trappola delle Generazioni', nav: 'Eroi', subtitle: 'Vecchia generazione a 5 stelle > nuova generazione a 1 stella.' },
    pl: { title: '🦸 4. Encyklopedia Bohaterów i Pułapka Generacji', nav: 'Bohaterowie', subtitle: '5-gwiazdkowy starszy bohater > 1-gwiazdkowy nowy bohater.' },
  },

  'hero-gear': {
    tr: { title: '⚔️ 5. Hero Gear — Empowerment (+20 → +60 → +100)', nav: 'Hero Gear', subtitle: 'Her parçanın Empowerment bonusları farklıdır. Doğru öncelik sırası hayati önemdedir.' },
    en: { title: '⚔️ 5. Hero Gear — Empowerment (+20 → +60 → +100)', nav: 'Hero Gear', subtitle: 'Empowerment curves differ per slot. Priority sequence is game-defining.' },
    de: { title: '⚔️ 5. Heldenausrüstung — Ermächtigung (+20 → +60 → +100)', nav: 'Helden-Gear', subtitle: 'Jedes Rüstungsteil hat andere Boni. Die richtige Reihenfolge ist entscheidend.' },
    fr: { title: '⚔️ 5. Équipement de Héros — Renforcement (+20 → +60 → +100)', nav: 'Équipement Héros', subtitle: 'Les courbes de bonus diffèrent selon la pièce. Prioriser +20 → +60 → +100.' },
    es: { title: '⚔️ 5. Equipo de Héroe — Potenciación (+20 → +60 → +100)', nav: 'Equipo Héroe', subtitle: 'Cada pieza otorga bonificaciones distintas. La prioridad es vital.' },
    pt: { title: '⚔️ 5. Equipamento de Herói — Potenciação (+20 → +60 → +100)', nav: 'Equip. Herói', subtitle: 'As curvas de bônus são diferentes por item. Prioridade é crucial.' },
    ru: { title: '⚔️ 5. Снаряжение героев — Усиление (+20 → +60 → +100)', nav: 'Снаряжение героев', subtitle: 'Бонусы усиления различаются по слотам. Грамотная очередность — ключ к победе.' },
    ar: { title: '⚔️ 5. عتاد الأبطال — التمكين (+20 → +60 → +100)', nav: 'عتاد الأبطال', subtitle: 'تختلف منحنيات مكافآت التمكين لكل قطعة عتاد. الترتيب الصحيح حاسم.' },
    ja: { title: '⚔️ 5. 英雄装備 — エンパワー (+20 → +60 → +100)', nav: '英雄装備', subtitle: '部位ごとに成長曲線が異なります。+20→+60→+100のスキップが必須。' },
    zh: { title: '⚔️ 5. 英雄装备 — 赋能精炼 (+20 → +60 → +100)', nav: '装备赋能', subtitle: '各部位属性成长路径完全不同，切忌平均升级！' },
    it: { title: '⚔️ 5. Equipaggiamento Eroi — Potenziamento (+20 → +60 → +100)', nav: 'Equip. Eroi', subtitle: 'Ogni pezzo conferisce bonus unici. L\'ordine corretto è fondamentale.' },
    pl: { title: '⚔️ 5. Ekwipunek Bohaterów — Wzmocnienie (+20 → +60 → +100)', nav: 'Ekwipunek Bohaterów', subtitle: 'Krzywe bonusów różnią się w zależności od części.' },
  },

  'chief-gear': {
    tr: { title: '🛡️ 6. Chief Gear — Set Bonusu Kuralı', nav: 'Chief Gear', subtitle: 'Set bonusu en düşük kaliteli parçaya göre hesaplanır.' },
    en: { title: '🛡️ 6. Chief Gear — Set Bonus Rules', nav: 'Chief Gear', subtitle: 'Set bonus matches your lowest quality piece.' },
    de: { title: '🛡️ 6. Anführer-Ausrüstung — Set-Bonus-Regel', nav: 'Anführer-Gear', subtitle: 'Der Setbonus richtet sich nach dem schwächsten Teil.' },
    fr: { title: '🛡️ 6. Équipement du Chef — Règle du Bonus de Set', nav: 'Équipement Chef', subtitle: 'Le bonus d\'ensemble s\'aligne sur votre pièce la plus basse.' },
    es: { title: '🛡️ 6. Equipo del Jefe — Regla del Bonus de Conjunto', nav: 'Equipo Jefe', subtitle: 'El bonus de conjunto se ajusta a la pieza más débil.' },
    pt: { title: '🛡️ 6. Equipamento do Chefe — Regra do Bônus de Conjunto', nav: 'Equip. Chefe', subtitle: 'O bônus de conjunto é nivelado pela peça mais fraca.' },
    ru: { title: '🛡️ 6. Снаряжение вождя — Правило бонуса сета', nav: 'Снаряжение вождя', subtitle: 'Бонус сета определяется предметом наименьшего качества.' },
    ar: { title: '🛡️ 6. عتاد القائد — قاعدة مكافأة المجموعة', nav: 'عتاد القائد', subtitle: 'تعتمد مكافأة المجموعة على القطعة الأقل جودة في عتادك.' },
    ja: { title: '🛡️ 6. 総督装備 — セット効果の絶対法則', nav: '総督装備', subtitle: 'セット効果は最も低いレアリティの部位に引きずられます。' },
    zh: { title: '🛡️ 6. 领主装备 — 套装效果木桶理论', nav: '领主装备', subtitle: '套装加成完全取决于你品质最低的那件装备，切勿偏科。' },
    it: { title: '🛡️ 6. Equipaggiamento del Capo — Regola del Bonus Set', nav: 'Equip. Capo', subtitle: 'Il bonus set corrisponde al pezzo di qualità inferiore.' },
    pl: { title: '🛡️ 6. Ekwipunek Wodza — Zasada Bonusu Zestawu', nav: 'Ekwipunek Wodza', subtitle: 'Bonus zestawu dostosowuje się do najsłabszego elementu.' },
  },

  'chief-charms': {
    tr: { title: '💎 7. Chief Charms — Lv.11 Eşiği ve 40:1 Takas', nav: 'Chief Charms', subtitle: 'Tüm 18 charm\'ı önce Lv.11\'e getirin.' },
    en: { title: '💎 7. Chief Charms — Lv.11 Threshold & 40:1 Exchange', nav: 'Chief Charms', subtitle: 'Bring all 18 charms to Lv.11 before specializing.' },
    de: { title: '💎 7. Anführer-Talismane — Lv.11 Schwelle & 40:1 Tausch', nav: 'Talismane', subtitle: 'Bringe zuerst alle 18 Talismane auf Lv.11.' },
    fr: { title: '💎 7. Charmes du Chef — Seuil Niv.11 & Échange 40:1', nav: 'Charmes Chef', subtitle: 'Montez d\'abord les 18 charmes au niveau 11.' },
    es: { title: '💎 7. Talismanes del Jefe — Umbral Nv.11 y Canje 40:1', nav: 'Talismanes', subtitle: 'Lleva primero los 18 talismanes a nivel 11.' },
    pt: { title: '💎 7. Amuletos do Chefe — Limite Nív.11 e Troca 40:1', nav: 'Amuletos', subtitle: 'Eleve todos os 18 amuletos ao Nív.11 primeiro.' },
    ru: { title: '💎 7. Чармы вождя — Порог 11 ур. и обмен 40:1', nav: 'Чармы вождя', subtitle: 'Сначала поднимите все 18 чармов до 11 уровня.' },
    ar: { title: '💎 7. تمائم القائد — عتبة المستوى 11 ومبادلة 40:1', nav: 'التمائم', subtitle: 'قم برفع جميع التمائم الـ 18 إلى المستوى 11 أولاً.' },
    ja: { title: '💎 7. 護符(チャーム) — Lv.11の壁と40:1交換レート', nav: '護符', subtitle: '全18個のチャームをまずLv.11に揃えるのが鉄則です。' },
    zh: { title: '💎 7. 领主护符 — 11级门槛与40:1兑换机制', nav: '领主护符', subtitle: '务必先将全部18个护符拉至11级，解锁材料置换。' },
    it: { title: '💎 7. Amuleti del Capo — Soglia Liv.11 e Scambio 40:1', nav: 'Amuleti Capo', subtitle: 'Porta tutti i 18 amuleti al livello 11 prima di specializzarti.' },
    pl: { title: '💎 7. Talizmany Wodza — Próg Poz. 11 i Wymiana 40:1', nav: 'Talizmany', subtitle: 'Rozwiń najpierw wszystkie 18 talizmanów na 11 poziom.' },
  },

  helios: {
    tr: { title: '🌟 8. Helios T11 — Geç Oyunun Kapısı', nav: 'Helios T11', subtitle: 'War Academy üzerinden açılır ve T12 Exalted\'ın önkoşuludur.' },
    en: { title: '🌟 8. Helios T11 — The Late-Game Gate', nav: 'Helios T11', subtitle: 'Researched via War Academy and mandatory prerequisite for T12.' },
    de: { title: '🌟 8. Helios T11 — Das Tor zum Late-Game', nav: 'Helios T11', subtitle: 'Wird über die Kriegsakademie erforscht; Voraussetzung für T12.' },
    fr: { title: '🌟 8. Hélios T11 — La Porte du Late-Game', nav: 'Hélios T11', subtitle: 'Débloqué via l\'Académie de Guerre et condition préalable au T12.' },
    es: { title: '🌟 8. Helios T11 — La Puerta al Late-Game', nav: 'Helios T11', subtitle: 'Se investiga en la Academia de Guerra; requisito para T12.' },
    pt: { title: '🌟 8. Helios T11 — A Porta para o Fim de Jogo', nav: 'Helios T11', subtitle: 'Pesquisado pela Academia de Guerra; pré-requisito para T12.' },
    ru: { title: '🌟 8. Гелиос T11 — Врата в позднюю игру', nav: 'Гелиос T11', subtitle: 'Изучается в Военной академии и обязателен для открытия T12.' },
    ar: { title: '🌟 8. قوات هيليوس T11 — بوابة المراحل المتقدمة', nav: 'هيليوس T11', subtitle: 'تُفتح عبر الأكاديمية العسكرية وهي متطلب أساسي لقوات T12.' },
    ja: { title: '🌟 8. ヘリオスT11兵 — 終盤戦の絶対関門', nav: 'ヘリオスT11', subtitle: '軍事アカデミーで解放。T12部隊への必須前提条件です。' },
    zh: { title: '🌟 8. 太阳神 T11 兵种 — 后期战争分水岭', nav: '太阳神T11', subtitle: '战争学院科技产物，迈向T12天兵不可逾越的先决条件。' },
    it: { title: '🌟 8. Helios T11 — La Porta del Late-Game', nav: 'Helios T11', subtitle: 'Sbloccato tramite l\'Accademia di Guerra; prerequisito per T12.' },
    pl: { title: '🌟 8. Helios T11 — Brama do Późnej Gry', nav: 'Helios T11', subtitle: 'Badany w Akademii Wojennej; warunek wstępny dla T12.' },
  },

  'helios-oranlar': {
    tr: { title: '🎯 9. Helios T11 — 1. Ordu ve Alternatifleri', nav: 'Helios 1. Ordu', subtitle: 'Elinizdeki Helios türlerine göre optimize edilmiş oranlar.' },
    en: { title: '🎯 9. Helios T11 — 1st Army Compositions', nav: 'Helios 1st Army', subtitle: 'Optimized troop ratios based on unlocked Helios types.' },
    de: { title: '🎯 9. Helios T11 — 1. Armee & Alternativen', nav: 'Helios 1. Armee', subtitle: 'Optimierte Verhältnisse basierend auf freigeschalteten Helios-Arten.' },
    fr: { title: '🎯 9. Hélios T11 — 1ère Armée et Alternatives', nav: 'Hélios 1ère Armée', subtitle: 'Ratios optimisés selon vos types Hélios débloqués.' },
    es: { title: '🎯 9. Helios T11 — 1er Ejército y Alternativas', nav: 'Helios 1er Ejército', subtitle: 'Proporciones optimizadas según tus tipos de Helios.' },
    pt: { title: '🎯 9. Helios T11 — 1º Exército e Alternativas', nav: 'Helios 1º Exército', subtitle: 'Proporções otimizadas conforme seus tipos Helios desbloqueados.' },
    ru: { title: '🎯 9. Гелиос T11 — Составы 1-й армии', nav: 'Гелиос 1-я армия', subtitle: 'Оптимизированные пропорции в зависимости от открытых видов.' },
    ar: { title: '🎯 9. هيليوس T11 — تشكيلات الجيش الأول والبدائل', nav: 'جيش هيليوس 1', subtitle: 'نسب محسوبة بدقة حسب فئات هيليوس المفتوحة لديك.' },
    ja: { title: '🎯 9. ヘリオスT11 — 第1軍団編成と代替案', nav: 'ヘリオス第1部隊', subtitle: '解放済みのヘリオス兵種に応じた最適比率。' },
    zh: { title: '🎯 9. 太阳神 T11 — 第一主力出征配比及变体', nav: '太阳神配比', subtitle: '根据所拥有的太阳神兵种类型精细化定制配比方案。' },
    it: { title: '🎯 9. Helios T11 — 1° Esercito e Alternative', nav: 'Helios 1° Esercito', subtitle: 'Rapporti ottimizzati in base ai tipi di Helios sbloccati.' },
    pl: { title: '🎯 9. Helios T11 — Skład 1. Armii i Alternatywy', nav: 'Helios 1. Armia', subtitle: 'Zoptymalizowane proporcje na podstawie odblokowanych typów.' },
  },

  'ordu-oranlari': {
    tr: { title: '🎯 10. Genel Ordu Oranları — Mod Bazlı', nav: 'Genel Ordu', subtitle: 'Ayı Tuzağı, Kale, Crazy Joe ve Labyrinth için ideal dağılımlar.' },
    en: { title: '🎯 10. General Troop Ratios — Mode Specific', nav: 'Troop Ratios', subtitle: 'Ideal spreads for Bear Trap, Sunfire, Crazy Joe, and Labyrinth.' },
    de: { title: '🎯 10. Allgemeine Truppenverhältnisse — Modus-spezifisch', nav: 'Truppenquoten', subtitle: 'Ideale Verteilungen für Bärenfalle, Schloss, Crazy Joe und Labyrinth.' },
    fr: { title: '🎯 10. Ratios Généraux de Troupes — Par Mode', nav: 'Ratios Troupes', subtitle: 'Compositions idéales pour Piège à Ours, Château, Joe Fou et Labyrinthe.' },
    es: { title: '🎯 10. Ratios Generales de Tropas — Por Modo de Juego', nav: 'Ratios Tropas', subtitle: 'Distribuciones para Trampa de Oso, Castillo, Crazy Joe y Laberinto.' },
    pt: { title: '🎯 10. Proporções Gerais de Tropas — Por Modo', nav: 'Proporções Tropas', subtitle: 'Composições para Armadilha de Urso, Castelo, Joe Louco e Labirinto.' },
    ru: { title: '🎯 10. Общие соотношения войск по режимам игры', nav: 'Составы войск', subtitle: 'Идеальные пропорции для Медведя, Замка, Сумасшедшего Джо и Лабиринта.' },
    ar: { title: '🎯 10. نسب القوات العامة — بحسب نمط اللعب', nav: 'نسب القوات', subtitle: 'توزيعات مثالية لمصيدة الدب، قلعة سان فاير، والمتاهة.' },
    ja: { title: '🎯 10. 各種コンテンツ別・部隊編成比率', nav: '全般兵種比率', subtitle: '熊狩り、太陽城、クレイジージョー、迷宮の最適黄金比。' },
    zh: { title: '🎯 10. 全玩法部队兵种出征配比大全', nav: '通用配比', subtitle: '猎熊、太阳城要塞、狂人乔、巨魔迷宫实测胜率配比。' },
    it: { title: '🎯 10. Ripartizione Generale Truppe — Per Modalità', nav: 'Ripartizione Truppe', subtitle: 'Composizioni per Trappola dell\'Orso, Castello, Joe Pazzo e Labirinto.' },
    pl: { title: '🎯 10. Ogólne Proporcje Wojsk — Według Trybów', nav: 'Proporcje Wojsk', subtitle: 'Podziały dla Polowania na Niedźwiedzia, Zamku, Szalonego Joe i Labiryntu.' },
  },

  savas: {
    tr: { title: '⚔️ 11. Savaş Mekanikleri — Sayaç Üçgeni, Ralli ve Garnizon', nav: 'Savaş', subtitle: 'Infantry > Lancer > Marksman > Infantry. Ralli kuralları.' },
    en: { title: '⚔️ 11. Battle Mechanics — Counter Triangle, Rallies & Garrisons', nav: 'Battle Mechanics', subtitle: 'Rock-paper-scissors dynamic and critical rally joiner rules.' },
    de: { title: '⚔️ 11. Kampfmechanik — Konter-Dreieck & Rallies', nav: 'Kampf', subtitle: 'Infanterie > Lanzenreiter > Schützen > Infanterie.' },
    fr: { title: '⚔️ 11. Mécaniques de Combat — Triangle de Contre & Rallies', nav: 'Combat', subtitle: 'Infanterie > Lanciers > Tireurs > Infanterie.' },
    es: { title: '⚔️ 11. Mecánicas de Batalla — Triángulo de Contras y Rallies', nav: 'Batalla', subtitle: 'Infantería > Lanceros > Tiradores > Infantería.' },
    pt: { title: '⚔️ 11. Mecânicas de Batalha — Triângulo de Vantagens e Ralis', nav: 'Batalha', subtitle: 'Infantaria > Lanceiros > Atiradores > Infantaria.' },
    ru: { title: '⚔️ 11. Боевая механика — Треугольник преимуществ и сборы', nav: 'Бой', subtitle: 'Пехота > Копьеносцы > Стрелки > Пехота. Правила сборов.' },
    ar: { title: '⚔️ 11. آليات المعركة — مثلث التفوق والحشود', nav: 'المعارك', subtitle: 'المشاة > الرماح > الرماة > المشاة. قواعد الحشود الصارمة.' },
    ja: { title: '⚔️ 11. 戦闘メカニクス — 三すくみ相性と集結・駐屯の鉄則', nav: '戦闘システム', subtitle: '盾兵 ＞ 槍兵 ＞ 弓兵 ＞ 盾兵。車頭と車身のスキル発動ルール。' },
    zh: { title: '⚔️ 11. 战斗底层机制 — 克制三角、集结与驻防', nav: '战斗机制', subtitle: '盾兵克制枪兵、枪兵克制射手、射手克制盾兵。车身英雄发车规矩。' },
    it: { title: '⚔️ 11. Meccaniche di Battaglia — Triangolo di Contrasto e Raduni', nav: 'Battaglia', subtitle: 'Fanti > Lancieri > Tiratori > Fanti.' },
    pl: { title: '⚔️ 11. Mechanika Walki — Trójkąt Kontr, Rajdy i Garnizony', nav: 'Walka', subtitle: 'Piechota > Włócznicy > Strzelcy > Piechota.' },
  },

  kale: {
    tr: { title: '🏰 12. Kale Savaşı (Sunfire Castle)', nav: 'Kale Savaşı', subtitle: '2.5 saat ardışık veya 5 saatlik pencerede en uzun süre tutan kazanır.' },
    en: { title: '🏰 12. Sunfire Castle Battle Rules', nav: 'Sunfire Castle', subtitle: 'Hold for 2.5 consecutive hours or longest cumulative duration.' },
    de: { title: '🏰 12. Sonnfeuer-Schlosschlacht', nav: 'Sonnfeuer', subtitle: '2,5 Stunden am Stück oder längste kumulative Zeit gewinnt.' },
    fr: { title: '🏰 12. Bataille du Château Sunfire', nav: 'Château Sunfire', subtitle: 'Contrôler 2,5 h consécutives ou la plus longue durée cumulée.' },
    es: { title: '🏰 12. Batalla del Castillo Sunfire', nav: 'Castillo Sunfire', subtitle: 'Mantener 2,5 h consecutivas o mayor tiempo acumulado.' },
    pt: { title: '🏰 12. Batalha do Castelo Sunfire', nav: 'Castelo Sunfire', subtitle: 'Manter por 2,5 h consecutivas ou maior tempo acumulado.' },
    ru: { title: '🏰 12. Битва за замок Санфайр (Sunfire Castle)', nav: 'Замок Санфайр', subtitle: '2.5 часа удержания подряд или наибольшее общее время.' },
    ar: { title: '🏰 12. معركة قلعة سان فاير (Sunfire Castle)', nav: 'قلعة سان فاير', subtitle: 'السيطرة لمدة ساعتين ونصف متواصلة أو أطول وقت إجمالي تراكمي.' },
    ja: { title: '🏰 12. サンファイア城塞決戦 (Sunfire Castle)', nav: '太陽城争奪', subtitle: '2.5時間の連続占拠、または5時間枠内の累計最長占拠で完全勝利。' },
    zh: { title: '🏰 12. 太阳城王城争夺战 (Sunfire Castle)', nav: '太阳城王战', subtitle: '连续占领2.5小时直接净胜夺冠，或5小时窗口内累计时间最高者胜。' },
    it: { title: '🏰 12. Battaglia del Castello Sunfire', nav: 'Castello Sunfire', subtitle: '2,5 ore consecutive o maggior tempo cumulativo vincono.' },
    pl: { title: '🏰 12. Bitwa o Zamek Sunfire', nav: 'Zamek Sunfire', subtitle: '2,5 godziny bez przerwy lub najdłuższy łączny czas kontroli.' },
  },

  'bear-trap': {
    tr: { title: '🐻 13. Ayı Tuzağı (Bear Trap / Bear Hunt) — Eksiksiz Rehber', nav: 'Ayı Tuzağı', subtitle: 'Gwen tartışması, ralli lideri vs katılımcı rolleri ve maksimum hasar formülü.' },
    en: { title: '🐻 13. Bear Trap / Bear Hunt — Master Guide', nav: 'Bear Trap', subtitle: 'Gwen debate, rally leader vs joiner roles, and max damage formulas.' },
    de: { title: '🐻 13. Bärenfalle (Bear Hunt) — Meister-Leitfaden', nav: 'Bärenfalle', subtitle: 'Gwen-Debatte, Leiter vs Teilnehmer und Formeln für maximalen Schaden.' },
    fr: { title: '🐻 13. Piège à Ours (Bear Hunt) — Guide Ultime', nav: 'Piège à Ours', subtitle: 'Débat sur Gwen, rôles de leader vs rejoint et formule de dégâts maximaux.' },
    es: { title: '🐻 13. Trampa de Oso (Bear Hunt) — Guía Maestra', nav: 'Trampa Oso', subtitle: 'El debate de Gwen, roles de líder vs participante y daño máximo.' },
    pt: { title: '🐻 13. Armadilha de Urso (Bear Hunt) — Guia Definitivo', nav: 'Armadilha Urso', subtitle: 'O debate sobre Gwen, papéis de líder e participante e dano máximo.' },
    ru: { title: '🐻 13. Медвежья ловушка (Bear Trap) — Полное руководство', nav: 'Медвежья ловушка', subtitle: 'Споры вокруг Гвен, роли лидера и участников, секреты топ-урона.' },
    ar: { title: '🐻 13. مصيدة الدب (Bear Trap) — الدليل الشامل', nav: 'مصيدة الدب', subtitle: 'جدل البطلة غوين، أدوار القائد والمنضمين، ومعادلة الضرر الأقصى.' },
    ja: { title: '🐻 13. ベアトラップ（熊狩り）— 完全攻略極意', nav: 'ベアトラップ', subtitle: 'グウェン論争の真相、車頭・車身の最適英雄選定と最大ダメージ方程式。' },
    zh: { title: '🐻 13. 猎熊陷阱 (Bear Trap) — 极限打桩终极全解', nav: '猎熊全解', subtitle: '格温(Gwen)收益争议深度拆解、车头车身位英雄与伤害最大化公式。' },
    it: { title: '🐻 13. Trappola dell\'Orso — Guida Suprema', nav: 'Trappola Orso', subtitle: 'Il dibattito su Gwen, ruoli leader e partecipante per il danno massimo.' },
    pl: { title: '🐻 13. Pułapka na Niedźwiedzia — Kompletny Przewodnik', nav: 'Pułapka Niedźwiedź', subtitle: 'Debata o Gwen, role lidera i dołączających oraz formuła max obrażeń.' },
  },

  uzmanlar: {
    tr: { title: '🧑‍🔬 14. Uzmanlar (Experts) — F2P Öncelik Sırası', nav: 'Uzmanlar', subtitle: 'Agnes, Cyrille ve Dawn Academy uzmanları.' },
    en: { title: '🧑‍🔬 14. Dawn Academy Experts — F2P Priority Order', nav: 'Experts', subtitle: 'Agnes, Cyrille, and progression sequencing in Dawn Academy.' },
    de: { title: '🧑‍🔬 14. Experten der Dämmerungsakademie', nav: 'Experten', subtitle: 'Agnes, Cyrille und die F2P-Prioritäten.' },
    fr: { title: '🧑‍🔬 14. Experts de l\'Académie de l\'Aube', nav: 'Experts', subtitle: 'Agnes, Cyrille et les priorités F2P.' },
    es: { title: '🧑‍🔬 14. Expertos de la Academia del Alba', nav: 'Expertos', subtitle: 'Agnes, Cyrille y el orden de prioridad F2P.' },
    pt: { title: '🧑‍🔬 14. Especialistas da Academia da Alvorada', nav: 'Especialistas', subtitle: 'Agnes, Cyrille e a ordem de prioridade F2P.' },
    ru: { title: '🧑‍🔬 14. Эксперты Академии Рассвета — Порядок прокачки F2P', nav: 'Эксперты', subtitle: 'Агнес, Сирил и приоритеты для экономных игроков.' },
    ar: { title: '🧑‍🔬 14. خبراء أكاديمية الفجر — أولويات لاعبي F2P', nav: 'الخبراء', subtitle: 'أغنيس، سيريل وترتيب أولويات الاستثمار المجاني.' },
    ja: { title: '🧑‍🔬 14. 暁のアカデミー・専門家育成優先度', nav: '専門家', subtitle: 'アグネス、シリルら無課金プレイヤーの必須投資指針。' },
    zh: { title: '🧑‍🔬 14. 黎明学院专家 — 平民F2P养成优先级', nav: '学院专家', subtitle: '艾格尼丝(Agnes)、西里尔(Cyrille)好感度停驻节点与高性价比指南。' },
    it: { title: '🧑‍🔬 14. Esperti dell\'Accademia dell\'Alba', nav: 'Esperti', subtitle: 'Agnes, Cyrille e l\'ordine di priorità F2P.' },
    pl: { title: '🧑‍🔬 14. Eksperci Akademii Świtu — Kolejność F2P', nav: 'Eksperci', subtitle: 'Agnes, Cyrille i optymalna kolejność dla graczy darmowych.' },
  },

  evcil: {
    tr: { title: '🐾 15. Evcil Hayvanlar (Pets) — Tier Listesi ve Öncelik', nav: 'Evcil Hayvanlar', subtitle: 'Iron Rhino, Cave Lion ve gelişim hayvanları.' },
    en: { title: '🐾 15. Pets Tier List & Evolution Order', nav: 'Pets', subtitle: 'Iron Rhino, Cave Lion, and essential developmental beasts.' },
    de: { title: '🐾 15. Haustiere (Pets) — Rangliste & Prioritäten', nav: 'Haustiere', subtitle: 'Eisennashorn, Höhlenlöwe und Entwicklungs-Tiere.' },
    fr: { title: '🐾 15. Familiers — Tier List & Ordre d\'Évolution', nav: 'Familiers', subtitle: 'Rhinocéros de Fer, Lion des Cavernes et bêtes économiques.' },
    es: { title: '🐾 15. Mascotas — Lista de Niveles y Prioridades', nav: 'Mascotas', subtitle: 'Rinoceronte de Hierro, León de las Cavernas y bestias de granja.' },
    pt: { title: '🐾 15. Mascotes — Tier List e Ordem de Evolução', nav: 'Mascotes', subtitle: 'Rinoceronte de Ferro, Leão das Cavernas e bestas de suporte.' },
    ru: { title: '🐾 15. Питомцы — Тир-лист и очередность развития', nav: 'Питомцы', subtitle: 'Железный носорог, пещерный лев и животные развития.' },
    ar: { title: '🐾 15. الحيوانات الأليفة — قائمة المستويات والأولويات', nav: 'الحيوانات', subtitle: 'وحيد القرن الحديدي، أسد الكهف، وحيوانات التطوير الاقتصادي.' },
    ja: { title: '🐾 15. 巨獣(ペット) — ティア表と育成優先順位', nav: '巨獣ペット', subtitle: 'アイアンライノ、ケーブライオン等の集結＆内政特化ペット。' },
    zh: { title: '🐾 15. 巨兽宠物系统 — 梯队排行与升级优先级', nav: '宠物巨兽', subtitle: '铁甲犀牛车头扩编神器、洞穴狮攻击光环与前期发展宠培养。' },
    it: { title: '🐾 15. Animali da Compagnia — Tier List e Priorità', nav: 'Animali', subtitle: 'Rinoceronte di Ferro, Leone delle Caverne e bestie di sviluppo.' },
    pl: { title: '🐾 15. Zwierzaki — Lista Poziomów i Priorytety', nav: 'Zwierzaki', subtitle: 'Żelazny Nosorożec, Jaskiniowy Lew i bestie rozwoju.' },
  },

  etkinlikler: {
    tr: { title: '📅 16. Etkinlik Takvimi', nav: 'Etkinlikler', subtitle: 'Ayı Tuzağı, SvS, Foundry ve Fortress döngüleri.' },
    en: { title: '📅 16. Event Calendar & Meta Strategies', nav: 'Events', subtitle: 'Bear Hunt, SvS, Foundry Battle, and Fortress cycles.' },
    de: { title: '📅 16. Event-Kalender & Strategien', nav: 'Events', subtitle: 'Bärenjagd, SvS, Gießerei-Schlacht und Festungs-Zyklen.' },
    fr: { title: '📅 16. Calendrier des Événements', nav: 'Événements', subtitle: 'Piège à Ours, SvS, Fonderie et Batailles de Forteresse.' },
    es: { title: '📅 16. Calendario de Eventos', nav: 'Eventos', subtitle: 'Caza del Oso, SvS, Batalla de Fundición y Fortalezas.' },
    pt: { title: '📅 16. Calendário de Eventos', nav: 'Eventos', subtitle: 'Caça ao Urso, SvS, Batalha da Fundição e Fortalezas.' },
    ru: { title: '📅 16. Календарь событий и циклы активностей', nav: 'События', subtitle: 'Охота на медведя, SvS, Битва в литейной и крепости.' },
    ar: { title: '📅 16. تقويم الفعاليات والأحداث', nav: 'الفعاليات', subtitle: 'صيد الدب، معارك السيرفرات SvS، ومعارك المسبك والقلاع.' },
    ja: { title: '📅 16. 定期イベントカレンダーと攻略周期', nav: 'イベント日程', subtitle: '熊狩り、サーバー間SvS、兵器工場争奪戦の定例サイクル。' },
    zh: { title: '📅 16. 循环活动日程表与备战节点', nav: '活动日程', subtitle: '猎熊、最强王国跨服战(SvS)、兵工厂争夺战与盟战日历。' },
    it: { title: '📅 16. Calendario Eventi', nav: 'Eventi', subtitle: 'Caccia all\'Orso, SvS, Fonderia e Fortezze.' },
    pl: { title: '📅 16. Kalendarz Wydarzeń i Strategie', nav: 'Wydarzenia', subtitle: 'Polowanie na Niedźwiedzia, SvS, Odlewnia i Twierdze.' },
  },

  f2p: {
    tr: { title: '💰 17. F2P vs P2W — Gerçek Zaman Çizelgesi', nav: 'F2P vs P2W', subtitle: 'Fark içeriğe ne zaman ulaştığınızdadır. Para hız satın alır.' },
    en: { title: '💰 17. F2P vs P2W — Realistic Progression Timelines', nav: 'F2P vs P2W', subtitle: 'The only true difference is velocity. Spending buys time, not exclusive content.' },
    de: { title: '💰 17. F2P vs P2W — Realistische Zeitachsen', nav: 'F2P vs P2W', subtitle: 'Der Unterschied liegt nur im Tempo. Geld kauft Zeit.' },
    fr: { title: '💰 17. F2P vs P2W — Délais de Progression Réalistes', nav: 'F2P vs P2W', subtitle: 'La seule différence réside dans la vitesse. L\'argent achète du temps.' },
    es: { title: '💰 17. F2P vs P2W — Líneas de Tiempo Reales', nav: 'F2P vs P2W', subtitle: 'La única diferencia es la velocidad. El dinero compra tiempo.' },
    pt: { title: '💰 17. F2P vs P2W — Linhas do Tempo Reais', nav: 'F2P vs P2W', subtitle: 'A única diferença é a velocidade. O dinheiro compra tempo.' },
    ru: { title: '💰 17. F2P против P2W — Реалистичные таймлайны', nav: 'F2P vs P2W', subtitle: 'Разница лишь в скорости. Деньги покупают время, а не эксклюзив.' },
    ar: { title: '💰 17. مقارنة F2P ضد P2W — الجداول الزمنية الواقعية', nav: 'F2P مقابل P2W', subtitle: 'الفرق الحقيقي الوحيد هو السرعة. الدفع يشتري الوقت فقط.' },
    ja: { title: '💰 17. 無課金(F2P) vs 課金(P2W) — 到達時期の現実', nav: '無課金vs課金', subtitle: '違いは「いつ到達するか」の速度のみ。資金は時間を買う手段です。' },
    zh: { title: '💰 17. 零氪(F2P) 与 氪金(P2W) 真实发展时间线', nav: '平民vs氪金', subtitle: '两者的本质区别仅在于速度。金钱买的是时间，不是门槛。' },
    it: { title: '💰 17. F2P vs P2W — Tempistiche Realistiche', nav: 'F2P vs P2W', subtitle: 'L\'unica vera differenza è la velocità. I soldi comprano tempo.' },
    pl: { title: '💰 17. F2P vs P2W — Realne Ramy Czasowe', nav: 'F2P vs P2W', subtitle: 'Jedyną różnicą jest prędkość. Pieniądze kupują czas.' },
  },

  tuzaklar: {
    tr: { title: '⚠️ 18. En Pahalı Tuzaklar', nav: 'Tuzaklar', subtitle: 'Bu 10 hata aylarca ilerleme kaybettirir.' },
    en: { title: '⚠️ 18. The 10 Most Expensive Traps', nav: 'Costly Traps', subtitle: 'These 10 blunders cost players months of progress.' },
    de: { title: '⚠️ 18. Die 10 Teuersten Fallen', nav: 'Fallen', subtitle: 'Diese 10 Fehler kosten Monate an Spielfortschritt.' },
    fr: { title: '⚠️ 18. Les 10 Pièges les Plus Coûteux', nav: 'Pièges', subtitle: 'Ces 10 erreurs font perdre des mois de progression.' },
    es: { title: '⚠️ 18. Las 10 Trampas Más Caras', nav: 'Trampas', subtitle: 'Estos 10 errores cuestan meses de progreso.' },
    pt: { title: '⚠️ 18. As 10 Armadilhas Mais Caras', nav: 'Armadilhas', subtitle: 'Estes 10 erros custam meses de progresso.' },
    ru: { title: '⚠️ 18. Топ-10 самых дорогих ошибок', nav: 'Ошибки', subtitle: 'Эти 10 просчетов отбрасывают развитие аккаунта на месяцы назад.' },
    ar: { title: '⚠️ 18. أغلى 10 أخطاء فادحة', nav: 'الأخطاء', subtitle: 'هذه الأخطاء الـ 10 قد تكلفك أشهراً من التقدم الضائع.' },
    ja: { title: '⚠️ 18. 絶対に避けるべき「最大の罠」ワースト10', nav: '落とし穴', subtitle: 'この10の致命的なミスは数ヶ月分の成長を水泡に帰します。' },
    zh: { title: '⚠️ 18. 代价惨重的 10 大避坑指南', nav: '避坑指南', subtitle: '新手和进阶玩家最容易犯的10个毁灭性资源浪费大坑。' },
    it: { title: '⚠️ 18. Le 10 Trappole Più Costose', nav: 'Trappole', subtitle: 'Questi 10 errori costano mesi di progressi.' },
    pl: { title: '⚠️ 18. 10 Najbardziej Kosztownych Pułapek', nav: 'Pułapki', subtitle: 'Te 10 błędów kosztuje miesiące zmarnowanego postępu.' },
  },

  kaynaklar: {
    tr: { title: '📚 19. Kaynaklar ve Doğrulama', nav: 'Kaynaklar', subtitle: 'Resmî kurallar ve doğrulanmış topluluk referansları.' },
    en: { title: '📚 19. Community & Official References', nav: 'Sources', subtitle: 'Official guides and high-trust community references.' },
    de: { title: '📚 19. Quellen & Verifizierung', nav: 'Quellen', subtitle: 'Offizielle Regeln und geprüfte Community-Referenzen.' },
    fr: { title: '📚 19. Sources et Vérification', nav: 'Sources', subtitle: 'Règles officielles et références communautaires vérifiées.' },
    es: { title: '📚 19. Fuentes y Verificación', nav: 'Fuentes', subtitle: 'Reglas oficiales y referencias verificadas de la comunidad.' },
    pt: { title: '📚 19. Fontes e Verificação', nav: 'Fontes', subtitle: 'Regras oficiais e referências comunitárias verificadas.' },
    ru: { title: '📚 19. Источники и ссылки', nav: 'Источники', subtitle: 'Официальные данные и проверенные гайды сообщества.' },
    ar: { title: '📚 19. المصادر والمراجع المعتمدة', nav: 'المصادر', subtitle: 'القواعد الرسمية ومراجع مجتمع اللاعبين الموثوقة.' },
    ja: { title: '📚 19. 参考文献と検証情報元', nav: '情報源', subtitle: '公式ルールブックおよび信頼できる攻略コミュニティ資料。' },
    zh: { title: '📚 19. 资料来源与官方验证出处', nav: '参考资料', subtitle: 'Century Games 官方帮助文档与海内外公认顶级攻略智库。' },
    it: { title: '📚 19. Fonti e Riferimenti', nav: 'Fonti', subtitle: 'Regole ufficiali e fonti verificate della community.' },
    pl: { title: '📚 19. Źródła i Weryfikacja', nav: 'Źródła', subtitle: 'Oficjalne zasady i zweryfikowane materiały społeczności.' },
  },
};

export const getLocalizedSections = (
  lang: SupportedLanguage
): Record<string, SectionContent> => {
  if (lang === 'tr') return SECTIONS_TR;
  if (lang === 'en') return SECTIONS_EN;

  // For other languages, build upon SECTIONS_EN with localized titles, subtitles, and nav labels!
  const base = SECTIONS_EN;
  const result: Record<string, SectionContent> = {};

  for (const [key, section] of Object.entries(base)) {
    const meta = SECTION_METADATA[key]?.[lang];
    result[key] = {
      ...section,
      title: meta?.title || section.title,
      navLabel: meta?.nav || section.navLabel,
      subtitle: meta?.subtitle || section.subtitle,
    };
  }

  return result;
};
