import { SectionContent } from '../types';

export const SECTIONS_TR: Record<string, SectionContent> = {
  baslangic: {
    id: 'baslangic',
    number: 1,
    navLabel: 'Başlangıç',
    title: '🚀 1. Sıfırdan Başlangıç — İlk 30 Gün ve F2P Yol Haritası',
    subtitle: 'Oyunun ilk ayı hesabınızın geleceğini belirler.',
    badge: { text: '✅ Doğrulanmış', type: 'ok' },
    cards: [
      {
        title: '🏁 Sunucu Seçimi',
        desc: 'Eski sunucularda güçlü ittifaklar oturmuştur. Yeni açılmış bir sunucuya girin. Yeni sunucu etkinlikleri kaçırılırsa telafi edilemez.',
      },
      {
        title: '🤝 İttifaka Hemen Katılın',
        desc: 'Oyunun ilk gününde aktif bir ittifaka katılın. İttifak yardımı, ralli ve kaynaklar erken oyunda katlanarak büyür.',
      },
      {
        title: '🎯 İlk 30 Günün Hedefi',
        desc: 'Fırın 18 + VIP 6. F2P oyuncular için erken oyunda Infantry Health araştırması diğer tüm savaş statlarından önce gelmelidir.',
      },
    ],
    notices: [
      {
        type: 'info',
        title: 'F2P Yol Haritası (WSCO verisi):',
        content: '',
        bullets: [
          'Gün 0–14: Fırın 19–22; ilk 3 ittifaktan birine katıl. Gen 1 kahramanlar, Arena, Tundra açılır.',
          'Gün 25–54: Fırın 25–27; Labyrinth, Daybreak Island, Sunfire, Pets Gen 1 açılır. İlk evcil hayvan: Arctic Wolf.',
          'Gün 60–120: FC1–FC2; Fire Crystal çağı, SvS/KoI, Gen 3 kahramanlar. İlk SvS hazırlık döngüsünü bankala.',
          'Fırın 30: F2P ~55–65. gün; €10/ay ~50. gün; €50/ay ~40–45. gün; balina ~35. gün.',
        ],
      },
      {
        type: 'warn',
        title: 'Erken Oyunun 3 Büyük Hatası:',
        content: '',
        bullets: [
          'Her binayı eşit yükseltmek. Fırın 20–25 arasında ciddi duvara çarparsınız.',
          'Hızlandırmaları boşa harcamak. Etkinlik veya kritik darboğaz için saklayın.',
          'İttifaka geç katılmak. İttifak yardımı ve kaynaklar katlanarak büyür.',
        ],
      },
    ],
  },

  firin: {
    id: 'firin',
    number: 2,
    navLabel: 'Fırın',
    title: '🏰 2. Fırın ve Şehir Gelişimi',
    subtitle: 'Fırın, şehrin kalbidir.',
    badge: { text: '✅ Doğrulanmış', type: 'ok' },
    tables: [
      {
        title: 'Bina Yükseltme Önceliği',
        headers: ['Sıra', 'Bina', 'Neden?'],
        rows: [
          ['1', 'Furnace (Fırın)', 'Neredeyse her sistemi kilitler; durursa hesap durur.'],
          ['2', 'Embassy (Elçilik)', 'Takviye ve ralli slotları; ittifak yardımı artışı.'],
          ['3', 'Research Center (Araştırma)', "Uzun vadeli bonuslar; Furnace'ın 3+ seviye gerisinde kalmamalı."],
          ['4', 'Birlik kampları (Kamplar)', 'Askeri temel; Furnace seviyesine yakın tutulmalıdır.'],
          ['5', 'Infirmary (Revir)', 'İyileştirme kapasitesi; savaş kayıplarını en aza indirir.'],
          ['6', 'Kaynak binaları', 'Sadece yetecek kadar; önce savaş ve Furnace önceliklidir.'],
        ],
      },
      {
        title: 'Fırın Seviyesiyle Açılan Kilit Özellikler',
        headers: ['Furnace Seviyesi', 'Açılan / Önemli Değişiklik'],
        rows: [
          ['Lv.9', 'Research Center (Araştırma Merkezi) açılır.'],
          ['Lv.15', 'Hero Gear (Kahraman Ekipmanı) açılır.'],
          ['Lv.18', 'Evcil hayvanlar açılır (Beast Cage; ~Gün 55–60).'],
          ['Lv.19', 'Labyrinth (Labirent) açılır.'],
          ['Lv.20', 'Mastery Forging açılır.'],
          ['Lv.22', 'Chief Gear (Şef Ekipmanı) açılır.'],
          ['Lv.25', 'Chief Charms (Şef Tılsımları) açılır.'],
          ['Lv.30', 'Klasik tavan; FC (Ateş Kristali) çağı (~Gün 60) başlar.'],
        ],
      },
    ],
  },

  arastirma: {
    id: 'arastirma',
    number: 3,
    navLabel: 'Araştırma',
    title: '🔬 3. Araştırma Merkezi',
    subtitle: 'Tek kuyrukludur; asla boş bırakmayın.',
    tables: [
      {
        headers: ['Aşama', 'Furnace', 'Dağılım', 'Öncelikli Düğümler'],
        rows: [
          ['1. Temel', '9–15', '%60 Eco / %30 Growth / %10 Battle', 'Tool Enhancement (araştırma hızı) → Tooling Up (inşaat hızı) → Command Tactics (yürüyüş kuyruğu).'],
          ['2. Hızlanma', '15–26', '%40 Growth / %35 Eco / %25 Battle', 'Gathering Speed, March Queue, Regimental Expansion.'],
          ['3. Uzmanlaşma', '26+', '%45 Battle / %30 Growth / %25 Eco', 'Yüzde bazlı savaş statları; en yüksek birlik kademenle eşleştir.'],
        ],
      },
    ],
    notices: [
      {
        type: 'danger',
        title: 'Fırın Kapısı Kuralı:',
        content: "Bir sonraki Furnace seviyesi belirli bir araştırma seviyesi istiyorsa, o araştırma 1. önceliktir. Araştırma Merkezi'ni Furnace'ın 3+ seviye gerisinde bırakmak ilerlemeyi bloke eder.",
      },
    ],
  },

  kahramanlar: {
    id: 'kahramanlar',
    number: 4,
    navLabel: 'Kahramanlar',
    title: '🦸 4. Kahraman Ansiklopedisi ve Nesil Tuzağı',
    subtitle: 'En yeni nesil her zaman en iyi değildir. 5 yıldızlı eski nesil > 1 yıldızlı yeni nesil.',
    badge: { text: '⚠️ Beceri yüzdeleri değişebilir', type: 'warn' },
    tables: [
      {
        headers: ['Nesil', 'Öncelikli Kahraman(lar)', 'Neden?'],
        rows: [
          ['1', 'Molly, Jeronimo', 'Molly: alan hasarı + dondurma kontrolü. Jeronimo: Ayı Tuzağı lideri.'],
          ['2', 'Flint, Alonso', 'Flint: F2P dostu tank (Lucky Wheel); 5. nesle kadar ön saf. Alonso: menzilli hasar.'],
          ['3', 'Mia', "Ayı Tuzağı'nın kilit kahramanı; özel silahı ralli hasarını artırır."],
          ['5', 'Hector', "Infantry tank; Flint'in F2P halefi."],
          ['8', 'Gatot', 'Infantry tank; geç oyunun sarsılmaz kalkanı.'],
          ['10+', 'Blanche, Rufus, Karol', 'Özel silah öncelikleriyle uyumlu yüksek hasar birimleri.'],
        ],
      },
    ],
    cards: [
      { title: 'Seviye & Tecrübe', desc: 'Temel istatistikleri artırır. R/SR geçici; asıl yatırım SSR kahramanlara yapılmalıdır.' },
      { title: 'Yıldız & Parçalar', desc: 'Genel turuncu parçalar kıttır; ilk 4 nesilde idareli harcayın, asıl birikim 5. nesil sonrasına saklanmalıdır.' },
      { title: 'Beceri Yükseltmeleri', desc: 'Expedition ve Exploration becerileri farklı oyun modlarında etkilidir.' },
      { title: 'Özel Silah', desc: 'Yalnızca Jeronimo ve Mia gibi uzun ömürlü (evergreen) kahramanlara öncelik verin.' },
    ],
    notices: [
      {
        type: 'warn',
        title: 'Nesil Kuralı:',
        content: 'Genel turuncu parçaları ilk 4 nesilde "idare edecek kadar" harcayın; asıl birikimi 5. nesil sonrasına saklayın. Uzun ömürlü kahramanlara yatırım yapın: Molly, Flint, Mia, Hector, Jeronimo.',
      },
    ],
  },

  'hero-gear': {
    id: 'hero-gear',
    number: 5,
    navLabel: 'Hero Gear',
    title: '⚔️ 5. Hero Gear — Empowerment (+20 → +60 → +100)',
    subtitle: 'Furnace 15\'te açılır. 3 birlik türü × 4 slot = 12 parça. Her parçanın Empowerment bonusları farklıdır.',
    badge: { text: '✅ Doğrulanmış', type: 'ok' },
    svgType: 'empowerment',
    subsections: [
      {
        title: '5.1 Gerçek Empowerment Bonus Matrisi',
        notices: [
          {
            type: 'warn',
            title: 'Kritik Düzeltme:',
            content: 'Önceki "Belt & Gloves = Health, Goggles & Boots = Lethality" genellemesi eksiktir. Empowerment bonusları parçanın kendi eğrisine göre belirlenir.',
          },
        ],
        tables: [
          {
            headers: ['Parça Grubu', '+20', '+40', '+60', '+80', '+100'],
            rows: [
              ['Eldiven & Bot (Defansif hat)', 'Savunma +%20', 'Sağlık +%7,5', 'Saldırı +%30', 'Kahraman Saldırı +%15', 'Savunma +%50'],
              ['Gözlük & Kemer (Hücum hattı)', 'Saldırı +%20', 'Sağlık +%7,5', 'Savunma +%30', 'Kahraman Saldırı +%15', 'Saldırı +%50'],
            ],
            note: 'Kaynak: 9game.cn Piyade rehberi: Eldiven ve Bot seviye 100 bonusunda Savunma +%50 verir.',
          },
        ],
      },
      {
        title: '5.2 +19 Nedir?',
        notices: [
          {
            type: 'info',
            title: '+19 Eşiği',
            content: 'Legendary bir ekipman parçasının henüz Empowerment yapılmamış son seviyesidir. +19\'a kadar Mithril gerekmez. +19\'dan +20\'ye geçiş ilk Empowerment eşiğidir.',
          },
        ],
      },
      {
        title: '5.3 Kümülatif Maliyet',
        tables: [
          {
            headers: ['Eşik', 'Adım Mithril', 'Adım Mythic', 'Kümülatif Mithril', 'Kümülatif Mythic', 'Ne Sağlar?'],
            rows: [
              ['+19', '0', '0', '0', '0', 'Empowerment öncesi son seviye.'],
              ['+20', '10', '3', '10', '3', 'İlk Empowerment. Savunma veya saldırı bonusu.'],
              ['+40', '20', '5', '30', '8', 'Sağlık +%7,5 (her iki grupta).'],
              ['+60', '30', '5', '60', '13', 'Eldiven/Bot: Saldırı +%30; Gözlük/Kemer: Savunma +%30.'],
              ['+80', '40', '10', '100', '23', 'Kahraman Saldırı +%15.'],
              ['+100', '50', '10', '150', '33', 'Eldiven/Bot: Savunma +%50; Gözlük/Kemer: Saldırı +%50.'],
            ],
            note: 'Bir parçayı +19\'dan +100\'e çıkarmak toplam 150 Mithril + 33 Mythic ekipman gerektirir. Altı parçalık tam set ≈ 900 Mithril.',
          },
        ],
      },
      {
        title: '5.4 Doğru Öncelik Sırası: +20 → +60 → +100',
        notices: [
          {
            type: 'danger',
            title: 'Neden +40 ve +80 atlanır?',
            content: 'F2P oyuncular için Mithril son derece kıttır. +40 sadece %7,5 Sağlık verir, +80 sadece %15 Kahraman Saldırısı verir. Bu ara seviyeler asıl devasa sıçramaları (+20, +60, +100) geciktirir! Önce +20 açılmalı, ardından hedef parça doğrudan +60\'a, sonra +100\'e taşınmalıdır.',
          },
        ],
        priorityBox: {
          title: '🛡️ Piyade (Infantry) — Savunma Odaklı Sıralama',
          items: [
            '1. Eldiven +20 → Savunma +%20. İlk 10 Mithril buraya yatırılır.',
            '2. Kemer +60 → Savunma +%30. Kemer +60 Savunma verir. Eldiveni +60 yapmadan önce Kemer\'i +60\'a taşıyın.',
            '3. Eldiven +100 → Savunma +%50. Piyade için en büyük tek savunma sıçramasıdır.',
          ],
          note: 'Kemer +20 (Saldırı) ve +100 (Saldırı) Piyade için bilinçli olarak atlanmalıdır!',
        },
      },
    ],
  },

  'chief-gear': {
    id: 'chief-gear',
    number: 6,
    navLabel: 'Chief Gear',
    title: '🛡️ 6. Chief Gear — Set Bonusu Kuralı',
    subtitle: 'Furnace 22\'de açılır. 6 parça; tüm yürüyüşlere uygulanır.',
    badge: { text: '✅ Doğrulanmış', type: 'ok' },
    tables: [
      {
        headers: ['Parça Grubu', 'Parçalar', 'Buff\'lanan Birlik', 'Öncelik'],
        rows: [
          ['Torso', 'Coat, Pants', 'Infantry', '1 (En Yüksek)'],
          ['Hand', 'Belt, Weapon', 'Marksman', '2 (Orta)'],
          ['Head & Wrist', 'Cap, Watch', 'Lancer', '3 (Dengeli)'],
        ],
      },
    ],
    notices: [
      {
        type: 'danger',
        title: 'Set bonusu en düşük kaliteli parçaya göre hesaplanır!',
        content: '5 Altın + 1 Mor parça takarsanız, set bonusu tüm parçalar için MOR T1 bonusuna düşer! Tek parçayı aşırı yükseltmek yerine 6 parçayı dengeli ve aynı kalitede tutun.',
      },
      {
        type: 'info',
        title: '3 Parça ve 6 Parça Bonusları:',
        content: 'Aynı kalitede 3 parça tüm birliklere Defense (Savunma); 6 parça ise tüm birliklere Attack (Saldırı) bonusu kazandırır.',
      },
    ],
  },

  'chief-charms': {
    id: 'chief-charms',
    number: 7,
    navLabel: 'Chief Charms',
    title: '💎 7. Chief Charms — Lv.11 Eşiği ve 40:1 Takas',
    subtitle: 'Furnace 25\'te açılır. 6 gear parçası × 3 slot = 18 charm.',
    badge: { text: '✅ Doğrulanmış', type: 'ok' },
    priorityBox: {
      title: 'İki Aşamalı Charm Sıralaması',
      items: [
        '1. Tüm 18 charm\'ı Lv.11\'e getirin. Bu Charm Materials Exchange kilidini açar ve Lv.1–11 Jewel Secrets gerektirmez.',
        '2. Ardından ana birlik türünün charm\'larını Lv.12+ seviyesine taşıyın. Jewel Secrets sadece bu aşamada gereklidir.',
      ],
      note: 'Gear önce, charm sonra kuralını unutmayın; charm çarpanları gear istatistikleriyle katlanır.',
    },
    notices: [
      {
        type: 'warn',
        title: '40:1 Takas Oranı:',
        content: 'Lv.11 sonrası, 40 Charm Guide veya 40 Charm Design → 1 Jewel Secret verir. Bir charm\'ı takasla Lv.16\'ya taşımak yaklaşık 10.400 materyal ister.',
      },
      {
        type: 'info',
        title: 'SvS Penceresi:',
        content: 'Charm yükseltmeleri SvS ve King of Icefield hazırlığında devasa puan kazandırır. Malzemeleri bu pencerelere saklayın.',
      },
    ],
  },

  helios: {
    id: 'helios',
    number: 8,
    navLabel: 'Helios T11',
    title: '🌟 8. Helios T11 — Geç Oyunun Kapısı',
    subtitle: 'War Academy üzerinden açılır ve T12 Exalted\'ın mekanik önkoşuludur; atlanamaz.',
    badge: { text: '✅ Doğrulanmış', type: 'ok' },
    svgType: 'helios-chain',
    tables: [
      {
        headers: ['Tür', 'Rol', 'En İyi Olduğu Yer', 'Açılma Önceliği'],
        rows: [
          ['Helios Infantry', 'Ön saf tank, garnizon savunmacısı', 'Ralli ve SvS garnizonlarında hasar emme', '1 (F2P Önceliği)'],
          ['Helios Marksman', 'Hasar dağıtıcısı, ralli çağırıcı', 'Ayı Tuzağı, hasar etkinlikleri', '2'],
          ['Helios Lancer', 'Marksman sayacı, niş uzman', 'Belirli ittifak sayaçları', '3'],
        ],
      },
      {
        title: 'Bir Helios Türü İçin Gereken Kaynaklar (Tam Dal)',
        headers: ['Kaynak', 'Miktar'],
        rows: [
          ['Fire Crystal Shard', '~13.400 Shard'],
          ['Et / Odun', '246.180.000 / 246.180.000'],
          ['Kömür / Demir / Çelik', '49.116.000 / 12.196.000 / 3.974.000'],
          ['Temel araştırma süresi', '~271 gün (~%70 hız bonusuyla ~159 gün)'],
        ],
      },
    ],
    notices: [
      {
        type: 'warn',
        title: 'FC vs Shard Ayrımı:',
        content: 'Binalar Fire Crystal tüketir; araştırma Fire Crystal Shard tüketir. FC\'leri erken Shard\'a dönüştürmeyin, çünkü War Academy binasının kendisi de FC5 olmalıdır. Dönüşüm oranı: 10 FC → 13 Shard (günlük üst sınır 2.600 Shard).',
      },
    ],
  },

  'helios-oranlar': {
    id: 'helios-oranlar',
    number: 9,
    navLabel: 'Helios 1. Ordu',
    title: '🎯 9. Helios T11 — 1. Ordu ve Alternatifleri',
    subtitle: 'Elinizdeki Helios türlerine ve rolünüze (saldırı/savunma) göre 1. Ordu oranları.',
    badge: { text: '✅ Topluluk + test', type: 'ok' },
    notices: [
      {
        type: 'warn',
        title: 'Karışık Birlik Notu:',
        content: 'Bu oranlar T10 ve altı birliklerle karışık kullanım içindir. 1. Ordu tamamen Helios ise 40/20/40 gibi agresif saldırı oranına geçilebilir. Savunmada daima ön saf (Infantry) yüksek tutulmalıdır.',
      },
    ],
    tables: [
      {
        headers: ['Helios Kompozisyonunuz', 'Rol / Senaryo', '1. Ordu (Temel)', '1. Ordu (Alternatif)', 'Neden?'],
        rows: [
          ['Sadece Helios Infantry', 'Saldırı', '50 / 25 / 25', '55 / 20 / 25', 'Ön safı Helios Infantry ile güçlendirip arkadaki T10 birimlerin daha uzun süre hasar vermesini sağlar.'],
          ['Sadece Helios Infantry', 'Savunma', '70 / 15 / 15', '75 / 10 / 15', 'Savunmada hayatta kalmak her şeydir. Helios Infantry + T10 birlikler saf T10 ordusundan çok daha uzun dayanır.'],
          ['Sadece Helios Lancer', 'Saldırı', '40 / 35 / 25', '35 / 40 / 25', 'Helios Lancer, Marksman birimlerine karşı etkilidir. Düşman Marksman ağırlıklıysa oranı artırın.'],
          ['Sadece Helios Lancer', 'Savunma', '55 / 30 / 15', '50 / 35 / 15', 'Lancer birimleri orta safta tampon oluşturur.'],
          ['Sadece Helios Marksman', 'Saldırı', '35 / 15 / 50', '30 / 15 / 55', 'En yüksek hasar potansiyeli; ancak ön safı tamamen ihmal etmeyin.'],
          ['Sadece Helios Marksman', 'Savunma', '55 / 15 / 30', '60 / 15 / 25', 'Marksman cam top gibidir; savunmada oranı düşürüp Infantry artırılmalıdır.'],
          ['Helios Infantry + Marksman', 'Saldırı', '45 / 15 / 40', '40 / 15 / 45', 'En dengeli saldırı kombinasyonu. Lancer minimumda tutulur.'],
          ['Helios Infantry + Marksman', 'Savunma', '65 / 15 / 20', '70 / 15 / 15', 'Ön saf maksimize edilir, Marksman arka safta destek hasarı verir.'],
          ['Helios Infantry + Lancer', 'Saldırı', '50 / 30 / 20', '45 / 35 / 20', 'Son derece dayanıklı saldırı kompozisyonu.'],
          ['Helios Infantry + Lancer', 'Savunma', '65 / 25 / 10', '70 / 25 / 5', 'En dayanıklı savunma kompozisyonu; garnizonu geçilmez kılar.'],
          ['Tamamı Helios', 'Saldırı', '45 / 20 / 35', '40 / 20 / 40', 'Tüm birlikler Helios olduğunda dengeli ve ölümcül seçim.'],
          ['Tamamı Helios', 'Savunma', '60 / 25 / 15', '65 / 20 / 15', 'En yüksek hayatta kalma süresini verir.'],
        ],
      },
    ],
  },

  'ordu-oranlari': {
    id: 'ordu-oranlari',
    number: 10,
    navLabel: 'Genel Ordu',
    title: '🎯 10. Genel Ordu Oranları — Mod Bazlı',
    subtitle: 'Helios kompozisyonundan bağımsız temel ordu dağılımları.',
    badge: { text: '✅ Topluluk + test', type: 'ok' },
    tables: [
      {
        headers: ['Mod / Durum', '1. Ordu', '2. Ordu', '3. Ordu', 'Gerekçe'],
        rows: [
          ['Dengeli / Açık Alan', '50/20/30', '60/20/20', '40/20/40', '1. ordu dengeli, 2. ordu dayanıklı, 3. ordu hasar odaklı.'],
          ['Garnizon / Savunma', '60/20/20', '60/30/10', '50/20/30', 'Ön saf düşman hasarını emer.'],
          ['Ayı Tuzağı (Bear Trap)', '10/10/80', '10/10/80', '10/10/80', 'Marksman yığılır. En az 5.000 Infantry mutlaka korunmalıdır!'],
          ['Crazy Joe', '90/10/0', '90/10/0', '90/10/0', 'Duvarları ve şehri korumak için saf ön saf.'],
          ['Labyrinth — Tek Ordu', '55/17/28 veya 45/20/35', '—', '—', 'Günün buff bölgesine göre ayarlanır.'],
          ['Labyrinth — 3 Ordu', '60/40/0', '54/3/43', '50/20/30', 'F2P için basamaklı kademelendirme.'],
        ],
      },
    ],
  },

  savas: {
    id: 'savas',
    number: 11,
    navLabel: 'Savaş',
    title: '⚔️ 11. Savaş Mekanikleri — Sayaç Üçgeni, Ralli ve Garnizon',
    subtitle: 'Taş-kağıt-makas: Infantry > Lancer > Marksman > Infantry.',
    badge: { text: '✅ Doğrulanmış', type: 'ok' },
    svgType: 'counter-triangle',
    cards: [
      {
        title: '🎯 Ralli Lideri (Kaptan)',
        desc: '3 kahramanın toplam 9 Expedition becerisi savaşa katılır. Güçlü genel statlar, ralli kapasitesi ve gelişmiş kahramanlar gerekir. Önerilen: Jeronimo, Mia.',
      },
      {
        title: '👥 Ralli Katılımcısı (Joiner)',
        desc: 'Yalnızca ilk kahraman yuvasındaki (en soldaki) kahramanın ilk Expedition becerisi savaşa etki eder. Toplamda sadece 4 katılımcı becerisi aktif olur. Jessie/Jasser/Seo-yoon koyulmalıdır.',
      },
    ],
    notices: [
      {
        type: 'danger',
        title: 'En Pahalı Hata:',
        content: 'Saldırı rallisine Patrick veya Sergey gibi savunma kahramanlarını ilk yuvaya koymak veya Ayı Tuzağı ralisine Gina koymak ralli slotunu bloke eder ve hasarı yere çakar!',
      },
    ],
  },

  kale: {
    id: 'kale',
    number: 12,
    navLabel: 'Kale Savaşı',
    title: '🏰 12. Kale Savaşı (Sunfire Castle)',
    subtitle: '5 saatlik pencerede 2.5 saat ardışık tutulursa doğrudan kazanılır; aksi halde en uzun toplam tutma süresi kazanır.',
    badge: { text: '✅ Resmî Kural', type: 'ok' },
    svgType: 'sunfire-timeline',
    cards: [
      {
        title: '🛡️ Savunma Stratejisi',
        desc: 'Oran: %60 Infantry / %20 Lancer / %20 Marksman. İlk yuva: Patrick, Sergey. İttifak sürekli takviye göndermelidir. Turret kontrolü hayati önem taşır.',
      },
      {
        title: '⚔️ Saldırı Stratejisi',
        desc: 'Çift ralli ile düşman garnizonunun dengesi bozulur. İlk yuva: Jessie veya Jasser. 14:30 UTC öncesi geri alma rakibin ardışık sayacını sıfırlar.',
      },
    ],
  },

  'bear-trap': {
    id: 'bear-trap',
    number: 13,
    navLabel: 'Ayı Tuzağı',
    title: '🐻 13. Ayı Tuzağı (Bear Trap / Bear Hunt) — Eksiksiz Rehber',
    subtitle: '~Her 48 saatte bir açılır; 30 dakika sürer. Ayı birlik öldürmez; amaç maksimum hasar vermektir.',
    badge: { text: '✅ Doğrulanmış', type: 'ok' },
    svgType: 'bear-trap-keys',
    subsections: [
      {
        title: '13.1 Mekanik: Neden Yalnızca İlk Yuva Önemli?',
        notices: [
          {
            type: 'info',
            title: 'Katılımcı Mekaniği',
            content: 'Katılımcı olarak katıldığınızda yalnızca en soldaki kahramanınızın sağ üstteki ilk Expedition becerisi ralliye katkı sağlar. Diğer 2 kahraman yalnızca asker kapasitesi içindir. Bir ralliye en fazla 4 katılımcı becerisi dahil olabilir.',
          },
        ],
      },
      {
        title: '13.2 İdeal Katılımcı Kahramanları',
        tables: [
          {
            headers: ['Kahraman', 'Nesil', 'İlk Expedition Becerisi', 'Etki'],
            rows: [
              ['Jessie', 'Gen 1', 'Stand of Arms', 'Tüm birliklerin verdiği hasar +%5 → +%25 (Lv.5).'],
              ['Jasser', 'Gen 1', 'Technical Genius', 'Tüm birliklerin verdiği hasar +%25\'e kadar.'],
              ['Seo-yoon', 'Gen 1', 'Conquest Drum', 'Tüm birliklerin saldırısını artırır.'],
              ['Jeronimo', 'Gen 1', 'Rallying Cry', 'Tüm birlik hasarı +%25 (Ödeme duvarı).'],
              ['Gwen', 'Gen 5', 'Eagle Vision', 'Tartışmalı: Damage Taken etkisi teorik olarak artırır ancak Ayı\'da çalışmadığına dair güçlü bulgular vardır.'],
              ['Reina', 'Gen 4', '—', '+%25 saldırı/hasar buff\'ı.'],
            ],
          },
        ],
      },
      {
        title: '13.3 Gwen Tartışması Analizi',
        cards: [
          {
            title: '✅ Gwen Lehine Argümanlar',
            desc: 'Eagle Vision Damage Taken debuff\'ı sunar; 5. neslin en güçlü saldırı nişancısıdır ve ralli lideri olarak çok etkilidir.',
            tag: 'Destekleyen',
            tagType: 'ok',
          },
          {
            title: '❌ Gwen Aleyhine Argümanlar',
            desc: 'Ayı Tuzağı\'nda hedef hasar almadığı ve hasar biriktirdiği için alınan hasar artışı çalışmaz; doğrudan Attack buff veren Jessie/Jasser çok daha üstündür.',
            tag: 'Eleştiren',
            tagType: 'bad',
          },
        ],
        notices: [
          {
            type: 'danger',
            title: 'Dengeli Tavsiye:',
            content: 'Katılımcı olarak Gwen göndermeyin! Jessie, Jasser veya Seo-yoon kullanın. Gwen\'i ise ralli lideri olarak rahatlıkla kullanabilirsiniz.',
          },
        ],
      },
    ],
  },

  uzmanlar: {
    id: 'uzmanlar',
    number: 14,
    navLabel: 'Uzmanlar',
    title: '🧑‍🔬 14. Uzmanlar (Experts) — F2P Öncelik Sırası',
    subtitle: 'Dawn Academy üzerinden açılır. F2P için en değerli uzmanlar verimlilik ve kaynak üretenlerdir.',
    badge: { text: '✅ Doğrulanmış', type: 'ok' },
    tables: [
      {
        headers: ['Öncelik', 'Uzman', 'Neden?', 'Önerilen Durma Noktası'],
        rows: [
          ['1', 'Agnes', 'Ekstra Intel görevleri (+8/gün), Mystery Badges (+120/gün), stamina ve inşaat azaltma.', 'Affinity 70 (erken 30→60→100).'],
          ['2', 'Cyrille', 'Ayı Tuzağı uzmanı; ralli kapasitesini ve hasar verimini katlar.', 'Affinity 60.'],
          ['3', 'Baldur', 'İttifak etkinlik ödüllerini artırır.', 'Duruma göre.'],
          ['4', 'Romulus', 'Askeri danışman; savaş istatistikleri.', 'Duruma göre.'],
          ['5', 'Holger', 'Arena odaklı ilerleme için en iyi uzman.', 'Arena oynuyorsanız.'],
        ],
      },
    ],
  },

  evcil: {
    id: 'evcil',
    number: 15,
    navLabel: 'Evcil Hayvanlar',
    title: '🐾 15. Evcil Hayvanlar (Pets) — Tier Listesi ve Öncelik',
    subtitle: 'Furnace 18\'de Beast Cage ile açılır.',
    badge: { text: '✅ Doğrulanmış', type: 'ok' },
    tables: [
      {
        headers: ['Tier', 'Evcil Hayvanlar', 'Kullanım ve Güç'],
        rows: [
          ['S', 'Iron Rhino, Saber-tooth Tiger, Cave Lion, Snow Ape, Frost Gorilla', 'Iron Rhino ralli kapasitesini +60.000→150.000 artırır. Ralli liderleri için zorunludur.'],
          ['A', 'Mammoth, Snow Leopard, Titan Roc', 'Duruma göre savaş desteği sağlar.'],
          ['B', 'Cave Hyena, Musk Ox, Arctic Wolf, Giant Tapir, Giant Elk', 'Gelişim odaklı: Cave Hyena inşaat hızı; Arctic Wolf stamina; Musk Ox anlık kaynak toplama.'],
        ],
      },
    ],
    notices: [
      {
        type: 'info',
        title: 'Erken Oyun Sıralaması:',
        content: 'Cave Hyena (inşaat) → Arctic Wolf (stamina) → Musk Ox (toplama). Geç oyunda ise Iron Rhino ve Cave Lion öne geçer.',
      },
    ],
  },

  etkinlikler: {
    id: 'etkinlikler',
    number: 16,
    navLabel: 'Etkinlikler',
    title: '📅 16. Etkinlik Takvimi',
    subtitle: 'Hangi etkinlik ne sıklıkta yapılır ve ne beklenmelidir?',
    badge: { text: '✅ Doğrulanmış', type: 'ok' },
    tables: [
      {
        headers: ['Etkinlik', 'Sıklık', 'Önemli Bilgi'],
        rows: [
          ['Ayı Tuzağı (Bear Hunt)', '~Her 48 saat', 'PvE; kalıcı kayıp yok. Trap buff her avda tazelenmelidir.'],
          ['Alliance Championship', 'Haftalık', 'Varsayılan 33/33/33 oranını asla kullanmayın; Infantry en az %50 olmalı.'],
          ['Fortress Battles', 'Her Cuma', 'İttifak PvP; 2 saatlik pencere, 30 dk kesintisiz tutuş.'],
          ['Frostfire Mine', '2 haftada bir', 'Solo PvP; 30 dk; Orichalcum madeni topla.'],
          ['Foundry Battle', '2 haftada bir', 'İttifak PvP; bina rolleri önceden organize edilmelidir.'],
          ['SvS / King of Icefield', '4 haftada bir', '5 gün hazırlık + savaş. Kale savaşı 2. saatte başlar.'],
          ['Crazy Joe', 'Aylık', '21 zorluk; dalga 7/14/17 çevrimiçi olun. Oran %90 Infantry.'],
          ['Alliance Mobilization', 'Aylık', 'R4/R5 paylaşılan görevleri her 30 dk\'da yenilemelidir.'],
        ],
      },
    ],
  },

  f2p: {
    id: 'f2p',
    number: 17,
    navLabel: 'F2P vs P2W',
    title: '💰 17. F2P vs P2W — Gerçek Zaman Çizelgesi',
    subtitle: 'Fark içeriğe ne zaman ulaştığınızdadır. Para hız satın alır.',
    badge: { text: '✅ WSCO Verisi', type: 'ok' },
    tables: [
      {
        headers: ['Kilometre Taşı', '€0 (F2P)', '~€10/ay', '~€50/ay', 'Balina (Whale)'],
        rows: [
          ['Furnace 30', '~55–65. gün', '~50. gün', '~40–45. gün', '~35. gün'],
          ['FC5', '~200–240. gün', '~180. gün', '~150. gün', '~110. gün'],
          ['T11 birlikler', '~240–280. gün', '~210. gün', '~170. gün', '~120. gün'],
          ['Legendary Chief Gear', '~220–260. gün', '~190. gün', '~150. gün', '~100. gün'],
          ['FC10 / Tam Yol', '~550–650. gün', '~450. gün', '~340. gün', '~220. gün'],
        ],
      },
    ],
    notices: [
      {
        type: 'info',
        title: '€10/ay Tatlı Noktası:',
        content: 'Growth Fund + Monthly Card kalıcı altyapı satın alır; ötesi yalnızca hız satın alır. Disiplinli bir F2P bir yılın sonunda düzensiz harcayan oyuncuya rahatlıkla yetişir.',
      },
    ],
  },

  tuzaklar: {
    id: 'tuzaklar',
    number: 18,
    navLabel: 'Tuzaklar',
    title: '⚠️ 18. En Pahalı Tuzaklar',
    subtitle: 'Bu hatalar aylarca ilerleme kaybettirir.',
    badge: { text: 'Kritik Uyarılar', type: 'bad' },
    cards: [
      { title: '1. Set bonusunu bozmak', desc: 'Chief Gear\'da tek parçayı aşırı yükseltmek; set bonusu en düşük parçaya eşitlenir.' },
      { title: '2. Mithril\'i atlamak', desc: 'Haftalık Labyrinth Mithril alımını kaçırmak. +19\'dan +100\'e 150 Mithril gerekir.' },
      { title: '3. Katılımcıya Mithril harcamak', desc: 'Jessie ve Jasser ekipmanına Mithril harcamak boşa kaynak israfıdır.' },
      { title: '4. Yanlış ilk yuva', desc: 'Ayı Tuzağı\'na Gina, Molly, Natalia, Bahiti gibi hasar buff\'ı olmayan kahramanları ilk yuvaya koymak.' },
      { title: '5. Lv.11\'den önce charm basmak', desc: 'Charm Materials Exchange\'i geciktirir ve nadir Jewel Secrets\'ı erken harcatır.' },
      { title: '6. Her yeni nesile yatırım', desc: '5 yıldızlı eski nesil kahraman, 1 yıldızlı yeni nesil kahramandan çok daha üstündür.' },
      { title: '7. Helios\'u atlamak', desc: 'T12 Exalted birliklere geçişi tamamen kilitler.' },
      { title: '8. FC\'leri erken Shard yapmak', desc: 'War Academy binasının kendisi de Fire Crystal ister.' },
      { title: '9. Yanlış parçaya Empowerment', desc: 'Piyade için Kemer yerine Eldiven +20 seçilmelidir. Empowerment kalıcıdır ve geri alınamaz!' },
      { title: '10. +40 ve +80\'e takılmak', desc: 'Bu eşikler zayıf stat verir; önce +20 → +60 → +100 hedeflerine odaklanın.' },
    ],
  },

  kaynaklar: {
    id: 'kaynaklar',
    number: 19,
    navLabel: 'Kaynaklar',
    title: '📚 19. Kaynaklar ve Doğrulama',
    subtitle: 'Tüm oyun içi isimler ilgili hak sahiplerine aittir. Bu sayfa kaynak gösteren bağımsız bir referanstır.',
    tables: [
      {
        headers: ['Kaynak', 'Kullanım Alanı', 'Güven Derecesi'],
        rows: [
          ['whiteoutsurvivalhandbook.com', 'Helios T11, Chief Gear, Charms, Gwen rehberi', 'Yüksek'],
          ['WSCO (Whiteout Survival Community)', 'F2P yol haritası, F2P vs P2W, uzman rehberleri', 'Yüksek'],
          ['wos.h5joy-games.com', 'Iron Rhino, Helios maliyet, Ayı hasar rehberi', 'Orta-Yüksek'],
          ['centurygames.helpshift.com', 'Sunfire Castle ve Hero Gear resmî kuralları', 'Resmî'],
          ['heaven-guardian.com', 'Charm Secrets, VIP seviyeleri, ralli rolleri', 'Yüksek'],
          ['altema.jp/whiteoutsurvival', 'Nesil bazlı kahraman analizleri', 'Yüksek'],
        ],
      },
    ],
  },
};
