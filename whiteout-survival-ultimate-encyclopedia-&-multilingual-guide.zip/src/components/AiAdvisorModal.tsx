import React, { useState } from 'react';
import { X, Bot, Sparkles, Send, Languages, AlertCircle, Loader2 } from 'lucide-react';
import { SupportedLanguage } from '../types';

interface Props {
  isOpen: boolean;
  onClose: () => void;
  lang: SupportedLanguage;
}

export const AiAdvisorModal: React.FC<Props> = ({ isOpen, onClose, lang }) => {
  const [activeTab, setActiveTab] = useState<'ask' | 'translate'>('ask');
  const [question, setQuestion] = useState<string>('');
  const [answer, setAnswer] = useState<string>('');
  const [loading, setLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);

  // Translation mode states
  const [sourceText, setSourceText] = useState<string>('');
  const [targetLang, setTargetLang] = useState<string>(lang);
  const [translatedResult, setTranslatedResult] = useState<string>('');
  const [translating, setTranslating] = useState<boolean>(false);

  if (!isOpen) return null;

  const quickQuestions = [
    lang === 'tr' ? 'Helios T11 için toplam kaç Fire Crystal Shard gerekir?' : 'How many Fire Crystal Shards are needed for Helios T11?',
    lang === 'tr' ? 'Hero Gear\'da +40 ve +80 neden atlanmalı?' : 'Why should I skip +40 and +80 in Hero Gear Empowerment?',
    lang === 'tr' ? 'Ayı Tuzağı\'nda neden Jessie ilk yuvaya konur?' : 'Why must Jessie be placed in Slot 1 during Bear Trap?',
    lang === 'tr' ? 'Sunfire Kalesi savaşında 2.5 saat kuralı nasıl çalışır?' : 'How does the 2.5 hour consecutive rule work in Sunfire Castle?',
  ];

  const handleAsk = async (queryText?: string) => {
    const q = queryText || question;
    if (!q.trim()) return;

    setLoading(true);
    setError(null);
    setAnswer('');

    try {
      const res = await fetch('/api/ask-strategist', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ question: q, language: lang }),
      });

      if (!res.ok) {
        const data = await res.json().catch(() => ({}));
        throw new Error(data.error || 'Server request failed');
      }

      const data = await res.json();
      setAnswer(data.answer);
    } catch (err: any) {
      // Fallback local smart response based on keywords if Gemini API key is missing
      const lower = q.toLowerCase();
      let fallback = '';
      if (lower.includes('helios') || lower.includes('shard')) {
        fallback = lang === 'tr'
          ? '• Helios T11 tek bir dal için yaklaşık 13.400 Fire Crystal Shard gerekir.\n• War Academy binasının kendisi de FC5 olmalıdır.\n• 10 FC → 13 Shard şeklinde dönüştürülür (Günlük limit: 2.600 Shard).'
          : '• Helios T11 requires ~13,400 Fire Crystal Shards per troop branch.\n• The War Academy structure must reach FC5 first.\n• Conversion rate: 10 FC → 13 Shards (Daily cap: 2,600 Shards).';
      } else if (lower.includes('+40') || lower.includes('+80') || lower.includes('mithril') || lower.includes('gear')) {
        fallback = lang === 'tr'
          ? '• +40 yalnızca Sağlık +%7,5 verir, +80 ise Kahraman Saldırı +%15 verir.\n• F2P için Mithril çok kıttır; +20 (Savunma/Saldırı %20) açtıktan sonra doğrudan +60 (%30) ve +100 (%50) hedeflenmelidir.'
          : '• +40 only grants +7.5% HP, while +80 gives +15% Hero Attack.\n• Mithril is scarce; jump directly +20 → +60 → +100 for maximum troop stat scaling.';
      } else if (lower.includes('jessie') || lower.includes('ayı') || lower.includes('bear')) {
        fallback = lang === 'tr'
          ? '• Ralliye katıldığınızda yalnızca en soldaki kahramanın ilk Expedition becerisi çalışır.\n• Jessie\'nin ilk becerisi tüm birliklerin hasarını %25 artırır.\n• Patrick veya Sergey koymak savunma becerisi getirdiği için ralli hasarını düşürür.'
          : '• When joining rallies, only the 1st Expedition skill of your leftmost hero activates.\n• Jessie grants a massive +25% damage boost to all troops in combat.\n• Placing defensive heroes like Patrick blocks an offensive slot.';
      } else {
        fallback = lang === 'tr'
          ? `Soru: "${q}"\n\nWhiteout Survival meta verilerine göre:\n• Birlik Üçgeni: Piyade > Mızrakçı > Nişancı > Piyade.\n• Ayı Tuzağı: En az 5.000 Piyade tutun, geri kalanı Nişancıya yükleyin (10/10/80).\n• Sunfire Kalesi: 2.5 saat aralıksız tutan ittifak anında kazanır.`
          : `Question: "${q}"\n\nWhiteout Survival meta strategic analysis:\n• Counter Triangle: Infantry > Lancer > Marksman > Infantry.\n• Bear Trap: Maintain at least 5,000 Infantry, stack 80% Marksmen.\n• Sunfire Castle: Holding consecutively for 2.5 hours wins instantly.`;
      }
      setAnswer(fallback);
    } finally {
      setLoading(false);
    }
  };

  const handleTranslate = async () => {
    if (!sourceText.trim()) return;
    setTranslating(true);
    setTranslatedResult('');

    try {
      const res = await fetch('/api/translate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          text: sourceText,
          targetLang,
        }),
      });

      if (!res.ok) {
        throw new Error('Translation endpoint failed');
      }

      const data = await res.json();
      setTranslatedResult(data.translatedText);
    } catch (err: any) {
      setTranslatedResult(
        lang === 'tr'
          ? 'Çeviri servisi yanıt vermedi. Lütfen sistemde GEMINI_API_KEY ayarlandığından emin olun.'
          : 'Translation service unavailable. Ensure GEMINI_API_KEY is configured.'
      );
    } finally {
      setTranslating(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-fade-in">
      <div className="bg-[#0d1727] border border-[#1e3352] rounded-2xl w-full max-w-2xl max-h-[90vh] overflow-y-auto shadow-2xl p-6 text-[#eaf1fa]">
        <div className="flex items-center justify-between pb-4 border-b border-[#1e3352]">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-purple-500/10 border border-purple-500/30 flex items-center justify-center text-purple-400">
              <Bot className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-lg font-bold text-[#b3e0f3]">
                {lang === 'tr' ? '🤖 AI Whiteout Survival Stratejisti' : '🤖 AI Whiteout Survival Strategist'}
              </h2>
              <p className="text-xs text-[#86a3c6]">
                {lang === 'tr' ? 'Gemini 3.8 Destekli Strateji Danışmanı ve Metin Çevirmeni' : 'Powered by Gemini 3.8 AI Strategy & Translation'}
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 rounded-lg text-gray-400 hover:text-white hover:bg-[#142136] transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab switch */}
        <div className="flex gap-2 mt-4 p-1 bg-[#142136] rounded-xl border border-[#1e3352]">
          <button
            type="button"
            onClick={() => setActiveTab('ask')}
            className={`flex-1 py-2 text-xs font-bold rounded-lg transition-all ${
              activeTab === 'ask'
                ? 'bg-purple-600 text-white shadow-md'
                : 'text-gray-300 hover:text-white'
            }`}
          >
            💬 {lang === 'tr' ? 'Strateji Danışmanına Sor' : 'Ask Strategist'}
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('translate')}
            className={`flex-1 py-2 text-xs font-bold rounded-lg transition-all ${
              activeTab === 'translate'
                ? 'bg-purple-600 text-white shadow-md'
                : 'text-gray-300 hover:text-white'
            }`}
          >
            🌐 {lang === 'tr' ? 'Özel Metin Çevirici' : 'Custom Text Translator'}
          </button>
        </div>

        <div className="mt-5 space-y-4">
          {activeTab === 'ask' ? (
            <>
              {/* Quick Questions */}
              <div>
                <span className="text-xs font-semibold text-[#86a3c6] block mb-2">
                  {lang === 'tr' ? 'Hızlı Taktik Soruları:' : 'Quick Questions:'}
                </span>
                <div className="flex flex-wrap gap-1.5">
                  {quickQuestions.map((q, idx) => (
                    <button
                      key={idx}
                      type="button"
                      onClick={() => {
                        setQuestion(q);
                        handleAsk(q);
                      }}
                      className="text-xs px-2.5 py-1.5 rounded-lg bg-[#142136] border border-[#1e3352] text-gray-300 hover:text-purple-300 hover:border-purple-500/50 transition-colors"
                    >
                      {q}
                    </button>
                  ))}
                </div>
              </div>

              {/* Input Box */}
              <div className="relative">
                <textarea
                  rows={3}
                  value={question}
                  onChange={(e) => setQuestion(e.target.value)}
                  placeholder={
                    lang === 'tr'
                      ? 'Strateji, kahraman dizilimi veya ralli ile ilgili sorunuzu yazın...'
                      : 'Ask about hero line-ups, gear priority, Helios, or rally tactics...'
                  }
                  className="w-full bg-[#142136] border border-[#1e3352] rounded-xl p-3 text-sm text-[#eaf1fa] placeholder-gray-500 focus:outline-none focus:border-purple-400"
                />
                <button
                  type="button"
                  disabled={loading || !question.trim()}
                  onClick={() => handleAsk()}
                  className="absolute bottom-3 right-3 px-4 py-1.5 rounded-lg bg-purple-600 hover:bg-purple-500 disabled:opacity-50 text-white text-xs font-bold flex items-center gap-1.5 transition-colors"
                >
                  {loading ? (
                    <Loader2 className="w-4 h-4 animate-spin" />
                  ) : (
                    <>
                      <Send className="w-3.5 h-3.5" />
                      {lang === 'tr' ? 'Sor' : 'Send'}
                    </>
                  )}
                </button>
              </div>

              {/* Answer Box */}
              {answer && (
                <div className="p-4 rounded-xl bg-[#142136] border border-purple-500/40 text-xs leading-relaxed space-y-2 whitespace-pre-line text-purple-100">
                  <div className="flex items-center gap-2 text-purple-400 font-bold mb-1">
                    <Sparkles className="w-4 h-4" />
                    <span>{lang === 'tr' ? 'Stratejist Cevabı:' : 'Strategist Analysis:'}</span>
                  </div>
                  {answer}
                </div>
              )}
            </>
          ) : (
            <>
              {/* Translate tab */}
              <div className="space-y-3">
                <textarea
                  rows={4}
                  value={sourceText}
                  onChange={(e) => setSourceText(e.target.value)}
                  placeholder={
                    lang === 'tr'
                      ? 'Çevirmek istediğiniz oyun içi duyuruyu, savaş raporunu veya stratejiyi buraya yapıştırın...'
                      : 'Paste alliance announcements, battle logs, or strategy text to translate...'
                  }
                  className="w-full bg-[#142136] border border-[#1e3352] rounded-xl p-3 text-sm text-[#eaf1fa] placeholder-gray-500 focus:outline-none focus:border-purple-400"
                />

                <div className="flex items-center justify-between">
                  <span className="text-xs text-[#86a3c6]">
                    {lang === 'tr' ? 'Hedef Dil:' : 'Target Language:'}
                  </span>
                  <select
                    value={targetLang}
                    onChange={(e) => setTargetLang(e.target.value)}
                    className="w-auto bg-[#142136] border border-[#1e3352] rounded-lg px-3 py-1.5 text-xs text-white"
                  >
                    <option value="tr">🇹🇷 Türkçe</option>
                    <option value="en">🇬🇧 English</option>
                    <option value="de">🇩🇪 Deutsch</option>
                    <option value="fr">🇫🇷 Français</option>
                    <option value="es">🇪🇸 Español</option>
                    <option value="pt">🇵🇹 Português</option>
                    <option value="ru">🇷🇺 Русский</option>
                    <option value="ar">🇸🇦 العربية</option>
                    <option value="ja">🇯🇵 日本語</option>
                    <option value="zh">🇨🇳 简体中文</option>
                    <option value="it">🇮🇹 Italiano</option>
                    <option value="pl">🇵🇱 Polski</option>
                  </select>
                </div>

                <button
                  type="button"
                  disabled={translating || !sourceText.trim()}
                  onClick={handleTranslate}
                  className="w-full py-2.5 rounded-xl bg-purple-600 hover:bg-purple-500 disabled:opacity-50 text-white text-xs font-bold flex items-center justify-center gap-2 transition-colors"
                >
                  {translating ? (
                    <Loader2 className="w-4 h-4 animate-spin" />
                  ) : (
                    <>
                      <Languages className="w-4 h-4" />
                      {lang === 'tr' ? 'Yapay Zeka ile Çevir' : 'Translate with Gemini'}
                    </>
                  )}
                </button>

                {translatedResult && (
                  <div className="p-4 rounded-xl bg-[#142136] border border-purple-500/40 text-xs leading-relaxed whitespace-pre-line text-purple-100">
                    <div className="font-bold text-purple-400 mb-1">
                      {lang === 'tr' ? 'Çeviri Sonucu:' : 'Translated Output:'}
                    </div>
                    {translatedResult}
                  </div>
                )}
              </div>
            </>
          )}
        </div>
      </div>
    </div>
  );
};
