import React, { useState } from 'react';
import { X, Shield, Sparkles, AlertCircle, ArrowRight, CheckCircle2 } from 'lucide-react';
import { SupportedLanguage } from '../types';

interface Props {
  isOpen: boolean;
  onClose: () => void;
  lang: SupportedLanguage;
}

export const GearPlannerModal: React.FC<Props> = ({ isOpen, onClose, lang }) => {
  const [troopType, setTroopType] = useState<'infantry' | 'marksman' | 'lancer'>('infantry');
  const [gearSlot, setGearSlot] = useState<'gloves' | 'belt' | 'goggles' | 'boots'>('gloves');
  const [targetLevel, setTargetLevel] = useState<number>(100);

  if (!isOpen) return null;

  const thresholds = [
    { level: 20, stepMithril: 10, stepMythic: 3, cumMithril: 10, cumMythic: 3 },
    { level: 40, stepMithril: 20, stepMythic: 5, cumMithril: 30, cumMythic: 8 },
    { level: 60, stepMithril: 30, stepMythic: 5, cumMithril: 60, cumMythic: 13 },
    { level: 80, stepMithril: 40, stepMythic: 10, cumMithril: 100, cumMythic: 23 },
    { level: 100, stepMithril: 50, stepMythic: 10, cumMithril: 150, cumMythic: 33 },
  ];

  const currentThreshold = thresholds.find((t) => t.level === targetLevel) || thresholds[4];

  // Determine stat bonus based on slot group:
  // Gloves & Boots: +20 Def 20%, +40 HP 7.5%, +60 Atk 30%, +80 HeroAtk 15%, +100 Def 50%
  // Goggles & Belt: +20 Atk 20%, +40 HP 7.5%, +60 Def 30%, +80 HeroAtk 15%, +100 Atk 50%
  const isDefensiveGroup = gearSlot === 'gloves' || gearSlot === 'boots';

  const getBonusText = (level: number) => {
    if (isDefensiveGroup) {
      switch (level) {
        case 20:
          return lang === 'tr' ? '🛡️ Savunma +%20' : '🛡️ Defense +20%';
        case 40:
          return lang === 'tr' ? '❤️ Sağlık +%7,5' : '❤️ Health +7.5%';
        case 60:
          return lang === 'tr' ? '⚔️ Saldırı +%30' : '⚔️ Attack +30%';
        case 80:
          return lang === 'tr' ? '🦸 Kahraman Saldırı +%15' : '🦸 Hero Attack +15%';
        case 100:
          return lang === 'tr' ? '🛡️ Savunma +%50 (Maksimum)' : '🛡️ Defense +50% (Peak)';
        default:
          return '';
      }
    } else {
      switch (level) {
        case 20:
          return lang === 'tr' ? '⚔️ Saldırı +%20' : '⚔️ Attack +20%';
        case 40:
          return lang === 'tr' ? '❤️ Sağlık +%7,5' : '❤️ Health +7.5%';
        case 60:
          return lang === 'tr' ? '🛡️ Savunma +%30' : '🛡️ Defense +30%';
        case 80:
          return lang === 'tr' ? '🦸 Kahraman Saldırı +%15' : '🦸 Hero Attack +15%';
        case 100:
          return lang === 'tr' ? '⚔️ Saldırı +%50 (Maksimum)' : '⚔️ Attack +50% (Peak)';
        default:
          return '';
      }
    }
  };

  const isRecommendedStep = targetLevel === 20 || targetLevel === 60 || targetLevel === 100;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-fade-in">
      <div className="bg-[#0d1727] border border-[#1e3352] rounded-2xl w-full max-w-2xl max-h-[90vh] overflow-y-auto shadow-2xl p-6 text-[#eaf1fa]">
        <div className="flex items-center justify-between pb-4 border-b border-[#1e3352]">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-amber-500/10 border border-amber-500/30 flex items-center justify-center text-amber-400">
              <Sparkles className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-lg font-bold text-[#b3e0f3]">
                {lang === 'tr' ? 'Hero Gear Empowerment Planlayıcı' : 'Hero Gear Empowerment Planner'}
              </h2>
              <p className="text-xs text-[#86a3c6]">
                {lang === 'tr' ? '+20 → +60 → +100 Öncelik Matrisi ve Mithril Maliyetleri' : '+20 → +60 → +100 Priority Matrix and Mithril Costs'}
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 rounded-lg text-gray-400 hover:text-white hover:bg-[#142136] transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="mt-5 space-y-5">
          {/* Troop Type Tabs */}
          <div>
            <label className="block text-xs font-semibold text-[#86a3c6] uppercase tracking-wider mb-2">
              {lang === 'tr' ? '1. Birlik Türünü Seçin' : '1. Select Troop Type'}
            </label>
            <div className="grid grid-cols-3 gap-2">
              {[
                { id: 'infantry', label: lang === 'tr' ? '🛡️ Piyade' : '🛡️ Infantry', role: lang === 'tr' ? 'Savunma Odaklı' : 'Defense Focus' },
                { id: 'marksman', label: lang === 'tr' ? '🏹 Nişancı' : '🏹 Marksman', role: lang === 'tr' ? 'Saldırı Odaklı' : 'Attack Focus' },
                { id: 'lancer', label: lang === 'tr' ? '⚔️ Mızrakçı' : '⚔️ Lancer', role: lang === 'tr' ? 'Dengeli Flank' : 'Balanced Flank' },
              ].map((t) => (
                <button
                  key={t.id}
                  type="button"
                  onClick={() => {
                    setTroopType(t.id as any);
                    if (t.id === 'infantry') setGearSlot('gloves');
                    if (t.id === 'marksman') setGearSlot('goggles');
                  }}
                  className={`p-3 rounded-xl border text-left transition-all ${
                    troopType === t.id
                      ? 'bg-cyan-950/40 border-cyan-400 text-cyan-200'
                      : 'bg-[#142136] border-[#1e3352] text-gray-300 hover:border-gray-500'
                  }`}
                >
                  <div className="font-bold text-sm">{t.label}</div>
                  <div className="text-[11px] text-[#86a3c6]">{t.role}</div>
                </button>
              ))}
            </div>
          </div>

          {/* Gear Slot */}
          <div>
            <label className="block text-xs font-semibold text-[#86a3c6] uppercase tracking-wider mb-2">
              {lang === 'tr' ? '2. Ekipman Parçası Seçin' : '2. Select Gear Piece'}
            </label>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
              {[
                { id: 'gloves', label: lang === 'tr' ? 'Eldiven' : 'Gloves', group: 'def', note: lang === 'tr' ? 'Defansif Hat' : 'Defensive Line' },
                { id: 'boots', label: lang === 'tr' ? 'Bot' : 'Boots', group: 'def', note: lang === 'tr' ? 'Defansif Hat' : 'Defensive Line' },
                { id: 'goggles', label: lang === 'tr' ? 'Gözlük' : 'Goggles', group: 'atk', note: lang === 'tr' ? 'Hücum Hattı' : 'Offensive Line' },
                { id: 'belt', label: lang === 'tr' ? 'Kemer' : 'Belt', group: 'atk', note: lang === 'tr' ? 'Hücum Hattı' : 'Offensive Line' },
              ].map((s) => (
                <button
                  key={s.id}
                  type="button"
                  onClick={() => setGearSlot(s.id as any)}
                  className={`p-2.5 rounded-xl border text-left transition-all ${
                    gearSlot === s.id
                      ? 'bg-amber-950/40 border-amber-400 text-amber-200'
                      : 'bg-[#142136] border-[#1e3352] text-gray-300 hover:border-gray-500'
                  }`}
                >
                  <div className="font-semibold text-xs">{s.label}</div>
                  <div className="text-[10px] text-[#86a3c6]">{s.note}</div>
                </button>
              ))}
            </div>
          </div>

          {/* Target Empowerment Level */}
          <div>
            <label className="block text-xs font-semibold text-[#86a3c6] uppercase tracking-wider mb-2">
              {lang === 'tr' ? '3. Hedef Empowerment Seviyesi' : '3. Target Empowerment Level'}
            </label>
            <div className="grid grid-cols-5 gap-2">
              {thresholds.map((t) => {
                const isSelected = targetLevel === t.level;
                const isKeyStep = t.level === 20 || t.level === 60 || t.level === 100;
                return (
                  <button
                    key={t.level}
                    type="button"
                    onClick={() => setTargetLevel(t.level)}
                    className={`p-3 rounded-xl border text-center transition-all ${
                      isSelected
                        ? 'bg-cyan-500 text-black font-bold border-cyan-400'
                        : isKeyStep
                        ? 'bg-[#142136] border-cyan-500/50 text-cyan-300'
                        : 'bg-[#142136] border-[#1e3352] text-gray-400 opacity-60'
                    }`}
                  >
                    <div className="text-base font-bold">+{t.level}</div>
                    <div className="text-[10px] mt-0.5">
                      {isKeyStep ? '★ Hedef' : 'Ara'}
                    </div>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Results Summary Box */}
          <div className="p-4 rounded-xl bg-gradient-to-br from-[#142136] to-[#0a121e] border border-[#1e3352] space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <span className="text-xs text-[#86a3c6]">
                  {lang === 'tr' ? 'Kazanılan İstatistik:' : 'Unlocked Stat:'}
                </span>
                <div className="text-lg font-bold text-cyan-300 mt-0.5">
                  {getBonusText(targetLevel)}
                </div>
              </div>
              <div className="text-right">
                <span className="text-xs text-[#86a3c6]">
                  {lang === 'tr' ? 'Toplam Mithril:' : 'Total Mithril:'}
                </span>
                <div className="text-lg font-mono font-bold text-amber-300 mt-0.5">
                  {currentThreshold.cumMithril} Mithril
                </div>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-3 pt-3 border-t border-[#1e3352]/60 text-xs font-mono">
              <div>
                <span className="text-[#86a3c6] block">
                  {lang === 'tr' ? 'Bu Eşik İçin (Adım):' : 'Step Requirement:'}
                </span>
                <span className="text-white font-bold">
                  {currentThreshold.stepMithril} Mithril + {currentThreshold.stepMythic} Mythic Gear
                </span>
              </div>
              <div>
                <span className="text-[#86a3c6] block">
                  {lang === 'tr' ? 'Kümülatif Toplam (+19→+' + targetLevel + '):' : 'Cumulative (+19→+' + targetLevel + '):'}
                </span>
                <span className="text-amber-300 font-bold">
                  {currentThreshold.cumMithril} Mithril + {currentThreshold.cumMythic} Mythic Gear
                </span>
              </div>
            </div>
          </div>

          {/* Golden Rule Callout */}
          <div className="p-4 rounded-xl bg-cyan-950/30 border border-cyan-500/40 text-xs space-y-2">
            <div className="flex items-center gap-2 text-cyan-300 font-bold">
              <CheckCircle2 className="w-4 h-4 text-cyan-400" />
              <span>
                {lang === 'tr'
                  ? 'Bölüm 5 Altın Tavsiyesi: +20 → +60 → +100 Yolunu İzleyin!'
                  : 'Chapter 5 Golden Rule: Follow the +20 → +60 → +100 Path!'}
              </span>
            </div>
            <p className="text-[#86a3c6] leading-relaxed">
              {lang === 'tr'
                ? '+40 (+%7,5 Sağlık) ve +80 (+%15 Kahraman Saldırısı) ara durakları F2P için Mithril israfıdır. Piyade için Eldiven +20 (Savunma %20) açın, ardından Kemer +60 (Savunma %30) yapın, son olarak Eldiven +100 (Savunma %50) hedefleyin.'
                : '+40 (+7.5% HP) and +80 (+15% Hero Atk) checkpoints dilute rare Mithril. For Infantry: unlock Gloves +20 (Def 20%), push Belt +60 (Def 30%), then sprint to Gloves +100 (Def 50%).'}
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};
