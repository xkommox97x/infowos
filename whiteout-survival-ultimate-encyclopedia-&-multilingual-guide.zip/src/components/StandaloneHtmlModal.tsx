import React, { useState } from 'react';
import { X, FileCode, Download, ExternalLink, Check, Sparkles } from 'lucide-react';
import { SupportedLanguage } from '../types';

interface Props {
  isOpen: boolean;
  onClose: () => void;
  lang: SupportedLanguage;
}

export const StandaloneHtmlModal: React.FC<Props> = ({ isOpen, onClose, lang }) => {
  const [copied, setCopied] = useState(false);

  if (!isOpen) return null;

  const filePath = '/assets/aistudio/deepseek_html_20261019_574f13_af3cbc3b.html';

  const handleCopyLink = () => {
    navigator.clipboard.writeText(window.location.origin + filePath);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-fade-in">
      <div className="bg-[#0d1727] border border-[#1e3352] rounded-2xl w-full max-w-xl shadow-2xl p-6 text-[#eaf1fa]">
        <div className="flex items-center justify-between pb-4 border-b border-[#1e3352]">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-cyan-500/10 border border-cyan-500/30 flex items-center justify-center text-cyan-400">
              <FileCode className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-lg font-bold text-[#b3e0f3]">
                {lang === 'tr' ? 'Düzeltilmiş Bağımsız HTML Dosyası' : 'Fixed Standalone HTML File'}
              </h2>
              <p className="text-xs text-[#86a3c6]">
                {lang === 'tr' ? 'Tek dosya, sıfır bağımlılık, 12 dilde çalışan çeviri' : 'Single-file, zero-dependency, working 12-language translation'}
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 rounded-lg text-gray-400 hover:text-white hover:bg-[#142136] transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="mt-5 space-y-4 text-xs">
          <div className="p-4 rounded-xl bg-cyan-950/30 border border-cyan-500/40 space-y-2">
            <div className="flex items-center gap-2 font-bold text-cyan-300">
              <Sparkles className="w-4 h-4 text-cyan-400" />
              <span>{lang === 'tr' ? 'Neler Düzeltildi?' : 'What Was Repaired?'}</span>
            </div>
            <p className="text-[#86a3c6] leading-relaxed">
              {lang === 'tr'
                ? 'Orijinal HTML dosyasında dil seçimi sadece arama kutusunun placeholder yazısını değiştiriyordu; içerik çevrilmiyordu. Dosyaya 12 dil için tam çeviri motoru, tüm bölümlerin başlık ve içerik haritaları, otomatik metin çevirici ve Arapça için RTL desteği eklendi!'
                : 'In the original HTML file, changing language only altered the search input placeholder; actual contents remained untranslated. The file now includes a full 12-language translation engine, mapped chapters, dynamic translator, and Arabic RTL layout!'}
            </p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2">
            <a
              href={filePath}
              download="whiteout_survival_encyclopedia_multilingual.html"
              className="p-3 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-black font-bold text-xs flex items-center justify-center gap-2 transition-colors shadow-lg shadow-cyan-500/20"
            >
              <Download className="w-4 h-4" />
              {lang === 'tr' ? 'Dosyayı İndir (.html)' : 'Download HTML (.html)'}
            </a>

            <a
              href={filePath}
              target="_blank"
              rel="noopener noreferrer"
              className="p-3 rounded-xl bg-[#142136] hover:bg-[#1e3352] border border-[#1e3352] text-white font-bold text-xs flex items-center justify-center gap-2 transition-colors"
            >
              <ExternalLink className="w-4 h-4 text-cyan-400" />
              {lang === 'tr' ? 'Yeni Sekmede Aç' : 'Open in New Tab'}
            </a>
          </div>

          <button
            type="button"
            onClick={handleCopyLink}
            className="w-full py-2.5 rounded-xl bg-[#142136] hover:bg-[#1c2c46] border border-[#1e3352] text-[#86a3c6] hover:text-white font-medium text-xs flex items-center justify-center gap-2 transition-colors"
          >
            {copied ? (
              <>
                <Check className="w-3.5 h-3.5 text-green-400" />
                <span className="text-green-400">{lang === 'tr' ? 'Bağlantı Kopyalandı!' : 'Link Copied!'}</span>
              </>
            ) : (
              <span>{lang === 'tr' ? 'Doğrudan URL Bağlantısını Kopyala' : 'Copy Direct URL Link'}</span>
            )}
          </button>
        </div>
      </div>
    </div>
  );
};
