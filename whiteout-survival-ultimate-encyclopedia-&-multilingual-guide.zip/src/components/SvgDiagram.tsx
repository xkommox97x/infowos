import React from 'react';
import { SupportedLanguage } from '../types';

interface Props {
  type: 'empowerment' | 'helios-chain' | 'counter-triangle' | 'sunfire-timeline' | 'bear-trap-keys';
  lang: SupportedLanguage;
}

export const SvgDiagram: React.FC<Props> = ({ type, lang }) => {
  const isTr = lang === 'tr';

  if (type === 'empowerment') {
    return (
      <div className="bg-[#0d1727] border border-[#1e3352] rounded-2xl p-4 my-4 overflow-x-auto text-center">
        <svg viewBox="0 0 900 280" className="max-w-full h-auto mx-auto" fontFamily="system-ui, sans-serif">
          <rect width="900" height="280" fill="#0d1727" rx="12" />
          <text x="450" y="28" textAnchor="middle" fill="#b3e0f3" fontSize="16" fontWeight="bold">
            {isTr ? 'Empowerment — Doğru Öncelik: +20 → +60 → +100' : 'Empowerment — True Priority: +20 → +60 → +100'}
          </text>

          {/* Infantry Box */}
          <rect x="30" y="55" width="400" height="210" rx="10" fill="#142136" stroke="#f87171" strokeWidth="2" />
          <text x="230" y="80" textAnchor="middle" fill="#f87171" fontSize="14" fontWeight="bold">
            🛡️ {isTr ? 'PİYADE (Infantry)' : 'INFANTRY'}
          </text>
          <rect x="55" y="100" width="350" height="32" rx="6" fill="#2a1518" stroke="#f87171" />
          <text x="230" y="121" textAnchor="middle" fill="#f87171" fontSize="11" fontWeight="bold">
            1. {isTr ? 'Eldiven +20 → Savunma +%20' : 'Gloves +20 → Defense +20%'}
          </text>
          <rect x="55" y="140" width="350" height="32" rx="6" fill="#2a2a15" stroke="#facc15" />
          <text x="230" y="161" textAnchor="middle" fill="#facc15" fontSize="11" fontWeight="bold">
            2. {isTr ? 'Kemer +60 → Savunma +%30' : 'Belt +60 → Defense +30%'}
          </text>
          <rect x="55" y="180" width="350" height="32" rx="6" fill="#1a3a4a" stroke="#54c0ef" />
          <text x="230" y="201" textAnchor="middle" fill="#b3e0f3" fontSize="11" fontWeight="bold">
            3. {isTr ? 'Eldiven +100 → Savunma +%50' : 'Gloves +100 → Defense +50%'}
          </text>
          <text x="230" y="240" textAnchor="middle" fill="#86a3c6" fontSize="10">
            {isTr ? 'Kemer +20 (Saldırı) ve +100 (Saldırı) atlanır.' : 'Belt +20 (Attack) & +100 (Attack) bypassed.'}
          </text>

          {/* Marksman Box */}
          <rect x="470" y="55" width="400" height="210" rx="10" fill="#142136" stroke="#4ade80" strokeWidth="2" />
          <text x="670" y="80" textAnchor="middle" fill="#4ade80" fontSize="14" fontWeight="bold">
            🏹 {isTr ? 'NİŞANCI (Marksman)' : 'MARKSMAN'}
          </text>
          <rect x="495" y="100" width="350" height="32" rx="6" fill="#1a2a18" stroke="#4ade80" />
          <text x="670" y="121" textAnchor="middle" fill="#4ade80" fontSize="11" fontWeight="bold">
            1. {isTr ? 'Gözlük +20 → Saldırı +%20' : 'Goggles +20 → Attack +20%'}
          </text>
          <rect x="495" y="140" width="350" height="32" rx="6" fill="#2a2a15" stroke="#facc15" />
          <text x="670" y="161" textAnchor="middle" fill="#facc15" fontSize="11" fontWeight="bold">
            2. {isTr ? 'Eldiven/Bot +60 → Saldırı +%30' : 'Gloves/Boots +60 → Attack +30%'}
          </text>
          <rect x="495" y="180" width="350" height="32" rx="6" fill="#1a3a4a" stroke="#54c0ef" />
          <text x="670" y="201" textAnchor="middle" fill="#b3e0f3" fontSize="11" fontWeight="bold">
            3. {isTr ? 'Gözlük +100 → Saldırı +%50' : 'Goggles +100 → Attack +50%'}
          </text>
          <text x="670" y="240" textAnchor="middle" fill="#86a3c6" fontSize="10">
            {isTr ? 'Eldiven +20 (Savunma) ve Kemer +60 (Savunma) atlanır.' : 'Gloves +20 (Def) & Belt +60 (Def) bypassed.'}
          </text>
        </svg>
        <div className="text-xs text-[#86a3c6] mt-2">
          {isTr ? 'Şekil 1 — Birlik türüne göre +20 → +60 → +100 önceliği.' : 'Figure 1 — Priority flow: +20 → +60 → +100 by troop class.'}
        </div>
      </div>
    );
  }

  if (type === 'helios-chain') {
    return (
      <div className="bg-[#0d1727] border border-[#1e3352] rounded-2xl p-4 my-4 overflow-x-auto text-center">
        <svg viewBox="0 0 860 160" className="max-w-full h-auto mx-auto" fontFamily="system-ui, sans-serif">
          <defs>
            <marker id="ar1" markerWidth="10" markerHeight="7" refX="10" refY="3.5" orient="auto">
              <polygon points="0 0,10 3.5,0 7" fill="#54c0ef" />
            </marker>
          </defs>

          <rect x="15" y="45" width="155" height="65" rx="8" fill="#142136" stroke="#facc15" strokeWidth="2" />
          <text x="92" y="70" textAnchor="middle" fill="#facc15" fontWeight="bold" fontSize="11">
            {isTr ? 'Sunucu Yaşı' : 'Server Age'}
          </text>
          <text x="92" y="90" textAnchor="middle" fill="#86a3c6" fontSize="10">~{isTr ? 'Gün' : 'Day'} 220–230</text>

          <rect x="190" y="45" width="155" height="65" rx="8" fill="#142136" stroke="#facc15" strokeWidth="2" />
          <text x="267" y="70" textAnchor="middle" fill="#facc15" fontWeight="bold" fontSize="11">
            {isTr ? 'Gen 4 Kahraman' : 'Gen 4 Heroes'}
          </text>
          <text x="267" y="90" textAnchor="middle" fill="#86a3c6" fontSize="10">
            {isTr ? 'Mevcut olmalı' : 'Must be active'}
          </text>

          <rect x="365" y="45" width="155" height="65" rx="8" fill="#142136" stroke="#facc15" strokeWidth="2" />
          <text x="442" y="70" textAnchor="middle" fill="#facc15" fontWeight="bold" fontSize="11">
            {isTr ? 'Furnace FC5' : 'Furnace FC5'}
          </text>
          <text x="442" y="90" textAnchor="middle" fill="#86a3c6" fontSize="10">{isTr ? 'Zorunlu' : 'Mandatory'}</text>

          <rect x="540" y="45" width="155" height="65" rx="8" fill="#142136" stroke="#facc15" strokeWidth="2" />
          <text x="617" y="70" textAnchor="middle" fill="#facc15" fontWeight="bold" fontSize="11">
            War Academy FC5
          </text>
          <text x="617" y="90" textAnchor="middle" fill="#86a3c6" fontSize="10">
            {isTr ? 'Ayrı FC5 Seviyesi' : 'Separate FC5'}
          </text>

          <rect x="715" y="45" width="130" height="65" rx="8" fill="#1a3a4a" stroke="#54c0ef" strokeWidth="2.5" />
          <text x="780" y="70" textAnchor="middle" fill="#b3e0f3" fontWeight="bold" fontSize="12">
            Helios T11
          </text>
          <text x="780" y="90" textAnchor="middle" fill="#86a3c6" fontSize="10">~13.400 Shard</text>

          <line x1="170" y1="77" x2="188" y2="77" stroke="#54c0ef" strokeWidth="2" markerEnd="url(#ar1)" />
          <line x1="345" y1="77" x2="363" y2="77" stroke="#54c0ef" strokeWidth="2" markerEnd="url(#ar1)" />
          <line x1="520" y1="77" x2="538" y2="77" stroke="#54c0ef" strokeWidth="2" markerEnd="url(#ar1)" />
          <line x1="695" y1="77" x2="713" y2="77" stroke="#54c0ef" strokeWidth="2" markerEnd="url(#ar1)" />
        </svg>
        <div className="text-xs text-[#86a3c6] mt-2">
          {isTr ? 'Şekil 2 — Helios T11 açılma zinciri. 4 kapı da aynı anda açık olmalıdır.' : 'Figure 2 — Helios T11 unlock prerequisites.'}
        </div>
      </div>
    );
  }

  if (type === 'counter-triangle') {
    return (
      <div className="bg-[#0d1727] border border-[#1e3352] rounded-2xl p-4 my-4 overflow-x-auto text-center">
        <svg viewBox="0 0 600 280" className="max-w-full h-auto mx-auto" fontFamily="system-ui, sans-serif">
          <defs>
            <marker id="arrow" markerWidth="10" markerHeight="7" refX="10" refY="3.5" orient="auto">
              <polygon points="0 0,10 3.5,0 7" fill="#54c0ef" />
            </marker>
          </defs>

          {/* Infantry Top Circle */}
          <circle cx="300" cy="60" r="50" fill="#2a1518" stroke="#f87171" strokeWidth="3" />
          <text x="300" y="58" textAnchor="middle" fill="#f87171" fontWeight="bold" fontSize="14">
            Infantry
          </text>
          <text x="300" y="76" textAnchor="middle" fill="#86a3c6" fontSize="11">
            {isTr ? 'Piyade' : 'Frontline'}
          </text>

          {/* Lancer Bottom Left Circle */}
          <circle cx="140" cy="220" r="50" fill="#2a2a15" stroke="#facc15" strokeWidth="3" />
          <text x="140" y="218" textAnchor="middle" fill="#facc15" fontWeight="bold" fontSize="14">
            Lancer
          </text>
          <text x="140" y="236" textAnchor="middle" fill="#86a3c6" fontSize="11">
            {isTr ? 'Mızrakçı' : 'Flank'}
          </text>

          {/* Marksman Bottom Right Circle */}
          <circle cx="460" cy="220" r="50" fill="#1a2a18" stroke="#4ade80" strokeWidth="3" />
          <text x="460" y="218" textAnchor="middle" fill="#4ade80" fontWeight="bold" fontSize="14">
            Marksman
          </text>
          <text x="460" y="236" textAnchor="middle" fill="#86a3c6" fontSize="11">
            {isTr ? 'Nişancı' : 'Backline'}
          </text>

          {/* Connecting Arrows */}
          <line x1="255" y1="90" x2="175" y2="185" stroke="#54c0ef" strokeWidth="2.5" markerEnd="url(#arrow)" />
          <line x1="185" y1="235" x2="415" y2="235" stroke="#54c0ef" strokeWidth="2.5" markerEnd="url(#arrow)" />
          <line x1="425" y1="185" x2="345" y2="90" stroke="#54c0ef" strokeWidth="2.5" markerEnd="url(#arrow)" />

          <text x="300" y="270" textAnchor="middle" fill="#b3e0f3" fontSize="11" fontWeight="bold">
            Infantry → Lancer → Marksman → Infantry
          </text>
        </svg>
        <div className="text-xs text-[#86a3c6] mt-2">
          {isTr ? 'Şekil 3 — Birlik sayaç üçgeni (Taş-Kağıt-Makas).' : 'Figure 3 — Troop counter triangle dynamics.'}
        </div>
      </div>
    );
  }

  if (type === 'sunfire-timeline') {
    return (
      <div className="bg-[#0d1727] border border-[#1e3352] rounded-2xl p-4 my-4 overflow-x-auto text-center">
        <svg viewBox="0 0 860 140" className="max-w-full h-auto mx-auto" fontFamily="system-ui, sans-serif">
          <rect x="20" y="45" width="820" height="35" rx="6" fill="#142136" stroke="#1e3352" />
          <rect x="20" y="45" width="410" height="35" rx="6" fill="#1a3a4a" stroke="#54c0ef" />
          <rect x="430" y="45" width="410" height="35" rx="6" fill="#2a1518" stroke="#f87171" />

          <text x="225" y="68" textAnchor="middle" fill="#b3e0f3" fontWeight="bold" fontSize="11">
            {isTr ? '2.5 SAAT ARDIŞIK TEMİZ KAZANMA' : '2.5 HOURS CONSECUTIVE INSTANT WIN'}
          </text>
          <text x="635" y="68" textAnchor="middle" fill="#f87171" fontWeight="bold" fontSize="11">
            {isTr ? 'KÜMÜLATİF SÜRE BARIŞI' : 'CUMULATIVE CONTROL TIME WIN'}
          </text>

          <line x1="20" y1="25" x2="20" y2="95" stroke="#86a3c6" strokeWidth="1.5" />
          <text x="20" y="18" textAnchor="middle" fill="#86a3c6" fontSize="9">12:00 UTC</text>

          <line x1="430" y1="25" x2="430" y2="95" stroke="#facc15" strokeWidth="2.5" />
          <text x="430" y="18" textAnchor="middle" fill="#facc15" fontWeight="bold" fontSize="10">14:30 UTC</text>
          <text x="430" y="112" textAnchor="middle" fill="#facc15" fontSize="9">
            {isTr ? 'Temiz kazanma için son başlangıç' : 'Last start for clean sweep'}
          </text>

          <line x1="840" y1="25" x2="840" y2="95" stroke="#86a3c6" strokeWidth="1.5" />
          <text x="840" y="18" textAnchor="middle" fill="#86a3c6" fontSize="9">17:00 UTC</text>
        </svg>
        <div className="text-xs text-[#86a3c6] mt-2">
          {isTr ? 'Şekil 4 — Sunfire Kalesi zaman penceresi ve zafer koşulları.' : 'Figure 4 — Sunfire Castle 5-hour tournament timeline.'}
        </div>
      </div>
    );
  }

  // bear-trap-keys
  return (
    <div className="bg-[#0d1727] border border-[#1e3352] rounded-2xl p-4 my-4 overflow-x-auto text-center">
      <svg viewBox="0 0 860 220" className="max-w-full h-auto mx-auto" fontFamily="system-ui, sans-serif">
        <rect width="860" height="220" fill="#0d1727" rx="12" />
        <text x="430" y="28" textAnchor="middle" fill="#b3e0f3" fontSize="15" fontWeight="bold">
          {isTr ? 'Ayı Tuzağı — Maksimum Hasar İçin 6 Altın Kural' : 'Bear Trap — 6 Pillars for Maximum Damage'}
        </text>

        <rect x="30" y="55" width="240" height="70" rx="8" fill="#2a1518" stroke="#f87171" />
        <text x="150" y="78" textAnchor="middle" fill="#f87171" fontSize="11" fontWeight="bold">
          {isTr ? '1. Daha Fazla Ralli' : '1. Squeeze More Rallies'}
        </text>
        <text x="150" y="96" textAnchor="middle" fill="#eaf1fa" fontSize="9">
          {isTr ? '30 dk\'da 6 ralli' : '6 rallies in 30 mins'}
        </text>
        <text x="150" y="112" textAnchor="middle" fill="#86a3c6" fontSize="9">
          {isTr ? 'Her 5 dk\'da bir ralli' : 'Every 5 min cooldown'}
        </text>

        <rect x="290" y="55" width="240" height="70" rx="8" fill="#1a3a4a" stroke="#54c0ef" />
        <text x="410" y="78" textAnchor="middle" fill="#b3e0f3" fontSize="11" fontWeight="bold">
          {isTr ? '2. Trap Buff %25' : '2. Trap Buff +25%'}
        </text>
        <text x="410" y="96" textAnchor="middle" fill="#eaf1fa" fontSize="9">
          Explosive Arrowhead
        </text>
        <text x="410" y="112" textAnchor="middle" fill="#86a3c6" fontSize="9">
          {isTr ? 'Her avda tazelenmeli' : 'Recharge every hunt'}
        </text>

        <rect x="550" y="55" width="240" height="70" rx="8" fill="#2a2a15" stroke="#facc15" />
        <text x="670" y="78" textAnchor="middle" fill="#facc15" fontSize="11" fontWeight="bold">
          {isTr ? '3. Tuzağa Sıfır Mesafe' : '3. Relocate Next to Trap'}
        </text>
        <text x="670" y="96" textAnchor="middle" fill="#eaf1fa" fontSize="9">
          {isTr ? 'Sıfır yürüyüş süresi' : 'Zero travel delay'}
        </text>
        <text x="670" y="112" textAnchor="middle" fill="#86a3c6" fontSize="9">
          {isTr ? 'Daha çok vuruş' : 'Fast returns'}
        </text>

        <rect x="30" y="135" width="240" height="70" rx="8" fill="#1a2a18" stroke="#4ade80" />
        <text x="150" y="158" textAnchor="middle" fill="#4ade80" fontSize="11" fontWeight="bold">
          {isTr ? '4. Doğru Kahramanlar' : '4. Correct Heroes'}
        </text>
        <text x="150" y="176" textAnchor="middle" fill="#eaf1fa" fontSize="9">
          Jeronimo (Lider)
        </text>
        <text x="150" y="192" textAnchor="middle" fill="#86a3c6" fontSize="9">
          Jessie (İlk Yuva)
        </text>

        <rect x="290" y="135" width="240" height="70" rx="8" fill="#2a1518" stroke="#f87171" />
        <text x="410" y="158" textAnchor="middle" fill="#f87171" fontSize="11" fontWeight="bold">
          {isTr ? '5. Oran Ayarı' : '5. Personal Ratios'}
        </text>
        <text x="410" y="176" textAnchor="middle" fill="#eaf1fa" fontSize="9">
          Min 5.000 Piyade
        </text>
        <text x="410" y="192" textAnchor="middle" fill="#86a3c6" fontSize="9">
          Nişancı %80-85+
        </text>

        <rect x="550" y="135" width="240" height="70" rx="8" fill="#1a3a4a" stroke="#54c0ef" />
        <text x="670" y="158" textAnchor="middle" fill="#b3e0f3" fontSize="11" fontWeight="bold">
          {isTr ? '6. Dolu Katılımcı Yuvası' : '6. Coordinated Joiners'}
        </text>
        <text x="670" y="176" textAnchor="middle" fill="#eaf1fa" fontSize="9">
          Jessie / Jasser
        </text>
        <text x="670" y="192" textAnchor="middle" fill="#86a3c6" fontSize="9">
          {isTr ? 'Boş slot bırakmayın' : 'Fill all 4 buffs'}
        </text>
      </svg>
      <div className="text-xs text-[#86a3c6] mt-2">
        {isTr ? 'Şekil 5 — Ayı Tuzağı\'nda maksimum hasar üretmenin 6 esası.' : 'Figure 5 — Six core principles of Bear Trap optimization.'}
      </div>
    </div>
  );
};
