import React, { useState } from 'react';
import { X, Target, Users, AlertTriangle, CheckCircle2, Flame, HelpCircle } from 'lucide-react';
import { SupportedLanguage } from '../types';

interface Props {
  isOpen: boolean;
  onClose: () => void;
  lang: SupportedLanguage;
}

export const BearTrapAssistantModal: React.FC<Props> = ({ isOpen, onClose, lang }) => {
  const [activeTab, setActiveTab] = useState<'joiner' | 'leader' | 'gwen'>('joiner');

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-fade-in">
      <div className="bg-[#0d1727] border border-[#1e3352] rounded-2xl w-full max-w-2xl max-h-[90vh] overflow-y-auto shadow-2xl p-6 text-[#eaf1fa]">
        <div className="flex items-center justify-between pb-4 border-b border-[#1e3352]">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-red-500/10 border border-red-500/30 flex items-center justify-center text-red-400">
              <Flame className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-lg font-bold text-[#b3e0f3]">
                {lang === 'tr' ? '🐻 Ayı Tuzağı Katılımcı & Lider Asistanı' : '🐻 Bear Trap Leader & Joiner Assistant'}
              </h2>
              <p className="text-xs text-[#86a3c6]">
                {lang === 'tr' ? 'Bölüm 13 Mekanikleri: İlk Yuva Kuralı ve Maksimum Hasar' : 'Chapter 13 Mechanics: Slot 1 Priority and Max Damage'}
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 rounded-lg text-gray-400 hover:text-white hover:bg-[#142136] transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab Navigation */}
        <div className="flex gap-2 mt-4 p-1 bg-[#142136] rounded-xl border border-[#1e3352]">
          <button
            type="button"
            onClick={() => setActiveTab('joiner')}
            className={`flex-1 py-2 text-xs font-bold rounded-lg transition-all ${
              activeTab === 'joiner'
                ? 'bg-cyan-500 text-black shadow-md'
                : 'text-gray-300 hover:text-white'
            }`}
          >
            👥 {lang === 'tr' ? 'Ralli Katılımcısı (Joiner)' : 'Rally Joiner'}
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('leader')}
            className={`flex-1 py-2 text-xs font-bold rounded-lg transition-all ${
              activeTab === 'leader'
                ? 'bg-cyan-500 text-black shadow-md'
                : 'text-gray-300 hover:text-white'
            }`}
          >
            🎯 {lang === 'tr' ? 'Ralli Lideri (Kaptan)' : 'Rally Leader'}
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('gwen')}
            className={`flex-1 py-2 text-xs font-bold rounded-lg transition-all ${
              activeTab === 'gwen'
                ? 'bg-cyan-500 text-black shadow-md'
                : 'text-gray-300 hover:text-white'
            }`}
          >
            ⚖️ {lang === 'tr' ? 'Gwen Tartışması' : 'Gwen Analysis'}
          </button>
        </div>

        <div className="mt-5 space-y-4">
          {activeTab === 'joiner' && (
            <>
              <div className="p-4 rounded-xl bg-cyan-950/30 border border-cyan-500/40 text-xs">
                <span className="font-bold text-cyan-300 block mb-1">
                  {lang === 'tr' ? '⚡ Katılımcı İçin 1 Numaralı Altın Kural:' : '⚡ Golden Rule for Joiners:'}
                </span>
                <p className="text-[#86a3c6]">
                  {lang === 'tr'
                    ? 'Ralliye katıldığınızda YALNIZCA en soldaki kahramanınızın ilk (sağ üst) Expedition becerisi savaşa etki eder. Diğer 2 kahraman yalnızca asker kapasitesi taşır. Rallide en fazla 4 katılımcı becerisi aktifleşebilir.'
                    : 'When joining, ONLY the top-right Expedition skill of your leftmost hero contributes to combat. The other 2 heroes only supply troop capacity. Exactly 4 joiner skills activate per rally.'}
                </p>
              </div>

              <div className="space-y-2">
                <span className="text-xs font-bold text-[#86a3c6] uppercase tracking-wider block">
                  {lang === 'tr' ? 'İdeal Katılımcı İlk Yuva Sıralaması:' : 'Optimal Slot 1 Joiner Tier List:'}
                </span>

                {[
                  {
                    rank: '1',
                    hero: 'Jessie',
                    skill: 'Stand of Arms',
                    effect: lang === 'tr' ? 'Tüm birliklerin verdiği hasar +%5 → +%25 (Lv.5)' : 'All troop damage dealt +5% → +25% (Lv.5)',
                    badge: 'SS Tier',
                  },
                  {
                    rank: '2',
                    hero: 'Jasser',
                    skill: 'Technical Genius',
                    effect: lang === 'tr' ? 'Tüm birliklerin verdiği hasar +%25\'e kadar' : 'All troop damage dealt up to +25%',
                    badge: 'SS Tier',
                  },
                  {
                    rank: '3',
                    hero: 'Seo-yoon',
                    skill: 'Conquest Drum',
                    effect: lang === 'tr' ? 'Tüm birliklerin saldırısını doğrudan artırır' : 'Flat troop attack buff for all units',
                    badge: 'S Tier',
                  },
                  {
                    rank: '4',
                    hero: 'Jeronimo',
                    skill: 'Rallying Cry',
                    effect: lang === 'tr' ? 'Tüm birlik hasarı +%25 (Ödeme duvarı)' : 'All troop damage +25% (Paywalled staple)',
                    badge: 'S Tier',
                  },
                ].map((item) => (
                  <div
                    key={item.hero}
                    className="p-3 rounded-xl bg-[#142136] border border-[#1e3352] flex items-center justify-between"
                  >
                    <div className="flex items-center gap-3">
                      <div className="w-7 h-7 rounded-lg bg-cyan-500/20 text-cyan-300 font-bold flex items-center justify-center text-xs">
                        #{item.rank}
                      </div>
                      <div>
                        <div className="font-bold text-sm text-white flex items-center gap-2">
                          {item.hero}
                          <span className="text-[10px] font-mono px-1.5 py-0.5 rounded bg-cyan-950 text-cyan-300 border border-cyan-800">
                            {item.skill}
                          </span>
                        </div>
                        <div className="text-xs text-[#86a3c6] mt-0.5">{item.effect}</div>
                      </div>
                    </div>
                    <span className="text-xs font-bold text-green-400 bg-green-950/40 border border-green-800 px-2 py-1 rounded-lg">
                      {item.badge}
                    </span>
                  </div>
                ))}
              </div>

              <div className="p-3 rounded-xl bg-red-950/40 border border-red-500/50 flex items-start gap-2 text-xs text-red-300">
                <AlertTriangle className="w-4 h-4 text-red-400 flex-shrink-0 mt-0.5" />
                <div>
                  <span className="font-bold block">
                    {lang === 'tr' ? 'İlk Yuvaya ASLA Koymamanız Gerekenler:' : 'Heroes to NEVER place in Slot 1:'}
                  </span>
                  <span className="text-[#86a3c6]">
                    Gina, Bahiti, Natalia, Molly, Sergey, Patrick. Bu kahramanlar Ayı Tuzağı\'nda hiçbir hasar artışı sağlamaz ve Jessie/Jasser gönderebilecek başka bir müttefikin slotunu gasp eder!
                  </span>
                </div>
              </div>
            </>
          )}

          {activeTab === 'leader' && (
            <div className="space-y-4 text-xs">
              <div className="p-4 rounded-xl bg-[#142136] border border-[#1e3352] space-y-2">
                <span className="font-bold text-sm text-[#b3e0f3] block">
                  🎯 {lang === 'tr' ? 'Ralli Lideri Neden Farklıdır?' : 'Why Rally Leaders Are Different'}
                </span>
                <p className="text-[#86a3c6] leading-relaxed">
                  {lang === 'tr'
                    ? 'Ralli liderinin 3 kahramanının TÜM Expedition becerileri (toplam 9 beceri) savaşa katılır. Bu yüzden lider yüksek statlı, özel silahlı ve saldırı buff\'lı SSR kahramanlarla yola çıkmalıdır.'
                    : 'A rally leader carries ALL 9 Expedition skills (3 heroes × 3 skills) into combat. Leaders require top-stat SSR heroes with exclusive gear and high multiplier synergy.'}
                </p>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div className="p-3 rounded-xl bg-[#142136] border border-[#1e3352]">
                  <span className="font-bold text-cyan-300 block mb-1">
                    {lang === 'tr' ? 'Önerilen Piyade Lideri:' : 'Recommended Infantry Lead:'}
                  </span>
                  <span className="text-white font-medium">Jeronimo &gt; Hector &gt; Natalia &gt; Flint</span>
                </div>
                <div className="p-3 rounded-xl bg-[#142136] border border-[#1e3352]">
                  <span className="font-bold text-yellow-300 block mb-1">
                    {lang === 'tr' ? 'Önerilen Mızrakçı Lideri:' : 'Recommended Lancer Lead:'}
                  </span>
                  <span className="text-white font-medium">Dominic &gt; Mia (Özel Silah ≥6) &gt; Karol</span>
                </div>
              </div>

              <div className="p-3 rounded-xl bg-amber-950/30 border border-amber-500/40">
                <span className="font-bold text-amber-300 block mb-1">
                  🏹 {lang === 'tr' ? 'Taktik İpuçları:' : 'Tactical Pro-Tips:'}
                </span>
                <ul className="list-disc pl-4 space-y-1 text-[#86a3c6]">
                  <li>{lang === 'tr' ? 'Şehrinizi tuzağın hemen dibine taşıyın (yürüyüş süresi kısalır, 30 dakikaya 6 ralli sığar).' : 'Relocate directly adjacent to the trap to minimize march time and squeeze 6 rallies into 30 mins.'}</li>
                  <li>{lang === 'tr' ? 'Patlayıcı Ok Ucu (Explosive Arrowhead) bağışı ile ralli hasarını %25 artırın.' : 'Donate Explosive Arrowheads to cap the alliance damage buff at +25%.'}</li>
                </ul>
              </div>
            </div>
          )}

          {activeTab === 'gwen' && (
            <div className="space-y-4 text-xs">
              <div className="p-4 rounded-xl bg-gradient-to-br from-[#142136] to-[#0a121e] border border-[#1e3352]">
                <h3 className="font-bold text-sm text-[#b3e0f3] mb-2">
                  {lang === 'tr' ? 'Gwen\'in Ayı Tuzağı\'ndaki Rolü: Neden Tartışmalı?' : 'The Gwen Controversy Explained'}
                </h3>
                <p className="text-[#86a3c6] leading-relaxed mb-3">
                  {lang === 'tr'
                    ? 'Gwen, 5. neslin en güçlü hasar nişancısıdır. Ancak Ayı Tuzağı\'nda katılımcı olarak kullanılıp kullanılmaması konusunda topluluk ikiye bölünmüştür:'
                    : 'Gwen is the strongest marksman of Generation 5. However, the community is divided on whether she should be used as a rally joiner:'}
                </p>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div className="p-3 rounded-lg bg-green-950/30 border border-green-800">
                    <span className="font-bold text-green-400 block mb-1">
                      ✅ {lang === 'tr' ? 'Gwen Lehine:' : 'Pro-Gwen Camp:'}
                    </span>
                    <p className="text-[#86a3c6]">
                      {lang === 'tr'
                        ? 'Eagle Vision yeteneği %25 "Alınan Hasar" artışı sağlar. Ralli lideri olarak tüm becerileri aktiftir.'
                        : 'Eagle Vision inflicts a 25% "Damage Taken" debuff. Outstanding as a rally captain.'}
                    </p>
                  </div>
                  <div className="p-3 rounded-lg bg-red-950/30 border border-red-800">
                    <span className="font-bold text-red-400 block mb-1">
                      ❌ {lang === 'tr' ? 'Gwen Aleyhine:' : 'Anti-Gwen Camp:'}
                    </span>
                    <p className="text-[#86a3c6]">
                      {lang === 'tr'
                        ? 'Ayı ölmeyen bir dummy hedeftir; debuff formülü çalışmaz. Katılımcı olarak Jessie\'nin yerini gasp eder.'
                        : 'The Bear does not register real debuffs cleanly. Sending her as a joiner steals a slot from Jessie.'}
                    </p>
                  </div>
                </div>

                <div className="mt-4 p-3 rounded-lg bg-cyan-950/40 border border-cyan-500/50">
                  <span className="font-bold text-cyan-300 block mb-1">
                    💎 {lang === 'tr' ? 'Net ve Kesin Sonuç:' : 'Final Pragmatic Verdict:'}
                  </span>
                  <p className="text-[#86a3c6]">
                    {lang === 'tr'
                      ? 'Katılımcı olarak ralliye katılıyorsanız Gwen yerine Jessie, Jasser veya Seo-yoon gönderin! Gwen\'i ise kendi başlattığınız rallilerde LİDER olarak kullanın.'
                      : 'When joining rallies, stick strictly to Jessie, Jasser, or Seo-yoon. Deploy Gwen as a RALLY LEADER instead where all 3 of her skills shine.'}
                  </p>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
