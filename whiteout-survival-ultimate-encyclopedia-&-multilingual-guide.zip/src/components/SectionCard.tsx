import React from 'react';
import { SectionContent, SupportedLanguage } from '../types';
import { SvgDiagram } from './SvgDiagram';
import { AlertTriangle, AlertOctagon, Info, CheckCircle2, ChevronRight } from 'lucide-react';
import { SECTIONS_TR } from '../data/sections_tr';

interface Props {
  section: SectionContent;
  lang: SupportedLanguage;
  dualView: boolean;
  onOpenCalc?: (calcType: 'troop' | 'gear' | 'bear') => void;
}

export const SectionCard: React.FC<Props> = ({ section, lang, dualView, onOpenCalc }) => {
  const isTr = lang === 'tr';
  const trSection = SECTIONS_TR[section.id];

  const renderBadge = (badge?: { text: string; type: 'ok' | 'warn' | 'bad' }) => {
    if (!badge) return null;
    const styles = {
      ok: 'bg-green-950/40 text-green-400 border-green-800',
      warn: 'bg-amber-950/40 text-amber-400 border-amber-800',
      bad: 'bg-red-950/40 text-red-400 border-red-800',
    };
    return (
      <span className={`inline-block text-[11px] font-semibold px-2.5 py-0.5 rounded-full border ${styles[badge.type] || styles.ok}`}>
        {badge.text}
      </span>
    );
  };

  const renderNotice = (n: any, idx: number) => {
    const borders = {
      info: 'border-l-4 border-cyan-400 bg-cyan-950/20 text-cyan-200',
      warn: 'border-l-4 border-amber-400 bg-amber-950/20 text-amber-200',
      danger: 'border-l-4 border-red-400 bg-red-950/20 text-red-200',
      ok: 'border-l-4 border-green-400 bg-green-950/20 text-green-200',
    };
    const Icon = {
      info: Info,
      warn: AlertTriangle,
      danger: AlertOctagon,
      ok: CheckCircle2,
    }[n.type as 'info' | 'warn' | 'danger' | 'ok'] || Info;

    return (
      <div key={idx} className={`p-4 rounded-xl my-3 text-xs leading-relaxed ${borders[n.type as 'info' | 'warn' | 'danger' | 'ok']}`}>
        {n.title && (
          <div className="font-bold text-sm mb-1.5 flex items-center gap-1.5 text-white">
            <Icon className="w-4 h-4 flex-shrink-0" />
            <span>{n.title}</span>
          </div>
        )}
        {n.content && <p className="text-[#eaf1fa]/90">{n.content}</p>}
        {n.bullets && n.bullets.length > 0 && (
          <ul className="mt-2 space-y-1 list-disc pl-5 text-[#eaf1fa]/90">
            {n.bullets.map((b: string, bIdx: number) => (
              <li key={bIdx}>{b}</li>
            ))}
          </ul>
        )}
      </div>
    );
  };

  const renderTable = (t: any, idx: number) => (
    <div key={idx} className="my-4 overflow-x-auto rounded-xl border border-[#1e3352]">
      {t.title && (
        <div className="bg-[#142136] px-4 py-2.5 font-bold text-xs text-[#b3e0f3] border-b border-[#1e3352]">
          {t.title}
        </div>
      )}
      <table className="w-full text-left text-xs bg-[#0d1727]">
        <thead>
          <tr className="bg-[#142136] text-[#86a3c6] uppercase tracking-wider text-[11px]">
            {t.headers.map((h: string, hIdx: number) => (
              <th key={hIdx} className="p-3 border-b border-[#1e3352] font-semibold">
                {h}
              </th>
            ))}
          </tr>
        </thead>
        <tbody className="divide-y divide-[#1e3352]/50">
          {t.rows.map((row: (string | number)[], rIdx: number) => (
            <tr key={rIdx} className="hover:bg-[#142136]/50 transition-colors">
              {row.map((cell: string | number, cIdx: number) => (
                <td key={cIdx} className="p-3 text-gray-200">
                  {cell}
                </td>
              ))}
            </tr>
          ))}
        </tbody>
      </table>
      {t.note && (
        <div className="p-2.5 bg-[#0a121e] text-[11px] text-[#86a3c6] italic border-t border-[#1e3352]">
          {t.note}
        </div>
      )}
    </div>
  );

  return (
    <section id={section.id} className="pt-8 pb-12 border-b border-[#1e3352]/70 scroll-mt-24">
      {/* Section Header */}
      <div className="mb-6">
        <div className="flex flex-wrap items-center gap-3">
          <h2 className="text-xl sm:text-2xl font-extrabold text-[#b3e0f3] tracking-tight">
            {section.title}
          </h2>
          {renderBadge(section.badge)}
        </div>
        <p className="text-sm text-[#86a3c6] mt-1.5">{section.subtitle}</p>

        {/* Dual View Turkish Original Subtitle */}
        {dualView && !isTr && trSection && (
          <div className="mt-2 text-xs text-cyan-400/80 bg-cyan-950/20 px-3 py-1.5 rounded-lg border border-cyan-900/50">
            <span className="font-semibold text-cyan-300">TR:</span> {trSection.title} — {trSection.subtitle}
          </div>
        )}

        {/* Interactive Quick Launch Buttons for Calculator-relevant sections */}
        {(section.id === 'helios-oranlar' || section.id === 'ordu-oranlari') && onOpenCalc && (
          <button
            type="button"
            onClick={() => onOpenCalc('troop')}
            className="mt-3 inline-flex items-center gap-2 px-3 py-1.5 rounded-xl bg-cyan-500/10 hover:bg-cyan-500/20 border border-cyan-500/30 text-cyan-300 text-xs font-bold transition-colors"
          >
            <span>🎯 {isTr ? 'Bu Oranları Hesaplayıcıda Dene' : 'Test These Ratios in Calculator'}</span>
            <ChevronRight className="w-3.5 h-3.5" />
          </button>
        )}

        {section.id === 'hero-gear' && onOpenCalc && (
          <button
            type="button"
            onClick={() => onOpenCalc('gear')}
            className="mt-3 inline-flex items-center gap-2 px-3 py-1.5 rounded-xl bg-amber-500/10 hover:bg-amber-500/20 border border-amber-500/30 text-amber-300 text-xs font-bold transition-colors"
          >
            <span>⚔️ {isTr ? 'Mithril ve Stat Planlayıcısını Aç' : 'Open Mithril & Stat Planner'}</span>
            <ChevronRight className="w-3.5 h-3.5" />
          </button>
        )}

        {section.id === 'bear-trap' && onOpenCalc && (
          <button
            type="button"
            onClick={() => onOpenCalc('bear')}
            className="mt-3 inline-flex items-center gap-2 px-3 py-1.5 rounded-xl bg-red-500/10 hover:bg-red-500/20 border border-red-500/30 text-red-300 text-xs font-bold transition-colors"
          >
            <span>🐻 {isTr ? 'Ayı Tuzağı Taktik Asistanını Aç' : 'Open Bear Trap Assistant'}</span>
            <ChevronRight className="w-3.5 h-3.5" />
          </button>
        )}
      </div>

      {/* Summary Cards */}
      {section.cards && section.cards.length > 0 && (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3 my-4">
          {section.cards.map((card, cIdx) => (
            <div
              key={cIdx}
              className="p-4 rounded-xl bg-[#142136] border border-[#1e3352] hover:border-cyan-500/50 transition-colors space-y-1.5"
            >
              <div className="flex items-center justify-between">
                <h3 className="font-bold text-sm text-white">{card.title}</h3>
                {card.tag && (
                  <span className="text-[10px] font-mono px-2 py-0.5 rounded-full border border-cyan-800 bg-cyan-950 text-cyan-300">
                    {card.tag}
                  </span>
                )}
              </div>
              <p className="text-xs text-[#86a3c6] leading-relaxed">{card.desc}</p>
            </div>
          ))}
        </div>
      )}

      {/* Embedded SVG Diagram */}
      {section.svgType && <SvgDiagram type={section.svgType} lang={lang} />}

      {/* Priority Box */}
      {section.priorityBox && (
        <div className="p-4 rounded-xl bg-gradient-to-br from-[#142136] to-[#0a121e] border border-cyan-500/30 my-4 space-y-2">
          <h4 className="font-bold text-sm text-cyan-300">{section.priorityBox.title}</h4>
          <ol className="list-decimal pl-5 space-y-1 text-xs text-gray-200">
            {section.priorityBox.items.map((it, idx) => (
              <li key={idx}>{it}</li>
            ))}
          </ol>
          {section.priorityBox.note && (
            <p className="text-[11px] text-[#86a3c6] mt-2 italic">{section.priorityBox.note}</p>
          )}
        </div>
      )}

      {/* Tables */}
      {section.tables && section.tables.map(renderTable)}

      {/* Notices */}
      {section.notices && section.notices.map(renderNotice)}

      {/* Subsections */}
      {section.subsections && section.subsections.length > 0 && (
        <div className="mt-8 space-y-6 pl-0 sm:pl-3 border-l-0 sm:border-l-2 border-[#1e3352]">
          {section.subsections.map((sub, sIdx) => (
            <div key={sIdx} className="space-y-3">
              <h3 className="text-base font-bold text-[#b3e0f3]">{sub.title}</h3>
              {sub.content && <p className="text-xs text-[#86a3c6]">{sub.content}</p>}

              {sub.cards && sub.cards.length > 0 && (
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  {sub.cards.map((c, idx) => (
                    <div key={idx} className="p-4 rounded-xl bg-[#142136] border border-[#1e3352]">
                      <h4 className="font-bold text-xs text-white mb-1">{c.title}</h4>
                      <p className="text-xs text-[#86a3c6]">{c.desc}</p>
                    </div>
                  ))}
                </div>
              )}

              {sub.priorityBox && (
                <div className="p-4 rounded-xl bg-[#142136] border border-cyan-500/30">
                  <h4 className="font-bold text-xs text-cyan-300 mb-2">{sub.priorityBox.title}</h4>
                  <ol className="list-decimal pl-5 space-y-1 text-xs text-gray-200">
                    {sub.priorityBox.items.map((it, idx) => (
                      <li key={idx}>{it}</li>
                    ))}
                  </ol>
                </div>
              )}

              {sub.tables && sub.tables.map(renderTable)}
              {sub.notices && sub.notices.map(renderNotice)}
            </div>
          ))}
        </div>
      )}
    </section>
  );
};
