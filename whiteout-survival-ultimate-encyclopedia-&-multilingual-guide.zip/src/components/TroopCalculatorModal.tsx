import React, { useState } from 'react';
import { X, Shield, Crosshair, Swords, AlertTriangle, CheckCircle2 } from 'lucide-react';
import { SupportedLanguage } from '../types';

interface Props {
  isOpen: boolean;
  onClose: () => void;
  lang: SupportedLanguage;
}

interface RatioPreset {
  id: string;
  name: string;
  role: 'attack' | 'defense' | 'pve';
  infantry: number;
  lancer: number;
  marksman: number;
  description: string;
}

export const TroopCalculatorModal: React.FC<Props> = ({ isOpen, onClose, lang }) => {
  const [marchCapacity, setMarchCapacity] = useState<number>(140000);
  const [selectedPresetId, setSelectedPresetId] = useState<string>('balanced');
  const [customInfantry, setCustomInfantry] = useState<number>(50);
  const [customLancer, setCustomLancer] = useState<number>(20);
  const [customMarksman, setCustomMarksman] = useState<number>(30);
  const [isCustom, setIsCustom] = useState<boolean>(false);

  if (!isOpen) return null;

  const presets: RatioPreset[] = [
    {
      id: 'balanced',
      name: lang === 'tr' ? 'Dengeli / Açık Alan (1. Ordu)' : 'Balanced / Open Field (1st March)',
      role: 'attack',
      infantry: 50,
      lancer: 20,
      marksman: 30,
      description: lang === 'tr' ? 'Genel PvP ve açık saha çatışmaları için ideal.' : 'Standard all-around ratio for PvP and field skirmishes.',
    },
    {
      id: 'defense',
      name: lang === 'tr' ? 'Garnizon / Kale Savunması' : 'Garrison / Sunfire Defense',
      role: 'defense',
      infantry: 60,
      lancer: 20,
      marksman: 20,
      description: lang === 'tr' ? 'Ön saf düşman hasarını emer, kayıpları asgariye indirir.' : 'Soaks rally damage and minimizes hospital casualties.',
    },
    {
      id: 'beartrap',
      name: lang === 'tr' ? 'Ayı Tuzağı (Bear Hunt)' : 'Bear Trap / Bear Hunt',
      role: 'pve',
      infantry: 10,
      lancer: 10,
      marksman: 80,
      description: lang === 'tr' ? 'Maksimum hasar için nişancı yığılır (En az 5.000 Piyade şart!).' : 'Maximum DPS marksman stacking (Min 5,000 Infantry mandatory!).',
    },
    {
      id: 'crazyjoe',
      name: lang === 'tr' ? 'Crazy Joe (Çılgın Joe)' : 'Crazy Joe City Defense',
      role: 'defense',
      infantry: 90,
      lancer: 10,
      marksman: 0,
      description: lang === 'tr' ? 'Barikatları ve şehri korumak için saf ön saf duvarı.' : 'Pure frontline wall to guard barricades from breaches.',
    },
    {
      id: 'helios-inf-atk',
      name: lang === 'tr' ? 'Helios Piyade — Saldırı' : 'Helios Infantry — Attack',
      role: 'attack',
      infantry: 50,
      lancer: 25,
      marksman: 25,
      description: lang === 'tr' ? 'Helios Piyade ön safı tutar, arka saf T10 birimler hasar verir.' : 'Helios front row anchors while backline units rain damage.',
    },
    {
      id: 'helios-inf-def',
      name: lang === 'tr' ? 'Helios Piyade — Savunma' : 'Helios Infantry — Defense',
      role: 'defense',
      infantry: 70,
      lancer: 15,
      marksman: 15,
      description: lang === 'tr' ? 'Yenilmez ön saf savunması. Helios Piyade hayatta kalır.' : 'Unbreakable front row defense with unmatched sustain.',
    },
    {
      id: 'helios-inf-mar',
      name: lang === 'tr' ? 'Helios Piyade + Nişancı — Saldırı' : 'Helios Inf + Marksman — Attack',
      role: 'attack',
      infantry: 45,
      lancer: 15,
      marksman: 40,
      description: lang === 'tr' ? 'Altın standart saldırı ikilisi; dayanıklılık ve yüksek patlama hasarı.' : 'Gold standard offensive duo with both durability and burst.',
    },
    {
      id: 'helios-all',
      name: lang === 'tr' ? 'Tam Helios — Saldırı' : 'Full Helios — Attack',
      role: 'attack',
      infantry: 45,
      lancer: 20,
      marksman: 35,
      description: lang === 'tr' ? 'Tüm birlikler T11 Helios olduğunda en ölümcül dengeli dağılım.' : 'Deadliest balanced spread when all units are T11 Helios.',
    },
  ];

  const currentPreset = presets.find((p) => p.id === selectedPresetId) || presets[0];

  const infPct = isCustom ? customInfantry : currentPreset.infantry;
  const lanPct = isCustom ? customLancer : currentPreset.lancer;
  const marPct = isCustom ? customMarksman : currentPreset.marksman;

  const infCount = Math.round((marchCapacity * infPct) / 100);
  const lanCount = Math.round((marchCapacity * lanPct) / 100);
  const marCount = Math.max(0, marchCapacity - infCount - lanCount);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-fade-in">
      <div className="bg-[#0d1727] border border-[#1e3352] rounded-2xl w-full max-w-2xl max-h-[90vh] overflow-y-auto shadow-2xl p-6 text-[#eaf1fa]">
        <div className="flex items-center justify-between pb-4 border-b border-[#1e3352]">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-cyan-500/10 border border-cyan-500/30 flex items-center justify-center text-cyan-400">
              <Swords className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-lg font-bold text-[#b3e0f3]">
                {lang === 'tr' ? 'Birlik & Ordu Oranı Hesaplayıcı' : 'Troop & March Ratio Calculator'}
              </h2>
              <p className="text-xs text-[#86a3c6]">
                {lang === 'tr' ? 'Bölüm 9 & 10 meta oranlarına dayalı anlık hesaplama' : 'Instant troop calculator grounded in Chapters 9 & 10'}
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 rounded-lg text-gray-400 hover:text-white hover:bg-[#142136] transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="mt-5 space-y-5">
          {/* March Capacity Input */}
          <div>
            <label className="block text-xs font-semibold text-[#86a3c6] uppercase tracking-wider mb-2">
              {lang === 'tr' ? 'Toplam Yürüyüş Kapasitesi (Asker Sayısı)' : 'Total March Capacity (Troop Count)'}
            </label>
            <div className="relative">
              <input
                type="number"
                min={10000}
                max={500000}
                step={1000}
                value={marchCapacity}
                onChange={(e) => setMarchCapacity(Math.max(1000, parseInt(e.target.value) || 0))}
                className="w-full bg-[#142136] border border-[#1e3352] rounded-xl px-4 py-3 text-lg font-mono font-bold text-cyan-300 focus:outline-none focus:border-cyan-400"
              />
              <div className="absolute right-3 top-3 flex gap-1">
                {[100000, 140000, 180000, 220000].map((v) => (
                  <button
                    key={v}
                    type="button"
                    onClick={() => setMarchCapacity(v)}
                    className="text-xs px-2 py-1 rounded bg-[#0d1727] text-gray-300 hover:text-cyan-300 border border-[#1e3352]"
                  >
                    {v / 1000}k
                  </button>
                ))}
              </div>
            </div>
          </div>

          {/* Preset Selector */}
          <div>
            <div className="flex items-center justify-between mb-2">
              <label className="text-xs font-semibold text-[#86a3c6] uppercase tracking-wider">
                {lang === 'tr' ? 'Senaryo / Oran Seçimi' : 'Scenario / Preset Selection'}
              </label>
              <button
                type="button"
                onClick={() => setIsCustom(!isCustom)}
                className="text-xs text-cyan-400 hover:underline"
              >
                {isCustom ? (lang === 'tr' ? 'Hazır Listeye Dön' : 'Use Presets') : (lang === 'tr' ? 'Özel Oran Gir' : 'Custom Ratio')}
              </button>
            </div>

            {!isCustom ? (
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                {presets.map((preset) => {
                  const isSelected = selectedPresetId === preset.id;
                  return (
                    <button
                      key={preset.id}
                      type="button"
                      onClick={() => setSelectedPresetId(preset.id)}
                      className={`text-left p-3 rounded-xl border transition-all ${
                        isSelected
                          ? 'bg-cyan-950/40 border-cyan-400 text-cyan-200 shadow-sm'
                          : 'bg-[#142136] border-[#1e3352] text-gray-300 hover:border-gray-500'
                      }`}
                    >
                      <div className="flex items-center justify-between">
                        <span className="font-semibold text-xs">{preset.name}</span>
                        <span className="text-[11px] font-mono text-cyan-400">
                          {preset.infantry}/{preset.lancer}/{preset.marksman}
                        </span>
                      </div>
                      <p className="text-[11px] text-[#86a3c6] mt-1 line-clamp-1">{preset.description}</p>
                    </button>
                  );
                })}
              </div>
            ) : (
              <div className="p-4 bg-[#142136] rounded-xl border border-[#1e3352] space-y-3">
                <div className="flex justify-between text-xs font-mono">
                  <span>Piyade: {customInfantry}%</span>
                  <span>Mızrakçı: {customLancer}%</span>
                  <span>Nişancı: {customMarksman}%</span>
                </div>
                <div className="grid grid-cols-3 gap-2">
                  <input
                    type="range"
                    min="0"
                    max="100"
                    value={customInfantry}
                    onChange={(e) => {
                      const v = parseInt(e.target.value);
                      setCustomInfantry(v);
                      if (v + customLancer > 100) setCustomLancer(100 - v);
                      setCustomMarksman(Math.max(0, 100 - v - (v + customLancer > 100 ? 100 - v : customLancer)));
                    }}
                    className="accent-red-500"
                  />
                  <input
                    type="range"
                    min="0"
                    max="100"
                    value={customLancer}
                    onChange={(e) => {
                      const v = parseInt(e.target.value);
                      setCustomLancer(v);
                      setCustomMarksman(Math.max(0, 100 - customInfantry - v));
                    }}
                    className="accent-yellow-500"
                  />
                  <input
                    type="range"
                    min="0"
                    max="100"
                    value={customMarksman}
                    onChange={(e) => {
                      const v = parseInt(e.target.value);
                      setCustomMarksman(v);
                      setCustomLancer(Math.max(0, 100 - customInfantry - v));
                    }}
                    className="accent-green-500"
                  />
                </div>
              </div>
            )}
          </div>

          {/* Visual Percentage Bar */}
          <div>
            <div className="flex items-center justify-between text-xs mb-1 font-mono">
              <span className="text-red-400 font-bold">🛡️ {infPct}% {lang === 'tr' ? 'Piyade' : 'Infantry'}</span>
              <span className="text-yellow-400 font-bold">⚔️ {lanPct}% {lang === 'tr' ? 'Mızrakçı' : 'Lancer'}</span>
              <span className="text-green-400 font-bold">🏹 {marPct}% {lang === 'tr' ? 'Nişancı' : 'Marksman'}</span>
            </div>
            <div className="w-full h-4 rounded-full overflow-hidden flex bg-gray-800">
              <div style={{ width: `${infPct}%` }} className="bg-red-500 transition-all duration-300" />
              <div style={{ width: `${lanPct}%` }} className="bg-yellow-500 transition-all duration-300" />
              <div style={{ width: `${marPct}%` }} className="bg-green-500 transition-all duration-300" />
            </div>
          </div>

          {/* Calculated Output Cards */}
          <div className="grid grid-cols-3 gap-3">
            <div className="p-4 rounded-xl bg-red-950/20 border border-red-500/30 text-center">
              <div className="flex items-center justify-center gap-1 text-red-400 mb-1">
                <Shield className="w-4 h-4" />
                <span className="text-xs font-bold uppercase">{lang === 'tr' ? 'Piyade' : 'Infantry'}</span>
              </div>
              <div className="text-2xl font-mono font-bold text-red-300">
                {infCount.toLocaleString()}
              </div>
              <div className="text-[11px] text-red-400/80 mt-1">
                {infPct}% {lang === 'tr' ? 'Ön Saf Tankı' : 'Frontline Tank'}
              </div>
            </div>

            <div className="p-4 rounded-xl bg-yellow-950/20 border border-yellow-500/30 text-center">
              <div className="flex items-center justify-center gap-1 text-yellow-400 mb-1">
                <Swords className="w-4 h-4" />
                <span className="text-xs font-bold uppercase">{lang === 'tr' ? 'Mızrakçı' : 'Lancer'}</span>
              </div>
              <div className="text-2xl font-mono font-bold text-yellow-300">
                {lanCount.toLocaleString()}
              </div>
              <div className="text-[11px] text-yellow-400/80 mt-1">
                {lanPct}% {lang === 'tr' ? 'Orta Saf Tampon' : 'Mid-Row Flank'}
              </div>
            </div>

            <div className="p-4 rounded-xl bg-green-950/20 border border-green-500/30 text-center">
              <div className="flex items-center justify-center gap-1 text-green-400 mb-1">
                <Crosshair className="w-4 h-4" />
                <span className="text-xs font-bold uppercase">{lang === 'tr' ? 'Nişancı' : 'Marksman'}</span>
              </div>
              <div className="text-2xl font-mono font-bold text-green-300">
                {marCount.toLocaleString()}
              </div>
              <div className="text-[11px] text-green-400/80 mt-1">
                {marPct}% {lang === 'tr' ? 'Arka Saf Hasarı' : 'Backline Burst'}
              </div>
            </div>
          </div>

          {/* Contextual Warning */}
          {selectedPresetId === 'beartrap' && infCount < 5000 && (
            <div className="p-3 rounded-xl bg-red-950/40 border border-red-500/50 flex items-start gap-2 text-xs text-red-300">
              <AlertTriangle className="w-4 h-4 text-red-400 flex-shrink-0 mt-0.5" />
              <span>
                {lang === 'tr'
                  ? 'Kritik Uyarı: Ayı Tuzağı formülünde en az 5.000 Piyade bulunmalıdır! Piyade 5.000 altına düşerse arka saf nişancılar tam verimle hasar veremez.'
                  : 'Critical Warning: You must deploy at least 5,000 Infantry in Bear Trap! Falling below 5,000 severely depresses backline marksman damage output.'}
              </span>
            </div>
          )}

          {selectedPresetId === 'beartrap' && infCount >= 5000 && (
            <div className="p-3 rounded-xl bg-green-950/30 border border-green-500/40 flex items-center gap-2 text-xs text-green-300">
              <CheckCircle2 className="w-4 h-4 text-green-400 flex-shrink-0" />
              <span>
                {lang === 'tr'
                  ? 'Harika! 5.000+ Piyade kuralı sağlandı. Nişancı hasarınız maksimum seviyeye çıkacaktır.'
                  : 'Optimal! 5,000+ Infantry threshold met. Marksman damage scaling is operating at peak efficiency.'}
              </span>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
